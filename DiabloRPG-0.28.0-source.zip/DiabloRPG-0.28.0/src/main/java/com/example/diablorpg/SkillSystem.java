package com.example.diablorpg;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

/**
 * 직업 / 스킬 트리 / 저주 / 오라 / 장비 스킬 옵션 시스템 (0.7.x). [전부 미검증: 작성자가 빌드/실행해 보지 못했다]
 *
 * 설계 요약
 *  - 직업·스킬·오라·저주·발동 옵션은 전부 config.yml(classes / skills / skill-procs)로 정의한다.
 *    kind: melee(근접 공격) / aoe(주변 범위) / fear(공포) / whirlwind(회전) / leap(도약) / leap_attack(대상에게 도약)
 *          / buff(강화) / passive(패시브) / curse(저주) / aura(오라) / display(효과 없이 표시만)
 *  - 수치는 {base, per-level, per-level2, max} / {points: {레벨: 값}} / {values: [..]} / 숫자 하나.
 *  - synergy: 다른 스킬의 레벨 x per-level 만큼 특정 수치(stat)에 더한다(mode: pct 이면 곱셈 %).
 *  - 스킬 사용 조건: 무기가 핫바 1번 칸이고 손에 들고 있을 때만 (config skill-system.require-slot-one).
 *  - 재사용 대기시간은 없다. 공격 스킬(speed: attack)은 공격 속도, 함성 스킬(speed: cast)은 시전 속도가 간격을 정한다.
 *    lock 이 같은 스킬은 이전 동작이 끝나기 전에 다시 쓸 수 없다(도약류: 착지 전, 소용돌이: 회전 중).
 *  - 패시브/버프/오라의 능력치는 "합성 PDC"로 만들어 기존 전투/방어/능력치 계산에 합산한다.
 *  - 스킬 피해는 target.damage(양, 플레이어)로 주기 때문에 기존 피해 파이프라인을 그대로 탄다.
 *    "마법 피해"(비전)와 오라 틱 피해, 전장의 함성 고정 피해는 pure 플래그로 파이프라인을 건너뛴다.
 */
final class SkillSystem implements Listener {

    // ===================================================================
    //  데이터 클래스
    // ===================================================================

    static final class ClassDef {
        String id;
        String name;
        Material icon = Material.IRON_SWORD;
        String desc = "";
        List<String> tabs = new ArrayList<>();
    }

    static final class Syn {
        String skill;
        String stat;
        double per;
        boolean pct;
    }

    static final class SkillDef {
        String id;
        String name;
        String classId = "";
        String kind = "passive";
        String desc = "";
        String speed = "none"; // attack / cast / none
        String lock = "";      // 같은 lock 끼리는 동작이 끝나야 다시 쓸 수 있다
        Material icon = Material.PAPER;
        int tab;
        int tier;
        int row;
        int col;
        int maxLevel = 20;
        int reqLevel = 0;
        List<String> prereq = new ArrayList<>();
        List<Syn> syn = new ArrayList<>();
        ConfigurationSection sec;
    }

    static final class ProcDef {
        String id;
        String optionName;
        String trigger = "hit";
        String cast;
        int level = 1;
    }

    static final class PData {
        String cls;                 // 직업 id (없으면 null)
        int bonusPoints;            // 관리자가 준 추가 포인트
        int maxLevel;               // 지금까지 도달한 최대 바닐라 레벨(포인트/요구 레벨 계산용)
        boolean hotkeys = true;     // 숫자키로 스킬 선택
        String left;                // 좌클릭 스킬 (null = 기본 공격)
        String right;               // 우클릭 스킬
        String activeAura;          // 클래스 오라(토글)
        final Map<String, Integer> levels = new LinkedHashMap<>();
        final String[] hot = new String[9]; // 인덱스 1~8 = 핫바 2~9번 칸
    }

    static final class Buff {
        final String id;
        final int level;
        final long until;

        Buff(String id, int level, long until) {
            this.id = id;
            this.level = level;
            this.until = until;
        }
    }

    static final class Curse {
        final double amount;
        final long until;

        Curse(double amount, long until) {
            this.amount = amount;
            this.until = until;
        }
    }

    /** 광분: 적중마다 쌓이는 속도 보너스. */
    static final class Frenzy {
        String skillId;
        int level;
        int stacks;
        long until;
    }

    /** 0.17.0: 독 구름 / 불길 (바닥에 남는 지속 피해 영역) */
    static final class Cloud {
        UUID owner;
        World world;
        Location loc;
        double radius;
        long until;
        double dps;
        String element = "poison";
    }

    static final class Gear {
        int all;
        int castSpeed;
        final Map<String, Integer> cls = new HashMap<>();
        final Map<String, Integer> lv = new HashMap<>();
        final Map<String, Integer> aura = new HashMap<>();
        final Map<String, Integer> proc = new HashMap<>();
    }

    static final class Cached {
        final int tick;
        final PersistentDataContainer pdc;
        final Map<String, Double> totals;

        Cached(int tick, PersistentDataContainer pdc, Map<String, Double> totals) {
            this.tick = tick;
            this.pdc = pdc;
            this.totals = totals;
        }
    }

    static final class SkillHolder implements InventoryHolder {
        final String type; // "tree" / "class"
        int tab;
        Inventory inv;
        final Map<Integer, String> slotSkill = new HashMap<>();

        SkillHolder(String type) {
            this.type = type;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private enum Result { FAIL, OK, WAIT }

    // ===================================================================
    //  필드
    // ===================================================================

    private static final Material[] TAB_ICONS = {Material.IRON_SWORD, Material.BELL, Material.SHIELD};
    private static final int[] TIER_LEVELS = {1, 6, 12, 18, 24, 30};
    private static final int GUI_SIZE = 54;
    private static final int STAR_SLOT = 35;
    private static final int BOOK_SLOT = 44;

    private final DiabloRPG plugin;
    private final Random random = new Random();
    private final NamespacedKey dataKey;

    private final Map<String, ClassDef> classes = new LinkedHashMap<>();
    private final Map<String, SkillDef> skills = new LinkedHashMap<>();
    private final Map<String, ProcDef> procs = new LinkedHashMap<>();
    private final Map<String, String> optionKeys = new HashMap<>();          // 옵션 이름 -> PDC 키 이름
    private final Map<String, NamespacedKey> keyCache = new HashMap<>();

    private final Map<UUID, PData> data = new HashMap<>();
    private final Map<UUID, Map<String, Buff>> buffs = new HashMap<>();
    private final Map<UUID, Map<String, Buff>> auraBuffs = new HashMap<>();
    private final Map<UUID, Map<String, Curse>> curses = new HashMap<>();
    private final Map<UUID, Frenzy> frenzy = new HashMap<>();
    private final Map<UUID, String> locks = new HashMap<>();
    private final Map<UUID, Long> nextSwing = new HashMap<>();
    private final Map<UUID, Long> castingUntil = new HashMap<>();
    private final Map<UUID, Long> leapGuard = new HashMap<>();
    private final Map<UUID, Long> feared = new HashMap<>();
    private final Map<UUID, Integer> lastLeftCast = new HashMap<>();
    private final Map<UUID, Cached> bonusCache = new HashMap<>();
    private final Map<UUID, Object[]> gearCache = new HashMap<>(); // {Integer tick, Gear}

    private int tickCounter = 0;       // 0.7.6: Paper 전용 Bukkit.getCurrentTick() 대신 직접 센다
    private boolean casting = false;    // 스킬이 주는 피해 중 (재귀/발동 방지)
    private boolean pure = false;       // 기존 피해 파이프라인을 건너뛰는 피해
    private boolean reflecting = false; // 강철 처녀 반사 중
    private final Map<UUID, Long> converted = new HashMap<>(); // 0.16.0: 전향된 몹 -> 끝나는 시각
    private Map<String, Double> tempBonus;                         // 0.17.0: 스킬 한 번의 적중에만 붙는 임시 옵션 보너스
    private UUID tempOwner;
    private final List<Cloud> clouds = new ArrayList<>();          // 0.17.0: 독 구름 / 불길
    private final Map<UUID, Long> lastMove = new HashMap<>();      // 0.17.0: 마지막으로 움직인 시각 (회피 계열 스킬)

    SkillSystem(DiabloRPG plugin) {
        this.plugin = plugin;
        this.dataKey = new NamespacedKey(plugin, "skill_data");
        reload();
    }

    /** 플레이어의 직업 id (없으면 null). */
    String classOf(Player p) {
        return data(p).cls;
    }

    boolean isPureHit() {
        return pure;
    }

    boolean isCasting() {
        return casting;
    }

    void start() {
        restoreTempBlocks();
        Bukkit.getScheduler().runTaskTimer(plugin, () -> tickCounter++, 1L, 1L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::fastTick, 20L, 10L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::slowTick, 40L, 20L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::summonTick, 30L, 10L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::fxTick, 30L, 6L);
    }

    // ===================================================================
    //  config 읽기
    // ===================================================================

    private static final java.util.regex.Pattern ID_PATTERN = java.util.regex.Pattern.compile("[a-z0-9_]+");

    void reload() {
        classes.clear();
        skills.clear();
        procs.clear();
        optionKeys.clear();
        keyCache.clear();

        ConfigurationSection cs = plugin.getConfig().getConfigurationSection("classes");
        if (cs != null) {
            for (String id : cs.getKeys(false)) {
                ConfigurationSection c = cs.getConfigurationSection(id);
                if (c == null || !ID_PATTERN.matcher(id).matches()) continue;
                ClassDef def = new ClassDef();
                def.id = id;
                def.name = c.getString("name", id);
                def.icon = mat(c.getString("icon"), Material.IRON_SWORD);
                def.desc = c.getString("description", "");
                def.tabs.addAll(c.getStringList("tabs"));
                if (def.tabs.isEmpty()) def.tabs.add("스킬");
                classes.put(id, def);
            }
        }

        ConfigurationSection ss = plugin.getConfig().getConfigurationSection("skills");
        if (ss != null) {
            for (String id : ss.getKeys(false)) {
                ConfigurationSection c = ss.getConfigurationSection(id);
                if (c == null) continue;
                if (!ID_PATTERN.matcher(id).matches()) {
                    plugin.getLogger().warning("[스킬] 스킬 id는 영문 소문자/숫자/_ 만 가능: " + id);
                    continue;
                }
                SkillDef d = new SkillDef();
                d.id = id;
                d.name = c.getString("name", id);
                d.classId = c.getString("class", "");
                d.kind = c.getString("kind", "passive").toLowerCase(Locale.ROOT);
                d.desc = c.getString("description", "");
                d.speed = c.getString("speed", "none").toLowerCase(Locale.ROOT);
                d.lock = c.getString("lock", "");
                d.icon = mat(c.getString("icon"), Material.PAPER);
                d.tab = c.getInt("tab", 0);
                d.tier = c.getInt("tier", 0);
                if (d.tier >= 1 && d.tier <= TIER_LEVELS.length) {
                    d.reqLevel = TIER_LEVELS[d.tier - 1];
                    d.row = d.tier - 1;
                } else {
                    d.reqLevel = c.getInt("req-level", 0);
                    d.row = Math.max(0, Math.min(5, c.getInt("row", 0)));
                }
                d.col = Math.max(0, Math.min(7, c.getInt("col", 0)));
                d.maxLevel = Math.max(1, c.getInt("max-level", 20));
                d.prereq.addAll(c.getStringList("prereq"));
                for (Map<?, ?> m : c.getMapList("synergy")) {
                    Syn sy = new Syn();
                    sy.skill = String.valueOf(m.get("skill"));
                    sy.stat = String.valueOf(m.get("stat"));
                    Object per = m.get("per-level");
                    sy.per = per instanceof Number n ? n.doubleValue() : 0.0;
                    sy.pct = "pct".equals(String.valueOf(m.get("mode")));
                    d.syn.add(sy);
                }
                d.sec = c;
                skills.put(id, d);
            }
        }

        ConfigurationSection ps = plugin.getConfig().getConfigurationSection("skill-procs");
        if (ps != null) {
            for (String id : ps.getKeys(false)) {
                ConfigurationSection c = ps.getConfigurationSection(id);
                if (c == null || !ID_PATTERN.matcher(id).matches()) continue;
                ProcDef p = new ProcDef();
                p.id = id;
                p.optionName = c.getString("option-name", id);
                p.trigger = c.getString("trigger", "hit").toLowerCase(Locale.ROOT);
                p.cast = c.getString("cast", "");
                p.level = Math.max(1, c.getInt("level", 1));
                procs.put(id, p);
            }
        }

        // 장비 옵션 이름 -> PDC 키
        optionKeys.put("모든 스킬", "sk_all");
        optionKeys.put("시전 속도", "cast_speed");
        for (ClassDef c : classes.values()) optionKeys.put(c.name + " 스킬", "sk_class_" + c.id);
        for (SkillDef s : skills.values()) {
            optionKeys.put(s.name + " 레벨", "sk_lv_" + s.id);
            if (s.kind.equals("aura")) optionKeys.put(s.name, "au_" + s.id);
        }
        for (ProcDef p : procs.values()) optionKeys.put(p.optionName, "pr_" + p.id);
    }

    private static Material mat(String name, Material def) {
        if (name == null) return def;
        Material m = Material.matchMaterial(name);
        return m == null ? def : m;
    }

    /**
     * 레벨에 맞는 수치.
     *  - 숫자 하나: 그대로
     *  - {base, per-level, per-level2, max}: base + per-level*(L-1) + per-level2*(L-1)^2
     *  - {points: {1: 7, 5: 25}}: 주어진 레벨 사이를 직선으로 보간
     *  - {values: [..]}: 레벨 순서 목록 (넘어가면 마지막 값)
     */
    static double scaled(ConfigurationSection parent, String key, int level, double def) {
        if (parent == null) return def;
        if (parent.isConfigurationSection(key)) {
            ConfigurationSection c = parent.getConfigurationSection(key);
            double v;
            if (c.isList("values")) {
                List<Double> vals = c.getDoubleList("values");
                v = vals.isEmpty() ? def : vals.get(Math.max(0, Math.min(vals.size() - 1, level - 1)));
            } else if (c.isConfigurationSection("points")) {
                v = interpolate(c.getConfigurationSection("points"), level, def);
            } else {
                int n = Math.max(0, level - 1);
                v = c.getDouble("base", def) + c.getDouble("per-level", 0.0) * n + c.getDouble("per-level2", 0.0) * n * n;
            }
            if (c.isSet("max")) v = Math.min(v, c.getDouble("max"));
            return v;
        }
        return parent.getDouble(key, def);
    }

    private static double interpolate(ConfigurationSection pts, int level, double def) {
        TreeMap<Integer, Double> m = new TreeMap<>();
        for (String k : pts.getKeys(false)) {
            try {
                m.put(Integer.parseInt(k.trim()), pts.getDouble(k));
            } catch (NumberFormatException ignored) {
                // 잘못된 키는 무시
            }
        }
        if (m.isEmpty()) return def;
        Map.Entry<Integer, Double> lo = m.floorEntry(level);
        Map.Entry<Integer, Double> hi = m.ceilingEntry(level);
        if (lo == null) return hi.getValue();
        if (hi == null) return lo.getValue();
        if (lo.getKey().equals(hi.getKey())) return lo.getValue();
        double t = (level - lo.getKey()) / (double) (hi.getKey() - lo.getKey());
        return lo.getValue() + (hi.getValue() - lo.getValue()) * t;
    }

    /** 스킬 수치 + 시너지(다른 스킬의 레벨 x 레벨당 보너스). */
    private double val(Player p, SkillDef s, String key, int lv, double def) {
        double v = scaled(s.sec, key, lv, def);
        if (s.syn.isEmpty()) return v;
        PData d = data(p);
        double pctSum = 0.0;
        for (Syn sy : s.syn) {
            if (!sy.stat.equals(key)) continue;
            SkillDef src = skills.get(sy.skill);
            if (src == null) continue;
            int sl = level(p, d, src);
            if (sl <= 0) continue;
            if (sy.pct) pctSum += sy.per * sl;
            else v += sy.per * sl;
        }
        if (pctSum != 0.0) v *= 1.0 + pctSum / 100.0;
        return v;
    }

    private double lengthScale() {
        return plugin.getConfig().getDouble("skill-system.length-scale", 0.5);
    }

    /** 범위(칸). radius-yd 가 있으면 원작 야드 값에 길이 변환 비율을 곱한다. */
    private double radius(Player p, SkillDef s, int lv, double def) {
        if (s.sec.contains("radius-yd")) return val(p, s, "radius-yd", lv, def) * lengthScale();
        return val(p, s, "radius", lv, def);
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("skill-system.enabled", true);
    }

    private NamespacedKey key(String name) {
        return keyCache.computeIfAbsent(name, n -> new NamespacedKey(plugin, n));
    }

    /** 장비 옵션(모든 스킬/직업 스킬/스킬 레벨/오라/발동/시전 속도)을 아이템 PDC에 쓴다. 해당되면 true. */
    boolean applyDynamicOption(PersistentDataContainer pdc, String optionName, int value) {
        String k = optionKeys.get(optionName);
        if (k == null) return false;
        pdc.set(key(k), PersistentDataType.DOUBLE, (double) value);
        return true;
    }

    // ===================================================================
    //  플레이어 데이터 저장/불러오기
    // ===================================================================

    private PData data(Player p) {
        PData d = data.get(p.getUniqueId());
        if (d == null) {
            d = parse(p.getPersistentDataContainer().get(dataKey, PersistentDataType.STRING));
            data.put(p.getUniqueId(), d);
        }
        return d;
    }

    private void save(Player p) {
        PData d = data.get(p.getUniqueId());
        if (d == null) return;
        p.getPersistentDataContainer().set(dataKey, PersistentDataType.STRING, serialize(d));
        bonusCache.remove(p.getUniqueId());
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static String serialize(PData d) {
        StringBuilder lv = new StringBuilder();
        for (Map.Entry<String, Integer> e : d.levels.entrySet()) {
            if (e.getValue() <= 0) continue;
            if (lv.length() > 0) lv.append(',');
            lv.append(e.getKey()).append(':').append(e.getValue());
        }
        StringBuilder hot = new StringBuilder();
        for (int i = 1; i < d.hot.length; i++) {
            if (d.hot[i] == null) continue;
            if (hot.length() > 0) hot.append(',');
            hot.append(i).append(':').append(d.hot[i]);
        }
        return "c=" + nz(d.cls) + "|b=" + d.bonusPoints + "|m=" + d.maxLevel + "|hk=" + (d.hotkeys ? 1 : 0)
                + "|l=" + nz(d.left) + "|r=" + nz(d.right) + "|a=" + nz(d.activeAura)
                + "|v=" + lv + "|h=" + hot;
    }

    private static PData parse(String s) {
        PData d = new PData();
        if (s == null || s.isEmpty()) return d;
        for (String part : s.split("\\|")) {
            int eq = part.indexOf('=');
            if (eq < 0) continue;
            String k = part.substring(0, eq);
            String v = part.substring(eq + 1);
            try {
                switch (k) {
                    case "c" -> d.cls = v.isEmpty() ? null : v;
                    case "b" -> d.bonusPoints = Integer.parseInt(v);
                    case "m" -> d.maxLevel = Integer.parseInt(v);
                    case "hk" -> d.hotkeys = !v.equals("0");
                    case "l" -> d.left = v.isEmpty() ? null : v;
                    case "r" -> d.right = v.isEmpty() ? null : v;
                    case "a" -> d.activeAura = v.isEmpty() ? null : v;
                    case "v" -> {
                        for (String t : v.split(",")) {
                            int c = t.indexOf(':');
                            if (c > 0) d.levels.put(t.substring(0, c), Integer.parseInt(t.substring(c + 1)));
                        }
                    }
                    case "h" -> {
                        for (String t : v.split(",")) {
                            int c = t.indexOf(':');
                            if (c <= 0) continue;
                            int slot = Integer.parseInt(t.substring(0, c));
                            if (slot >= 1 && slot < d.hot.length) d.hot[slot] = t.substring(c + 1);
                        }
                    }
                    default -> { }
                }
            } catch (NumberFormatException ignored) {
                // 깨진 항목은 무시
            }
        }
        return d;
    }

    private int spentPoints(PData d) {
        int sum = 0;
        for (int v : d.levels.values()) sum += v;
        return sum;
    }

    private int totalPoints(PData d) {
        int start = plugin.getConfig().getInt("skill-system.start-points", 1);
        int per = plugin.getConfig().getInt("skill-system.points-per-level", 1);
        return start + d.maxLevel * per + d.bonusPoints;
    }

    private int freePoints(PData d) {
        return totalPoints(d) - spentPoints(d);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        PData d = data(e.getPlayer());
        d.maxLevel = Math.max(d.maxLevel, e.getPlayer().getLevel());
        save(e.getPlayer());
        final Player jp = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> respawnGolem(jp), 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        save(p);
        UUID id = p.getUniqueId();
        data.remove(id);
        buffs.remove(id);
        auraBuffs.remove(id);
        frenzy.remove(id);
        locks.remove(id);
        nextSwing.remove(id);
        castingUntil.remove(id);
        leapGuard.remove(id);
        lastLeftCast.remove(id);
        bonusCache.remove(id);
        gearCache.remove(id);
        fxAuras.remove(id);
        removeSummonsOf(id);
    }

    // ===================================================================
    //  장비 스킬 옵션 합산 (모든 스킬 / 직업 스킬 / 스킬 레벨 / 오라 / 발동 / 시전 속도)
    // ===================================================================

    private boolean isRpg(ItemStack it) {
        return it != null && !it.getType().isAir() && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(plugin.rarityKey, PersistentDataType.STRING);
    }

    private Gear gearOf(Player p) {
        int tick = tickCounter;
        Object[] c = gearCache.get(p.getUniqueId());
        if (c != null && (Integer) c[0] == tick) return (Gear) c[1];

        List<PersistentDataContainer> pdcs = new ArrayList<>();
        for (ItemStack a : p.getInventory().getArmorContents()) {
            if (isRpg(a)) pdcs.add(a.getItemMeta().getPersistentDataContainer());
        }
        ItemStack off = p.getInventory().getItemInOffHand();
        if (off.getType() == Material.SHIELD && isRpg(off)) pdcs.add(off.getItemMeta().getPersistentDataContainer());
        ItemStack main = p.getInventory().getItemInMainHand();
        if (isRpg(main)) pdcs.add(main.getItemMeta().getPersistentDataContainer());
        if (plugin.equipSystem() != null) {
            for (ItemStack ex : plugin.equipSystem().extraItems(p)) {
                if (isRpg(ex)) pdcs.add(ex.getItemMeta().getPersistentDataContainer());
            }
        }
        SetSystem.Bonus sb = plugin.setSystem() == null ? null : plugin.setSystem().bonusFor(p);
        if (sb != null) pdcs.add(sb.pdc);

        Gear g = new Gear();
        for (PersistentDataContainer pdc : pdcs) {
            g.all += (int) Math.round(pdc.getOrDefault(key("sk_all"), PersistentDataType.DOUBLE, 0.0));
            g.castSpeed += (int) Math.round(pdc.getOrDefault(key("cast_speed"), PersistentDataType.DOUBLE, 0.0));
            for (ClassDef cd : classes.values()) {
                int v = (int) Math.round(pdc.getOrDefault(key("sk_class_" + cd.id), PersistentDataType.DOUBLE, 0.0));
                if (v != 0) g.cls.merge(cd.id, v, Integer::sum);
            }
            for (SkillDef sd : skills.values()) {
                int v = (int) Math.round(pdc.getOrDefault(key("sk_lv_" + sd.id), PersistentDataType.DOUBLE, 0.0));
                if (v != 0) g.lv.merge(sd.id, v, Integer::sum);
                if (sd.kind.equals("aura")) {
                    int a = (int) Math.round(pdc.getOrDefault(key("au_" + sd.id), PersistentDataType.DOUBLE, 0.0));
                    if (a > 0) g.aura.merge(sd.id, a, Integer::sum);
                }
            }
            for (ProcDef pd : procs.values()) {
                int v = (int) Math.round(pdc.getOrDefault(key("pr_" + pd.id), PersistentDataType.DOUBLE, 0.0));
                if (v > 0) g.proc.merge(pd.id, v, Integer::sum);
            }
        }
        gearCache.put(p.getUniqueId(), new Object[]{tick, g});
        return g;
    }

    /** 스킬의 현재 유효 레벨 (투자 포인트 + 장비 보너스 + 전투 명령 같은 버프). 투자하지 않았으면 0. */
    private int level(Player p, PData d, SkillDef s) {
        int base = d.levels.getOrDefault(s.id, 0);
        if (base <= 0) return 0;
        Gear g = gearOf(p);
        int bonus = g.lv.getOrDefault(s.id, 0);
        if (!s.classId.isEmpty() && s.classId.equals(d.cls)) {
            bonus += g.all + g.cls.getOrDefault(s.classId, 0) + (int) Math.round(buffSum(p, "모든 스킬"));
        }
        return Math.max(1, base + bonus);
    }

    /** 활성 버프/오라가 주는 특정 옵션 합. (level() 에서 쓰므로 cached()를 부르지 않는다: 순환 방지) */
    private double buffSum(Player p, String optionName) {
        long now = System.currentTimeMillis();
        return buffSumIn(buffs.get(p.getUniqueId()), optionName, now)
                + buffSumIn(auraBuffs.get(p.getUniqueId()), optionName, now);
    }

    private double buffSumIn(Map<String, Buff> map, String optionName, long now) {
        if (map == null) return 0.0;
        double sum = 0.0;
        for (Buff b : map.values()) {
            if (b.until < now) continue;
            SkillDef s = skills.get(b.id);
            if (s == null) continue;
            ConfigurationSection bs = s.sec.getConfigurationSection("bonuses");
            if (bs == null || !bs.isSet(optionName)) continue;
            sum += scaled(bs, optionName, b.level, 0.0);
        }
        return sum;
    }

    // ===================================================================
    //  패시브 / 버프 / 오라 -> 합성 PDC (기존 전투 계산에 합산)
    // ===================================================================

    private boolean isWeapon(Material m) {
        String n = m.name();
        return n.endsWith("_SWORD") || n.endsWith("_AXE") || m == Material.MACE || m == Material.TRIDENT;
    }

    private boolean holdingWeaponType(Player p, String type) {
        Material m = p.getInventory().getItemInMainHand().getType();
        String n = m.name();
        return switch (type) {
            case "sword" -> n.endsWith("_SWORD");
            case "axe" -> n.endsWith("_AXE");
            case "mace" -> m == Material.MACE;
            case "throwing" -> plugin.throwSystem() != null && plugin.throwSystem().isThrowing(p.getInventory().getItemInMainHand());
            case "spear" -> isSpearHeld(p);
            case "bow" -> isBowHeld(p);
            default -> false;
        };
    }

    /** 0.16.0: bonuses 의 옵션 값(stat 이름이 옵션 이름)에 시너지를 적용한다. val() 과 같은 규칙. */
    private double synBonus(Player p, SkillDef s, String stat, double v) {
        if (s.syn.isEmpty()) return v;
        PData d = data(p);
        double pctSum = 0.0;
        for (Syn sy : s.syn) {
            if (!sy.stat.equals(stat)) continue;
            SkillDef src = skills.get(sy.skill);
            if (src == null) continue;
            int sl = level(p, d, src);
            if (sl <= 0) continue;
            if (sy.pct) pctSum += sy.per * sl;
            else v += sy.per * sl;
        }
        return pctSum != 0.0 ? v * (1.0 + pctSum / 100.0) : v;
    }

    private void addBonuses(Player p, Map<String, Double> totals, SkillDef s, int lv) {
        String wt = s.sec.getString("weapon", "");
        if (!wt.isEmpty() && !holdingWeaponType(p, wt)) return;
        ConfigurationSection b = s.sec.getConfigurationSection("bonuses");
        if (b == null) return;
        double defScale = plugin.getConfig().getDouble("skill-system.defense-scale", 0.2);
        for (String name : b.getKeys(false)) {
            double v = synBonus(p, s, name, scaled(b, name, lv, 0.0));
            if (name.equals("방어력 증가")) v *= defScale; // 원작 "방어력 %"는 피해 감소 %보다 훨씬 커서 비율을 곱한다
            if (v != 0) totals.merge(name, v, Double::sum);
        }
    }

    private void addBuffMap(Player p, Map<String, Double> totals, Map<String, Buff> map, long now) {
        if (map == null) return;
        for (Buff b : map.values()) {
            if (b.until < now) continue;
            SkillDef s = skills.get(b.id);
            if (s != null) addBonuses(p, totals, s, b.level);
        }
    }

    private Cached cached(Player p) {
        int tick = tickCounter;
        Cached c = bonusCache.get(p.getUniqueId());
        if (c != null && c.tick == tick) return c;

        Map<String, Double> totals = new LinkedHashMap<>();
        if (enabled()) {
            PData d = data(p);
            long now = System.currentTimeMillis();
            for (SkillDef s : skills.values()) {
                if (!s.kind.equals("passive")) continue;
                int lv = level(p, d, s);
                if (lv > 0) addBonuses(p, totals, s, lv);
            }
            addBuffMap(p, totals, buffs.get(p.getUniqueId()), now);
            addBuffMap(p, totals, auraBuffs.get(p.getUniqueId()), now);

            Frenzy f = frenzy.get(p.getUniqueId());
            if (f != null && f.until >= now && f.stacks > 0) {
                SkillDef fs = skills.get(f.skillId);
                if (fs != null) {
                    double max = scaled(fs.sec, "attack-speed-max", f.level, 0.0);
                    int cap = Math.max(1, fs.sec.getInt("stack-max", 5));
                    double v = max * Math.min(f.stacks, cap) / cap;
                    totals.merge("공격 속도 증가", v, Double::sum);
                    totals.merge("이동 속도", v * 0.5, Double::sum);
                }
            }
            Map<String, Frenzy> fst = formStacks.get(p.getUniqueId());
            if (fst != null) {
                for (Frenzy ff : fst.values()) {
                    SkillDef fs = skills.get(ff.skillId);
                    if (fs == null || ff.until < now || ff.stacks <= 0) continue;
                    ConfigurationSection sb = fs.sec.getConfigurationSection("stack-bonuses");
                    if (sb == null) continue;
                    int cap = Math.max(1, (int) scaled(fs.sec, "stack-max", ff.level, 5.0));
                    for (String k : sb.getKeys(false)) {
                        totals.merge(k, scaled(sb, k, ff.level, 0.0) * Math.min(ff.stacks, cap) / cap, Double::sum);
                    }
                }
            }
            if (tempBonus != null && p.getUniqueId().equals(tempOwner)) {
                for (Map.Entry<String, Double> tb : tempBonus.entrySet()) totals.merge(tb.getKey(), tb.getValue(), Double::sum);
            }
            double defCap = plugin.getConfig().getDouble("skill-system.defense-cap", 60.0);
            Double def = totals.get("방어력 증가");
            if (def != null && def > defCap) totals.put("방어력 증가", defCap);
        }
        PersistentDataContainer pdc = null;
        if (!totals.isEmpty()) {
            ItemMeta scratch = new ItemStack(Material.STONE).getItemMeta();
            for (Map.Entry<String, Double> t : totals.entrySet()) {
                plugin.applyOptionToPdc(scratch, t.getKey(), (int) Math.round(t.getValue()));
            }
            pdc = scratch.getPersistentDataContainer();
        }
        c = new Cached(tick, pdc, totals);
        bonusCache.put(p.getUniqueId(), c);
        return c;
    }

    /** 전투/능력치 계산에 합산할 스킬 보너스 PDC. 없으면 null. */
    PersistentDataContainer bonusPdc(Player p) {
        return cached(p).pdc;
    }

    /** 스킬이 주는 최대 마나 % (전투 지시). StatSystem 이 최대 마나 계산에 쓴다. */
    double manaPct(Player p) {
        return cached(p).totals.getOrDefault("최대 마나%", 0.0);
    }

    private void refreshAttributes(Player p) {
        Map<String, Double> t = cached(p).totals;
        setModifier(p, VersionCompat.MAX_HEALTH, "skill_maxhealth", t.getOrDefault("최대 생명력", 0.0),
                AttributeModifier.Operation.ADD_NUMBER);
        setModifier(p, VersionCompat.MAX_HEALTH, "skill_maxhealth_pct", t.getOrDefault("최대 생명력%", 0.0) / 100.0,
                AttributeModifier.Operation.MULTIPLY_SCALAR_1);
        setModifier(p, VersionCompat.ATTACK_SPEED, "skill_atkspeed", 4.0 * t.getOrDefault("공격 속도 증가", 0.0) / 100.0,
                AttributeModifier.Operation.ADD_NUMBER);
        setModifier(p, VersionCompat.MOVEMENT_SPEED, "skill_movespeed", t.getOrDefault("이동 속도", 0.0) / 100.0,
                AttributeModifier.Operation.MULTIPLY_SCALAR_1);
    }

    private void setModifier(Player p, Attribute attribute, String keyName, double amount,
                             AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attribute);
        if (inst == null) return;
        NamespacedKey k = key(keyName);
        AttributeModifier existing = null;
        for (AttributeModifier m : new ArrayList<>(inst.getModifiers())) {
            if (k.equals(m.getKey())) {
                existing = m;
                break;
            }
        }
        if (existing != null) {
            if (existing.getAmount() == amount && existing.getOperation() == op) return;
            inst.removeModifier(existing);
        }
        if (amount != 0.0) inst.addModifier(VersionCompat.mod(k, amount, op));
    }

    // ===================================================================
    //  주기 작업
    // ===================================================================

    /** 0.5초: 레벨 추적, 속성 갱신, 만료 정리 */
    private void fastTick() {
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            PData d = data(p);
            if (p.getLevel() > d.maxLevel) {
                d.maxLevel = p.getLevel();
                save(p);
            }
            expire(buffs.get(p.getUniqueId()), now);
            expire(auraBuffs.get(p.getUniqueId()), now);
            Frenzy f = frenzy.get(p.getUniqueId());
            if (f != null && f.until < now) frenzy.remove(p.getUniqueId());
            bonusCache.remove(p.getUniqueId());
            refreshAttributes(p);
        }
        converted.values().removeIf(t -> t < now);
        leapGuard.values().removeIf(t -> t < now);
        feared.values().removeIf(t -> t < now);
    }

    private void expire(Map<String, Buff> map, long now) {
        if (map == null) return;
        map.values().removeIf(b -> b.until < now);
    }

    /** 1초: 오라 적용/피해, 저주 정리/표시 */
    private void slowTick() {
        long now = System.currentTimeMillis();
        necroTick();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isDead()) continue;
            PData d = data(p);
            Map<String, Integer> auras = new HashMap<>(gearOf(p).aura);
            if (d.activeAura != null) {
                SkillDef s = skills.get(d.activeAura);
                if (s != null && s.kind.equals("aura")) {
                    int lv = level(p, d, s);
                    if (lv > 0) auras.merge(s.id, lv, Math::max);
                }
            }
            if (auras.isEmpty()) fxAuras.remove(p.getUniqueId());
            else fxAuras.put(p.getUniqueId(), new HashMap<>(auras));
            for (Map.Entry<String, Integer> a : auras.entrySet()) {
                SkillDef s = skills.get(a.getKey());
                if (s == null) continue;
                runAura(p, s, a.getValue(), now);
            }
        }

        cloudTick();

        Iterator<Map.Entry<UUID, Map<String, Curse>>> it = curses.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Map<String, Curse>> e = it.next();
            Entity ent = Bukkit.getEntity(e.getKey());
            e.getValue().values().removeIf(c -> c.until < now);
            if (ent == null || !ent.isValid() || ent.isDead() || e.getValue().isEmpty()) {
                it.remove();
                continue;
            }
        }
    }

    private void runAura(Player p, SkillDef s, int lv, long now) {
        double radius = radius(p, s, lv, 10.0);
        boolean selfOnly = s.sec.getBoolean("self-only", false);
        List<Player> recipients = new ArrayList<>();
        recipients.add(p);
        if (!selfOnly) {
            for (Entity e : p.getNearbyEntities(radius, radius, radius)) {
                if (e instanceof Player o && !o.isDead() && o.getLocation().distanceSquared(p.getLocation()) <= radius * radius) {
                    recipients.add(o);
                }
            }
        }
        if (s.sec.isConfigurationSection("bonuses") || s.sec.contains("thorns-pct")) {
            for (Player r : recipients) {
                Map<String, Buff> map = auraBuffs.computeIfAbsent(r.getUniqueId(), k -> new HashMap<>());
                Buff old = map.get(s.id);
                if (old == null || old.until < now || old.level <= lv) {
                    map.put(s.id, new Buff(s.id, lv, now + 2500L));
                }
            }
        }

        double dmg = val(p, s, "damage", lv, 0.0);
        double slowAmp = val(p, s, "slow-amp", lv, 0.0);
        double auraKb = val(p, s, "knockback", lv, 0.0);
        boolean undeadOnly = s.sec.getBoolean("undead-only", false);
        boolean auraCurse = s.sec.isConfigurationSection("curse");
        if (dmg > 0 || slowAmp > 0 || auraKb > 0 || auraCurse) {
            for (LivingEntity t : around(p.getLocation(), radius, p)) {
                if (undeadOnly && !plugin.isUndead(t)) continue;
                if (dmg > 0) pureHit(p, t, dmg);
                if (auraKb > 0 && t.isValid() && !t.isDead()) knock(p.getLocation(), t, auraKb);
                if (auraCurse && t.isValid() && !t.isDead()) applyCurse(t, s, lv);
                if (slowAmp > 0 && t.isValid() && !t.isDead()) {
                    t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, (int) Math.max(0, slowAmp - 1), false, false));
                }
            }
        }
    }

    // ===================================================================
    //  저주 (몹에 붙는 상태)
    // ===================================================================

    /**
     * 대상에 걸린 저주 수치.
     * type: amplify(물리 피해 증가) / lower_resist(저항 감소) / weaken(몹 피해 감소) / reflect(반사) / defense_down(대상 방어력 감소)
     * 없으면 0.
     */
    double curseAmount(Entity e, String type) {
        Map<String, Curse> m = curses.get(e.getUniqueId());
        if (m == null) return 0.0;
        Curse c = m.get(type);
        if (c == null || c.until < System.currentTimeMillis()) return 0.0;
        return c.amount;
    }

    private void applyCurse(LivingEntity t, SkillDef s, int lv) {
        for (String section : new String[]{"curse", "curse2", "curse3"}) {
            ConfigurationSection c = s.sec.getConfigurationSection(section);
            if (c == null) continue;
            String type = c.getString("type", "amplify");
            double amount = scaled(c, "amount", lv, 0.0);
            double durSec = scaled(c, "duration", lv, 6.0);
            long now = System.currentTimeMillis();
            long until = now + (long) (durSec * 1000.0);
            if (s.sec.getBoolean("glow", false)) { // 내면의 시야 / 투사체 감속: 맞은 적이 빛난다
                t.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, (int) (durSec * 20), 0, false, false));
            }
            if (type.equals("slow")) {
                t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (durSec * 20), (int) Math.max(0, amount - 1), false, true));
                continue;
            }
            Map<String, Curse> m = curses.computeIfAbsent(t.getUniqueId(), k -> new HashMap<>());
            Curse old = m.get(type);
            if (old != null && old.until >= now && old.amount > amount) {
                m.put(type, new Curse(old.amount, Math.max(old.until, until))); // 더 강한 저주는 유지하고 시간만 연장
            } else {
                m.put(type, new Curse(amount, until));
            }
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onCursedMobHit(EntityDamageByEntityEvent e) {
        LivingEntity attacker = mobAttacker(e.getDamager());
        if (attacker == null) return;
        double w = curseAmount(attacker, "weaken");
        if (w > 0) e.setDamage(e.getDamage() * Math.max(0.1, 1.0 - w / 100.0));
        if (e.getDamager() instanceof Projectile) { // 0.17.0: 투사체 감속 - 날아온 물리 피해 감소
            double md = curseAmount(attacker, "missile_dmg");
            if (md > 0) e.setDamage(e.getDamage() * Math.max(0.1, 1.0 - md / 100.0));
        }
    }

    /** 0.17.0: 투사체 감속 - 저주에 걸린 몹이 쏜 투사체는 느려진다. */
    @EventHandler(ignoreCancelled = true)
    public void onMobShoot(ProjectileLaunchEvent e) {
        Projectile pr = e.getEntity();
        if (!(pr.getShooter() instanceof LivingEntity sh) || sh instanceof Player) return;
        double slow = curseAmount(sh, "missile_slow");
        if (slow <= 0) return;
        pr.setVelocity(pr.getVelocity().multiply(Math.max(0.1, 1.0 - slow / 100.0)));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCursedMobReflect(EntityDamageByEntityEvent e) {
        if (reflecting) return;
        LivingEntity attacker = mobAttacker(e.getDamager());
        if (attacker == null) return;
        double r = curseAmount(attacker, "reflect");
        if (r <= 0) return;
        double dealt = e.getFinalDamage();
        if (dealt <= 0) return;
        reflecting = true;
        try {
            attacker.damage(dealt * r / 100.0);
        } finally {
            reflecting = false;
        }
    }

    /** 0.15.0: 켜져 있는 오라가 주는 key 수치 합 (예: 가시 오라의 thorns-pct). */
    private double auraSum(Player p, String key) {
        Map<String, Buff> m = auraBuffs.get(p.getUniqueId());
        if (m == null) return 0.0;
        long now = System.currentTimeMillis();
        double sum = 0.0;
        for (Buff b : m.values()) {
            if (b.until < now) continue;
            SkillDef sd = skills.get(b.id);
            if (sd == null || !sd.sec.contains(key)) continue;
            sum += scaled(sd.sec, key, b.level, 0.0);
        }
        return sum;
    }

    /** 가시 오라: 몹에게 근접 공격을 맞으면 받은 피해의 일부를 공격자에게 되돌린다. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onThornsReflect(EntityDamageByEntityEvent e) {
        if (reflecting || !(e.getEntity() instanceof Player victim)) return;
        if (!(e.getDamager() instanceof LivingEntity attacker) || attacker instanceof Player) return;
        double pct = auraSum(victim, "thorns-pct");
        if (pct <= 0) return;
        double dealt = e.getFinalDamage();
        if (dealt <= 0 || attacker.isDead()) return;
        reflecting = true;
        try {
            attacker.damage(dealt * pct / 100.0);
        } finally {
            reflecting = false;
        }
    }

    private LivingEntity mobAttacker(Entity damager) {
        if (damager instanceof Player) return null;
        if (damager instanceof LivingEntity le) return le;
        if (damager instanceof Projectile pr && pr.getShooter() instanceof LivingEntity sh && !(sh instanceof Player)) return sh;
        return null;
    }

    /** 공포에 걸린 몹은 도망치는 동안 플레이어를 목표로 삼지 않는다. */
    @EventHandler(ignoreCancelled = true)
    public void onMobTarget(EntityTargetEvent e) {
        if (e.getTarget() == null) return;
        if (isSummonEntity(e.getEntity())) { // 소환수는 플레이어와 다른 소환수를 노리지 않는다
            if (e.getTarget() instanceof Player || isSummonEntity(e.getTarget())
                    || e.getTarget() instanceof Villager || e.getTarget() instanceof WanderingTrader) e.setCancelled(true);
            return;
        }
        Long until = feared.get(e.getEntity().getUniqueId());
        if (until != null && until > System.currentTimeMillis()) e.setCancelled(true);
        Long cv = converted.get(e.getEntity().getUniqueId());
        if (cv != null && cv > System.currentTimeMillis() && e.getTarget() instanceof Player) e.setCancelled(true);
        double dim = curseAmount(e.getEntity(), "dim_vision"); // 시야 흐림: 멀리 있는 플레이어는 노리지 못한다
        if (dim > 0 && e.getTarget() instanceof Player tp
                && tp.getLocation().distanceSquared(e.getEntity().getLocation()) > dim * dim) e.setCancelled(true);
    }

    // ===================================================================
    //  장비 발동 옵션 (타격 시 / 피격 시 확률로 스킬 시전)
    // ===================================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProcTrigger(EntityDamageByEntityEvent e) {
        if (!enabled() || casting || pure || reflecting) return;
        Entity dm = e.getDamager();
        Player attackerPlayer = null;
        if (dm instanceof Player pl) attackerPlayer = pl;
        else if (dm instanceof Projectile pr && pr.getShooter() instanceof Player pl2) attackerPlayer = pl2;

        if (attackerPlayer != null && e.getEntity() instanceof LivingEntity t && validTarget(attackerPlayer, t)) {
            runProcs(attackerPlayer, "hit", t);
        }
        if (e.getEntity() instanceof Player victim) {
            LivingEntity attacker = mobAttacker(dm);
            if (attacker != null && validTarget(victim, attacker)) runProcs(victim, "struck", attacker);
        }
    }

    private void runProcs(Player p, String trigger, LivingEntity target) {
        Gear g = gearOf(p);
        if (g.proc.isEmpty()) return;
        for (Map.Entry<String, Integer> en : g.proc.entrySet()) {
            ProcDef pd = procs.get(en.getKey());
            if (pd == null || !pd.trigger.equals(trigger)) continue;
            if (random.nextDouble() * 100.0 >= en.getValue()) continue;
            SkillDef s = skills.get(pd.cast);
            if (s == null) continue;
            castAt(p, s, pd.level, target);
            plugin.getLogger().info(String.format(Locale.ROOT, "[스킬 발동] %s | %s | %s %d레벨 (확률 %d%%) -> %s",
                    p.getName(), trigger.equals("hit") ? "타격 시" : "피격 시", s.name, pd.level, en.getValue(), target.getType().name()));
        }
    }

    /** 장비 발동용 시전: 마나/속도 제한 없이 대상 위치에서 효과만. */
    private void castAt(Player p, SkillDef s, int lv, LivingEntity target) {
        switch (s.kind) {
            case "curse" -> applyCurseArea(p, s, lv, target.getLocation());
            case "aoe" -> doAoe(p, s, lv, target.getLocation());
            case "buff" -> doBuff(p, s, lv);
            case "melee" -> hit(p, target, skillDamage(p, s, lv));
            default -> { }
        }
    }

    // ===================================================================
    //  대상 찾기 / 피해
    // ===================================================================

    private boolean validTarget(Player p, LivingEntity t) {
        if (t == p || t.isDead() || !t.isValid() || isSummonEntity(t)) return false;
        if (t instanceof Player) return plugin.getConfig().getBoolean("skill-system.hit-players", false);
        if (t instanceof ArmorStand || t instanceof Villager || t instanceof WanderingTrader) return false;
        if (t instanceof Tameable tm && tm.isTamed()) return false;
        return true;
    }

    private LivingEntity findTarget(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceEntities(eye, eye.getDirection(), range, 0.4,
                en -> en instanceof LivingEntity le && validTarget(p, le));
        if (r == null || !(r.getHitEntity() instanceof LivingEntity le)) return null;
        return le;
    }

    private List<LivingEntity> around(Location center, double radius, Player caster) {
        List<LivingEntity> list = new ArrayList<>();
        if (center.getWorld() == null) return list;
        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (e instanceof LivingEntity le && validTarget(caster, le)
                    && le.getLocation().distanceSquared(center) <= radius * radius) {
                list.add(le);
            }
        }
        return list;
    }

    private LivingEntity nearestOther(Player p, LivingEntity first, double radius) {
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity o : around(first.getLocation(), radius, p)) {
            if (o == first) continue;
            double d = o.getLocation().distanceSquared(first.getLocation());
            if (d < bestD) {
                bestD = d;
                best = o;
            }
        }
        return best;
    }

    /** 플레이어 공격력 속성(무기 포함). */
    private double attackPower(Player p) {
        AttributeInstance atk = p.getAttribute(VersionCompat.ATTACK_DAMAGE);
        return atk == null ? 1.0 : Math.max(1.0, atk.getValue());
    }

    /** 스킬 피해 = 공격력 x damage-pct% + flat-damage. 이후 기존 파이프라인이 % 증가/저항 등을 적용한다. */
    private double skillDamage(Player p, SkillDef s, int lv) {
        double base = attackPower(p) * val(p, s, "damage-pct", lv, 100.0) / 100.0 + val(p, s, "flat-damage", lv, 0.0);
        if (s.kind.equals("throw") || s.kind.equals("arrow")) { // 0.17.0: 간파 (원거리 피해 증가)
            base *= 1.0 + passiveSum(p, "ranged-damage-pct") / 100.0;
        }
        return base;
    }

    private void hit(Player p, LivingEntity t, double dmg) {
        if (t.isDead() || !t.isValid()) return;
        boolean prev = casting;
        casting = true;
        try {
            t.setNoDamageTicks(0);
            t.setLastDamage(0.0); // 0.7.2: 연타 때 '직전 피해와의 차이만 적용' 규칙으로 피해가 깎이는 것을 막는다
            double before = t.getHealth();
            t.damage(dmg, p);
            if (plugin.getConfig().getBoolean("skill-system.debug", false)) {
                plugin.getLogger().info(String.format(Locale.ROOT, "[스킬 피해] %s -> %s | 요청 %.1f | 체력 변화 %.1f | 직전피해 %.1f",
                        p.getName(), t.getType().name(), dmg, before - t.getHealth(), t.getLastDamage()));
            }
        } finally {
            casting = prev;
        }
    }

    private void pureHit(Player p, LivingEntity t, double dmg) {
        if (t.isDead() || !t.isValid()) return;
        boolean prevPure = pure;
        boolean prevCasting = casting;
        pure = true;
        casting = true;
        try {
            t.setNoDamageTicks(0);
            t.setLastDamage(0.0); // 0.7.2: 연타 때 '직전 피해와의 차이만 적용' 규칙으로 피해가 깎이는 것을 막는다
            t.damage(dmg, p);
        } finally {
            pure = prevPure;
            casting = prevCasting;
        }
    }

    private void knock(Location from, LivingEntity t, double power) {
        if (power <= 0 || t.isDead()) return;
        Vector v = t.getLocation().toVector().subtract(from.toVector());
        v.setY(0);
        if (v.lengthSquared() < 0.0001) return;
        v.normalize().multiply(power).setY(0.3);
        t.setVelocity(t.getVelocity().add(v));
    }

    private void stun(LivingEntity t, double seconds) {
        if (seconds <= 0 || t.isDead()) return;
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (seconds * 20), 6, false, true));
    }

    // ===================================================================
    //  스킬 시전
    // ===================================================================

    private void msg(Player p, String text) {
        plugin.statSystem().notice(p, text);
    }

    /** 스킬을 쓸 수 있는 자세인가: 무기가 1번 칸이고 손에 들고 있는 RPG 무기. */
    private boolean weaponReady(Player p) {
        if (!enabled()) return false;
        if (plugin.getConfig().getBoolean("skill-system.require-slot-one", true)
                && p.getInventory().getHeldItemSlot() != 0) return false;
        if (plugin.getConfig().getBoolean("skill-system.require-rpg-weapon", true)
                && !isRpg(p.getInventory().getItemInMainHand())) return false;
        return true;
    }

    /** 공격 속도(초당 공격 횟수)로 정해지는 공격 스킬 간 최소 간격(ms). */
    private long swingIntervalMs(Player p) {
        AttributeInstance a = p.getAttribute(VersionCompat.ATTACK_SPEED);
        double rate = a == null ? 4.0 : Math.max(0.1, a.getValue());
        return Math.max(100L, Math.min(2000L, (long) (1000.0 / rate)));
    }

    /** 스킬에 커스텀 소리(sounds)가 설정돼 있는가. */
    private boolean hasCustomSound(SkillDef s) {
        return !s.sec.getStringList("sounds").isEmpty();
    }

    /** 시전 시작 소리: sounds 목록에서 무작위로 하나(리소스팩 소리 키). 없으면 기본 효과음. */
    private void playCastSound(Player p, SkillDef s) {
        List<String> list = s.sec.getStringList("sounds");
        if (list.isEmpty()) {
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_EVOKER_PREPARE_ATTACK, 0.7f, 1.2f);
            return;
        }
        String key = list.get(random.nextInt(list.size()));
        float vol = (float) s.sec.getDouble("sound-volume", 1.0);
        float pitch = (float) s.sec.getDouble("sound-pitch", 1.0);
        p.getWorld().playSound(p.getLocation(), key, org.bukkit.SoundCategory.PLAYERS, vol, pitch);
    }

    private Result tryCast(Player p, SkillDef s, LivingEntity forced, boolean quiet) {
        PData d = data(p);
        int lv = level(p, d, s);
        if (lv <= 0) {
            if (!quiet) msg(p, ChatColor.RED + s.name + "을(를) 배우지 않았습니다.");
            return Result.FAIL;
        }
        if (s.kind.equals("passive")) return Result.FAIL;
        if (s.kind.equals("display")) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 아직 효과가 없는 스킬입니다. (표시만)");
            return Result.FAIL;
        }

        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        String formNow = formOf(p);
        String needForm = s.sec.getString("requires-form", "");
        if (!needForm.isEmpty() && (formNow == null || (!needForm.equals("any") && !needForm.equals(formNow)))) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": " + (needForm.equals("bear") ? "곰인간" : needForm.equals("wolf") ? "늑대인간" : "늑대인간이나 곰인간")
                    + " 상태에서만 쓸 수 있습니다.");
            return Result.FAIL;
        }
        if (formNow != null && needForm.isEmpty() && !s.kind.equals("form") && !s.sec.getBoolean("form-ok", false)) {
            if (!quiet) msg(p, ChatColor.RED + "변신 중에는 쓸 수 없습니다. (변신 스킬을 다시 쓰면 풀림)");
            return Result.FAIL;
        }
        String curLock = locks.get(id);
        if (curLock != null && !s.lock.isEmpty() && curLock.equals(s.lock)) return Result.WAIT;
        Long cu = castingUntil.get(id);
        if (cu != null && cu > now) return Result.WAIT;
        long cdLeft = cooldownLeft(p, s);
        if (cdLeft > 0L) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 재사용 대기 " + fmt(cdLeft / 1000.0) + "초");
            return Result.WAIT;
        }
        if (s.speed.equals("attack")) {
            Long ns = nextSwing.get(id);
            if (ns != null && ns > now) return Result.WAIT;
        }

        StatSystem ss = plugin.statSystem();
        StatSystem.Stats st = ss.collect(p);
        double max = ss.maxMana(st);
        double cur = ss.getMana(p);
        if (cur < 0) cur = max;
        double cost = val(p, s, "mana", lv, 0.0);
        if (cost > 0 && cur < cost) {
            if (!quiet) msg(p, ChatColor.AQUA + "마나가 부족합니다. (" + (int) Math.ceil(cost) + " 필요)");
            return Result.FAIL;
        }

        if (s.speed.equals("cast")) {
            double base = s.sec.contains("cast-seconds") ? s.sec.getDouble("cast-seconds", 0.8)
                    : plugin.getConfig().getDouble("skill-system.cast-time", 0.8); // 스킬별 시전 지연(cast-seconds)이 우선
            double fcr = gearOf(p).castSpeed;
            long delayMs = (long) (base * 1000.0 / (1.0 + fcr / 100.0));
            if (delayMs > 50L) {
                castingUntil.put(id, now + delayMs);
                startCooldown(p, s);
                if (cost > 0) ss.setMana(p, cur - cost);
                msg(p, ChatColor.GOLD + s.name + ChatColor.GRAY + " 시전 중...");
                playCastSound(p, s);
                final int lvF = lv;
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    castingUntil.remove(id);
                    if (!p.isOnline() || p.isDead()) return;
                    execute(p, s, lvF, null, true);
                }, Math.max(1L, delayMs / 50L));
                return Result.OK;
            }
        }

        if (s.speed.equals("cast")) playCastSound(p, s);
        if (!execute(p, s, lv, forced, quiet)) return Result.FAIL;

        if (cost > 0) ss.setMana(p, cur - cost);
        startCooldown(p, s);
        if (s.speed.equals("attack")) nextSwing.put(id, now + swingIntervalMs(p));
        msg(p, ChatColor.GOLD + s.name + ChatColor.GRAY + " Lv" + lv
                + (cost > 0 ? ChatColor.AQUA + "  마나 -" + (int) Math.ceil(cost) : ""));
        return Result.OK;
    }

    private boolean execute(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        return switch (s.kind) {
            case "melee" -> doMelee(p, s, lv, forced, quiet);
            case "aoe" -> {
                doAoe(p, s, lv, p.getLocation());
                yield true;
            }
            case "fear" -> doFear(p, s, lv);
            case "whirlwind" -> doWhirlwind(p, s, lv);
            case "throw" -> doThrow(p, s, lv, forced, quiet);
            case "bolt" -> doBolt(p, s, lv, forced, quiet);
            case "hammer" -> doHammer(p, s, lv);
            case "fist" -> doFist(p, s, lv, forced, quiet);
            case "leap" -> doLeap(p, s, lv);
            case "leap_attack" -> doLeapAttack(p, s, lv, forced, quiet);
            case "charge" -> doCharge(p, s, lv, forced, quiet);
            case "convert" -> doConvert(p, s, lv, forced, quiet);
            case "arrow" -> doArrow(p, s, lv, forced, quiet);
            case "buff" -> {
                doBuff(p, s, lv);
                yield true;
            }
            case "curse" -> doCurse(p, s, lv, forced, quiet);
            case "aura" -> doAuraToggle(p, s);
            case "missile" -> doMissile(p, s, lv, forced, quiet);
            case "corpse" -> doCorpse(p, s, lv, forced, quiet);
            case "shield" -> doShield(p, s, lv);
            case "wall" -> doWall(p, s, lv, forced, quiet);
            case "raise" -> doRaise(p, s, lv, forced, quiet);
            case "golem" -> doGolem(p, s, lv, forced, quiet);
            case "nova" -> doNova(p, s, lv);
            case "chain" -> doChain(p, s, lv, forced, quiet);
            case "static" -> doStatic(p, s, lv);
            case "telekinesis" -> doTelekinesis(p, s, lv, forced, quiet);
            case "teleport" -> doTeleport(p, s, lv, forced, quiet);
            case "eshield" -> doEShield(p, s, lv);
            case "storm" -> doStorm(p, s, lv);
            case "blizzard" -> doBlizzard(p, s, lv, forced, quiet);
            case "orb" -> doOrb(p, s, lv);
            case "coldarmor" -> doColdArmor(p, s, lv);
            case "inferno" -> doInferno(p, s, lv);
            case "blaze" -> doBlaze(p, s, lv);
            case "firewall" -> doFireWall(p, s, lv, forced, quiet);
            case "enchant" -> doEnchant(p, s, lv);
            case "meteor" -> doMeteor(p, s, lv, forced, quiet);
            case "hydra" -> doHydra(p, s, lv, forced, quiet);
            case "decoy" -> doDecoy(p, s, lv, forced, quiet);
            case "valkyrie" -> doValkyrie(p, s, lv, forced, quiet);
            case "shockweb" -> doShockWeb(p, s, lv, forced, quiet);
            case "bladesent" -> doBladeSentinel(p, s, lv, forced, quiet);
            case "bladefury" -> doBladeFury(p, s, lv, forced, quiet);
            case "animal" -> doAnimal(p, s, lv, forced, quiet);
            case "spirit" -> doSpirit(p, s, lv, forced, quiet);
            case "raven" -> {
                doRaven(p, s, lv);
                yield true;
            }
            case "plant" -> doPlant(p, s, lv, forced, quiet);
            case "form" -> doForm(p, s, lv);
            case "shockwave" -> doShockWave(p, s, lv);
            case "firestorm" -> doFirestorm(p, s, lv);
            case "molten" -> doMolten(p, s, lv, forced);
            case "arctic" -> doArctic(p, s, lv);
            case "fissure" -> doFissure(p, s, lv, forced, quiet);
            case "cyclone" -> doCycloneArmor(p, s, lv);
            case "twister" -> doTwister(p, s, lv);
            case "volcano" -> doVolcano(p, s, lv, forced, quiet);
            case "tornado" -> doTornado(p, s, lv);
            case "armageddon" -> doArmageddon(p, s, lv);
            case "hurricane" -> doHurricane(p, s, lv);
            case "bladeshield" -> doBladeShield(p, s, lv);
            case "sentry" -> doSentry(p, s, lv, forced, quiet);
            case "cloak" -> doCloak(p, s, lv);
            case "psychic" -> doPsychic(p, s, lv, forced, quiet);
            case "mindblast" -> doMindBlast(p, s, lv);
            case "shadow" -> doShadow(p, s, lv);
            case "mcharge" -> doMCharge(p, s, lv, forced, quiet);
            case "kick" -> doKick(p, s, lv, forced, quiet);
            case "dualstrike" -> doDualStrike(p, s, lv, forced, quiet);
            case "flight" -> doFlight(p, s, lv, forced, quiet);
            default -> false;
        };
    }

    private void unlock(Player p, String group) {
        if (group.equals(locks.get(p.getUniqueId()))) locks.remove(p.getUniqueId());
    }

    // ===================================================================
    //  0.14.0: 투척 (kind: throw)  [미검증]
    //   손(1번 칸)에 투척 무기를 들고 있어야 하고, 던질 때마다 수량이 hits(기본 1)만큼 준다.
    //   날아가는 모습은 ItemDisplay, 맞았는지는 서버가 직접 광선으로 판정한다 (바닐라 투사체 피해를 쓰지 않는다).
    // ===================================================================

    private boolean doThrow(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        ThrowSystem ts = plugin.throwSystem();
        ItemStack held = p.getInventory().getItemInMainHand();
        if (ts == null || !ts.isThrowing(held)) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": 투척 무기를 손에 들어야 합니다.");
            return false;
        }
        int have = ts.quantity(held);
        if (have <= 0) {
            msg(p, ChatColor.RED + "투척 무기 수량이 0입니다. 상점에서 수리하세요.");
            return false;
        }

        // 던지는 개수. offhand-throw 스킬(이중 투척)은 왼손에도 투척 무기가 있으면 오른손 하나 + 왼손 하나를 던진다.
        // 왼손에 없으면 오른손 무기를 연달아 던진다.
        final int want = Math.max(1, s.sec.getInt("hits", 1));
        ItemStack off = p.getInventory().getItemInOffHand();
        final boolean useOff = want >= 2 && s.sec.getBoolean("offhand-throw", false)
                && ts.isThrowing(off) && ts.quantity(off) > 0;
        final int mainUse = Math.min(want - (useOff ? 1 : 0), have);
        final int count = mainUse + (useOff ? 1 : 0);

        final double range = val(p, s, "range", lv, 20.0);
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        final double dmg = skillDamage(p, s, lv);
        // 왼손 무기의 피해: 오른손 무기 대비 기본 피해 비율로 환산 (옵션/숙련 증가분도 같은 비율로 적용)
        final double mainBase = Math.max(1.0, ts.baseDamage(held));
        final double offDmg = useOff ? dmg * Math.max(1.0, ts.baseDamage(off)) / mainBase : dmg;

        List<LivingEntity> aim = new ArrayList<>();
        aim.add(t);
        if (count > 1) {
            LivingEntity second = (t != null && s.sec.getBoolean("dual-targets", false)) ? nearestOther(p, t, 4.0) : null;
            for (int i = 1; i < count; i++) aim.add(second != null ? second : t);
        }

        final ItemStack mainVisual = held.clone();
        mainVisual.setAmount(1);
        final ItemStack offVisual = useOff ? off.clone() : null;
        if (offVisual != null) offVisual.setAmount(1);
        ts.consume(p, mainUse);
        if (useOff) ts.consumeOffHand(p, 1);

        // 순서: 오른손 ... 그다음 왼손 (왼손은 마지막 번째)
        for (int i = 0; i < count; i++) {
            final LivingEntity target = aim.get(i);
            final int idx = i;
            final boolean fromOff = useOff && i == count - 1;
            Runnable r = () -> {
                if (!p.isOnline() || p.isDead()) return;
                launchThrown(p, fromOff ? offVisual : mainVisual, target, idx, count, fromOff ? offDmg : dmg, range, s, lv);
            };
            if (i == 0) r.run();
            else Bukkit.getScheduler().runTaskLater(plugin, r, 3L * i);
        }
        return true;
    }

    private void launchThrown(Player p, ItemStack visual, LivingEntity target, int idx, int count,
                              double dmg, double range, SkillDef s, int lv) {
        final World w = p.getWorld();
        Location eye = p.getEyeLocation();
        Vector dir;
        if (target != null && target.isValid() && !target.isDead()) {
            Location aimLoc = target.getLocation().add(0, target.getHeight() * 0.6, 0);
            dir = aimLoc.toVector().subtract(eye.toVector());
            if (dir.lengthSquared() < 0.0001) dir = eye.getDirection();
        } else {
            dir = eye.getDirection();
            if (count > 1) { // 대상이 없으면 좌우로 살짝 퍼뜨린다
                double off = (idx - (count - 1) / 2.0) * 0.12;
                Vector right = dir.clone().crossProduct(new Vector(0, 1, 0));
                if (right.lengthSquared() > 1.0E-6) {
                    right.normalize();
                    dir = dir.clone().add(right.multiply(off));
                }
            }
        }
        dir = dir.clone().normalize();
        final Vector d = dir;
        final Location pos = eye.clone().add(d.clone().multiply(0.6)).subtract(0, 0.15, 0);
        pos.setDirection(d);

        final ItemDisplay disp = w.spawn(pos, ItemDisplay.class);
        disp.setItemStack(visual);
        disp.setPersistent(false);
        w.playSound(eye, Sound.ENTITY_SNOWBALL_THROW, 1.0f, 1.2f);

        final double speed = Math.max(0.3, plugin.getConfig().getDouble("throwing.speed", 1.6));
        final double[] traveled = {0.0};
        final double[] trailAcc = {0.0};
        final Set<UUID> struck = new HashSet<>();
        final double pierceChance = Math.min(100.0, passiveSum(p, "pierce-chance")); // 0.17.0: 관통
        final double trailGap = s != null && s.sec.contains("trail-spacing-yd") ? Math.max(0.5, val(p, s, "trail-spacing-yd", lv, 2.0) * lengthScale()) : 0.0;
        final BukkitTask[] task = new BukkitTask[1];
        task[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!disp.isValid() || !p.isOnline()) {
                disp.remove();
                task[0].cancel();
                return;
            }
            double step = Math.min(speed, range - traveled[0]);
            if (step <= 0.0) {
                throwOnEnd(p, s, lv, pos.clone());
                disp.remove();
                task[0].cancel();
                return;
            }
            RayTraceResult br = w.rayTraceBlocks(pos, d, step, FluidCollisionMode.NEVER, true);
            double maxD = br == null ? step : pos.toVector().distance(br.getHitPosition());
            RayTraceResult er = maxD <= 0.001 ? null : w.rayTraceEntities(pos, d, maxD, 0.35,
                    en -> en != p && !struck.contains(en.getUniqueId()) && en instanceof LivingEntity le && validTarget(p, le));
            if (er != null && er.getHitEntity() instanceof LivingEntity le) {
                struck.add(le.getUniqueId());
                Location hitAt = er.getHitPosition().toLocation(w);
                if (s != null) hitSkill(p, le, dmg, s, lv);
                else hit(p, le, dmg);
                throwOnHit(p, s, lv, le);
                w.spawnParticle(Particle.CRIT, hitAt, 6, 0.1, 0.1, 0.1, 0.1);
                w.playSound(le.getLocation(), Sound.ENTITY_ARROW_HIT, 1.0f, 1.0f);
                if (br == null && pierceChance > 0 && random.nextDouble() * 100.0 < pierceChance) {
                    pos.add(d.clone().multiply(step)); // 관통: 계속 날아간다
                    traveled[0] += step;
                    disp.teleport(pos);
                    return;
                }
                throwOnEnd(p, s, lv, hitAt);
                disp.remove();
                task[0].cancel();
                return;
            }
            if (br != null) {
                Location at = br.getHitPosition().toLocation(w);
                w.spawnParticle(Particle.CRIT, at, 4, 0.05, 0.05, 0.05, 0.05);
                w.playSound(at, Sound.ENTITY_ARROW_HIT, 0.6f, 1.4f);
                throwOnEnd(p, s, lv, at);
                disp.remove();
                task[0].cancel();
                return;
            }
            pos.add(d.clone().multiply(step));
            traveled[0] += step;
            disp.teleport(pos);
            if (trailGap > 0.0) {
                trailAcc[0] += step;
                if (trailAcc[0] >= trailGap) {
                    trailAcc[0] = 0.0;
                    addCloud(p, pos.clone(), val(p, s, "cloud-radius-yd", lv, 2.0) * lengthScale(),
                            val(p, s, "poison-seconds", lv, 5.0), val(p, s, "poison-dps", lv, 3.0), "poison");
                }
            }
        }, 1L, 1L);
    }

    private boolean doMelee(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        boolean offWeapon = isWeapon(p.getInventory().getItemInOffHand().getType());
        if (s.sec.getBoolean("requires-offhand", false) && !offWeapon) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": 왼손에도 무기를 들어야 합니다.");
            return false;
        }
        if (s.sec.getString("requires-weapon", "").equals("spear") && !isSpearHeld(p)) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": 창(삼지창 또는 투창)을 들어야 합니다.");
            return false;
        }
        String rw = s.sec.getString("requires-weapon", "");
        if (!rw.isEmpty() && !rw.equals("spear") && !holdingWeaponType(p, rw)) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": " + weaponLabel(rw) + "을(를) 들어야 합니다.");
            return false;
        }
        if (s.sec.getBoolean("requires-shield", false) && p.getInventory().getItemInOffHand().getType() != Material.SHIELD) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": 왼손에 방패를 들어야 합니다.");
            return false;
        }
        double range = val(p, s, "range", lv, 4.5);
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + "대상이 없습니다.");
            return false;
        }

        // 0.15.0: 희생 - 사용할 때 최대 생명력 일부를 소모 (죽지는 않는다)
        double selfPct = val(p, s, "self-damage-pct", lv, 0.0);
        if (selfPct > 0) {
            AttributeInstance mh = p.getAttribute(VersionCompat.MAX_HEALTH);
            double cost = (mh == null ? 20.0 : mh.getValue()) * selfPct / 100.0;
            p.setHealth(Math.max(1.0, p.getHealth() - cost));
            p.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, p.getLocation().add(0, 1.2, 0), 4, 0.2, 0.2, 0.2, 0.0);
        }
        // 0.15.0: 복수 - 보너스(원소 피해 추가)가 이번 타격부터 적용되도록 먼저 건다
        if (s.sec.getBoolean("buff-first", false)) applySelfBuff(p, s, lv);

        // 공격 순서: 이중 타격류는 왼손 무기가 있으면 두 대상에게 한 번씩, 없으면 한 대상에게 연속으로.
        List<LivingEntity> seq = new ArrayList<>();
        int hits = Math.max(1, (int) Math.round(val(p, s, "hits", lv, 1.0)));
        double adj = s.sec.contains("adjacent-radius-yd") ? val(p, s, "adjacent-radius-yd", lv, 0.0) * lengthScale() : 0.0;
        if (adj > 0) {
            // 열의: 지정한 적을 먼저, 그다음 주변 적을 가까운 순서로 번갈아 (적이 하나면 그 적만)
            List<LivingEntity> near = around(p.getLocation(), adj, p);
            near.remove(t);
            near.sort(Comparator.comparingDouble(o -> o.getLocation().distanceSquared(p.getLocation())));
            List<LivingEntity> order = new ArrayList<>();
            order.add(t);
            order.addAll(near);
            if (s.sec.getBoolean("hit-all", false)) { // 난격: 사거리 안의 적을 한 번씩만
                for (int i = 0; i < order.size() && i < hits; i++) seq.add(order.get(i));
            } else {
                for (int i = 0; i < hits; i++) seq.add(order.get(i % order.size()));
            }
        } else if (s.sec.getBoolean("dual-targets", false) && offWeapon) {
            seq.add(t);
            LivingEntity second = nearestOther(p, t, 4.0);
            seq.add(second != null ? second : t);
        } else {
            for (int i = 0; i < hits; i++) seq.add(t);
        }

        final boolean hasPhys = s.sec.contains("damage-pct");
        final double dmg = hasPhys ? skillDamage(p, s, lv) : 0.0;
        final double magic = attackPower(p) * val(p, s, "magic-pct", lv, 0.0) / 100.0; // 마법(비전) 피해: 방어/저항 무시
        final double kb = val(p, s, "knockback", lv, 0.0);
        final double stunSec = val(p, s, "stun-seconds", lv, 0.0);
        final Location origin = p.getLocation();

        for (int i = 0; i < seq.size(); i++) {
            final LivingEntity target = seq.get(i);
            Runnable r = () -> {
                if (!p.isOnline() || p.isDead() || !target.isValid() || target.isDead()) return;
                if (hasPhys) hitSkill(p, target, dmg, s, lv);
                if (magic > 0) pureHit(p, target, magic);
                meleeLightning(p, s, lv, target);
                target.getWorld().spawnParticle(Particle.SWEEP_ATTACK, target.getLocation().add(0, 1, 0), 1);
                target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 0.9f);
            };
            if (i == 0) r.run();
            else Bukkit.getScheduler().runTaskLater(plugin, r, 3L * i);
        }
        knock(origin, t, kb);
        stun(t, stunSec);
        if (s.sec.contains("melee-poison-dps")) {
            poisonDot(p, t, val(p, s, "melee-poison-dps", lv, 0.0), val(p, s, "melee-poison-seconds", lv, 3.0));
            double spread = s.sec.getDouble("poison-spread-radius", 0.0); // 광견병: 주변 적에게 전염
            if (spread > 0) {
                for (LivingEntity o : around(t.getLocation(), spread, p)) {
                    if (o == t) continue;
                    poisonDot(p, o, val(p, s, "melee-poison-dps", lv, 0.0), val(p, s, "melee-poison-seconds", lv, 3.0));
                    o.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, o.getLocation().add(0, 1, 0), 6, 0.3, 0.4, 0.3, 0.0);
                }
            }
        }
        double slowSec = val(p, s, "slow-seconds", lv, 0.0); // 꿰뚫기: 감속
        if (slowSec > 0) {
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (slowSec * 20.0), s.sec.getInt("slow-amplifier", 2), false, true));
        }
        wearWeapon(p, s, lv);

        // 집중 공격/버서크: 짧은 자가 버프(방어력 보너스/페널티)
        if (!s.sec.getBoolean("buff-first", false)) applySelfBuff(p, s, lv);

        // 광분: 적중마다 속도 보너스 누적
        if (s.sec.getBoolean("frenzy-stack", false) || s.sec.contains("attack-speed-max")) { // 0.7.4: attack-speed-max 가 있으면 중첩
            Frenzy f = frenzy.computeIfAbsent(p.getUniqueId(), k -> new Frenzy());
            long now = System.currentTimeMillis();
            if (f.until < now) f.stacks = 0;
            f.skillId = s.id;
            f.level = lv;
            f.stacks = Math.min(Math.max(1, s.sec.getInt("stack-max", 5)), f.stacks + seq.size());
            f.until = now + (long) (val(p, s, "stack-seconds", lv, 6.0) * 1000.0);
            bonusCache.remove(p.getUniqueId());
            refreshAttributes(p);
        }
        // 0.27.0: 드루이드 흉포한 격노/후려치기: 스킬마다 따로 쌓이는 중첩 (stack-bonuses)
        if (s.sec.isConfigurationSection("stack-bonuses")) {
            Frenzy f = formStacks.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).computeIfAbsent(s.id, k -> new Frenzy());
            long now = System.currentTimeMillis();
            if (f.until < now) f.stacks = 0;
            f.skillId = s.id;
            f.level = lv;
            f.stacks = Math.min(Math.max(1, (int) val(p, s, "stack-max", lv, 5.0)), f.stacks + seq.size());
            f.until = now + (long) (val(p, s, "stack-seconds", lv, 6.0) * 1000.0);
            bonusCache.remove(p.getUniqueId());
            refreshAttributes(p);
        }
        return true;
    }

    private void applySelfBuff(Player p, SkillDef s, int lv) {
        double sb = s.sec.getDouble("self-buff-seconds", 0.0);
        if (sb <= 0) return;
        buffs.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>())
                .put(s.id, new Buff(s.id, lv, System.currentTimeMillis() + (long) (sb * 1000.0)));
        bonusCache.remove(p.getUniqueId());
        refreshAttributes(p);
    }

    // ===================================================================
    //  0.15.0: 팔라딘 원거리 (kind: bolt 신성한 빛줄기 / hammer 축복받은 망치 / fist 천상의 주먹)  [미검증]
    //   서버가 직접 날려 보내고(입자) 직접 판정한다. 피해는 마법(비전) 피해라 방어/저항을 무시한다.
    //   마크 몹은 언데드/악마가 적어서: 모든 몹에게 기본 피해, 언데드/악마에게는 undead-bonus-pct 만큼 추가, 아군 플레이어는 치유.
    // ===================================================================

    /** 지금 나에게 적용 중인 특정 오라(skillId)가 주는 옵션 값. 없으면 0. (0.15.1) */
    private double auraOptionValue(Player p, String skillId, String optionName) {
        Map<String, Buff> m = auraBuffs.get(p.getUniqueId());
        if (m == null) return 0.0;
        Buff b = m.get(skillId);
        SkillDef sd = skills.get(skillId);
        if (b == null || sd == null || b.until < System.currentTimeMillis()) return 0.0;
        ConfigurationSection bs = sd.sec.getConfigurationSection("bonuses");
        return bs == null ? 0.0 : scaled(bs, optionName, b.level, 0.0);
    }

    private void healAlly(Player o, double amount) {
        if (o.isDead() || amount <= 0 || plugin.isHealBlocked(o)) return;
        AttributeInstance mh = o.getAttribute(VersionCompat.MAX_HEALTH);
        double max = mh == null ? 20.0 : mh.getValue();
        o.setHealth(Math.min(max, o.getHealth() + amount));
        o.getWorld().spawnParticle(Particle.HEART, o.getLocation().add(0, 1.6, 0), 3, 0.3, 0.2, 0.3, 0.0);
    }

    /** 신성한 마법 피해 한 번. 플레이어는 아군으로 보고 치유만 한다. */
    private void holyHit(Player p, LivingEntity t, double magic, double undeadPct, double heal) {
        if (t instanceof Player o) {
            if (o != p) healAlly(o, heal);
            return;
        }
        double m = magic;
        if (undeadPct > 0 && (plugin.isUndead(t) || plugin.isDemon(t))) m *= 1.0 + undeadPct / 100.0;
        if (m > 0) pureHit(p, t, m);
        t.getWorld().spawnParticle(Particle.END_ROD, t.getLocation().add(0, t.getHeight() * 0.6, 0), 8, 0.2, 0.3, 0.2, 0.05);
    }

    /** 직선으로 날아가는 빛줄기. pierce 면 맞아도 계속 날아간다(한 대상에 한 번). */
    private void flyBolt(Player p, Location from, Vector dir, double speed, double range, boolean pierce,
                         java.util.function.Consumer<LivingEntity> onHit) {
        final World w = p.getWorld();
        final Vector d = dir.clone().normalize();
        final Location pos = from.clone();
        final double[] traveled = {0.0};
        final Set<UUID> done = new HashSet<>();
        final BukkitTask[] task = new BukkitTask[1];
        task[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || p.getWorld() != w) {
                task[0].cancel();
                return;
            }
            double step = Math.min(speed, range - traveled[0]);
            if (step <= 0.0) {
                task[0].cancel();
                return;
            }
            RayTraceResult br = w.rayTraceBlocks(pos, d, step, FluidCollisionMode.NEVER, true);
            double maxD = br == null ? step : pos.toVector().distance(br.getHitPosition());
            for (double dd = 0.0; dd <= maxD; dd += 0.5) {
                w.spawnParticle(Particle.END_ROD, pos.clone().add(d.clone().multiply(dd)), 1, 0.0, 0.0, 0.0, 0.0);
            }
            Location mid = pos.clone().add(d.clone().multiply(maxD / 2.0));
            double rad = maxD / 2.0 + 1.0;
            List<LivingEntity> cand = new ArrayList<>();
            for (Entity en : w.getNearbyEntities(mid, rad, rad, rad)) {
                if (en == p || !(en instanceof LivingEntity le) || done.contains(le.getUniqueId())) continue;
                if (!(le instanceof Player) && !validTarget(p, le)) continue;
                if (le.getBoundingBox().expand(0.3).rayTrace(pos.toVector(), d, maxD) == null) continue;
                cand.add(le);
            }
            cand.sort(Comparator.comparingDouble(o -> o.getLocation().distanceSquared(pos)));
            for (LivingEntity le : cand) {
                done.add(le.getUniqueId());
                onHit.accept(le);
                if (!pierce) {
                    task[0].cancel();
                    return;
                }
            }
            if (br != null) {
                task[0].cancel();
                return;
            }
            pos.add(d.clone().multiply(step));
            traveled[0] += step;
        }, 1L, 1L);
    }

    /** 신성한 빛줄기: 앞으로 날아가며 적에게 피해, 아군은 치유. */
    private boolean doBolt(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final double range = val(p, s, "range", lv, 24.0);
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection();
        if (t != null) {
            Vector to = t.getLocation().add(0, t.getHeight() * 0.6, 0).toVector().subtract(eye.toVector());
            if (to.lengthSquared() > 0.0001) dir = to;
        }
        final double magic = attackPower(p) * val(p, s, "magic-pct", lv, 100.0) / 100.0;
        final double undeadPct = val(p, s, "undead-bonus-pct", lv, 0.0);
        final double heal = val(p, s, "heal", lv, 0.0);
        final double speed = s.sec.getDouble("bolt-speed", 1.4);
        final boolean pierce = s.sec.getBoolean("pierce", true);
        Location from = eye.clone().add(dir.clone().normalize().multiply(0.8)).subtract(0, 0.2, 0);
        flyBolt(p, from, dir, speed, range, pierce, le -> holyHit(p, le, magic, undeadPct, heal));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 0.8f, 1.6f);
        return true;
    }

    /** 축복받은 망치: 시전 지점에서 11시 방향에 시작해 시계 방향으로 점점 크게 도는 망치. */
    private boolean doHammer(Player p, SkillDef s, int lv) {
        final World w = p.getWorld();
        final Location origin = p.getLocation().add(0, 1.0, 0);
        Vector f = p.getLocation().getDirection().setY(0);
        if (f.lengthSquared() < 1.0E-6) f = new Vector(0, 0, 1);
        final Vector fwd = f.normalize();
        final Vector right = fwd.clone().crossProduct(new Vector(0, 1, 0)).normalize();
        final double maxR = val(p, s, "max-radius-yd", lv, 14.0) * lengthScale();
        final double startR = s.sec.getDouble("start-radius", 1.2);
        final double turns = s.sec.getDouble("turns", 1.75);
        final int dur = Math.max(6, (int) val(p, s, "duration-ticks", lv, 36.0));
        double magicBase = attackPower(p) * val(p, s, "magic-pct", lv, 100.0) / 100.0;
        // 0.15.1: 집중 오라의 "공격력 증가" 수치의 concentration-share % 만큼 피해 증가 (원작: 절반)
        double share = s.sec.getDouble("concentration-share", 0.0);
        if (share > 0) magicBase *= 1.0 + auraOptionValue(p, "concentration", "공격력 증가") * share / 10000.0;
        final double magic = magicBase;
        final double undeadPct = val(p, s, "undead-bonus-pct", lv, 0.0);
        final ItemDisplay disp = w.spawn(origin, ItemDisplay.class);
        disp.setItemStack(new ItemStack(mat(s.sec.getString("visual"), Material.IRON_AXE)));
        disp.setPersistent(false);
        final Set<UUID> done = new HashSet<>();
        w.playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.7f);
        new BukkitRunnable() {
            int tk = 0;

            @Override
            public void run() {
                if (!p.isOnline() || !disp.isValid() || tk > dur) {
                    disp.remove();
                    cancel();
                    return;
                }
                double frac = (double) tk / dur;
                double r = startR + (maxR - startR) * frac;
                double phi = Math.toRadians(-30.0) + Math.PI * 2.0 * turns * frac;
                Location pos = origin.clone()
                        .add(fwd.clone().multiply(r * Math.cos(phi)))
                        .add(right.clone().multiply(r * Math.sin(phi)));
                pos.setYaw(tk * 40f);
                disp.teleport(pos);
                w.spawnParticle(Particle.END_ROD, pos, 2, 0.1, 0.1, 0.1, 0.0);
                for (Entity en : w.getNearbyEntities(pos, 1.3, 1.3, 1.3)) {
                    if (en == p || !(en instanceof LivingEntity le) || le instanceof Player) continue;
                    if (done.contains(le.getUniqueId()) || !validTarget(p, le)) continue;
                    done.add(le.getUniqueId());
                    holyHit(p, le, magic, undeadPct, 0.0);
                    w.playSound(le.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.8f, 1.2f);
                }
                tk++;
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }

    /** 천상의 주먹: 대상 몬스터에게 번개를 내리치고, 그 주변 적들에게 신성한 빛줄기가 퍼져 나간다. (0.15.1: 대상을 직접 지정해야 한다) */
    private boolean doFist(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final World w = p.getWorld();
        final double range = val(p, s, "range", lv, 24.0);
        final LivingEntity t = forced != null ? forced : findTarget(p, range);
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 몬스터를 직접 조준해야 합니다.");
            return false;
        }
        final Location c = t.getLocation().clone();
        w.strikeLightningEffect(c);
        final double strike = attackPower(p) * val(p, s, "magic-pct", lv, 100.0) / 100.0;
        pureHit(p, t, strike); // 번개는 대상 하나만

        final double boltR = val(p, s, "bolt-radius-yd", lv, 20.0) * lengthScale();
        final int maxBolts = Math.max(1, (int) val(p, s, "max-bolts", lv, 8.0));
        final double boltMagic = attackPower(p) * val(p, s, "bolt-magic-pct", lv, 100.0) / 100.0;
        final double undeadPct = val(p, s, "undead-bonus-pct", lv, 0.0);
        List<LivingEntity> foes = around(c, boltR, p);
        foes.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(c)));
        int idx = 0;
        for (LivingEntity foe : foes) {
            if (idx >= maxBolts) break;
            final LivingEntity target = foe;
            final long delay = 4L + idx;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline() || !target.isValid() || target.isDead()) return;
                Location from = c.clone().add(0, 1.2, 0);
                Vector dir = target.getLocation().add(0, target.getHeight() * 0.6, 0).toVector().subtract(from.toVector());
                if (dir.lengthSquared() < 0.0001) return;
                flyBolt(p, from, dir, 1.4, dir.length() + 2.0, true,
                        le -> holyHit(p, le, boltMagic, undeadPct, 0.0));
            }, delay);
            idx++;
        }
        w.playSound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 1.4f);
        return true;
    }

    private void doAoe(Player p, SkillDef s, int lv, Location center) {
        double radius = radius(p, s, lv, 5.0);
        boolean hasDmg = s.sec.contains("damage-pct");
        double dmg = hasDmg ? skillDamage(p, s, lv) : 0.0;
        boolean flat = s.sec.contains("damage-min");
        double fmin = val(p, s, "damage-min", lv, 0.0);
        double frange = scaled(s.sec, "damage-range", lv, 10.0);
        double bonusPct = val(p, s, "damage-bonus-pct", lv, 0.0);
        double kb = val(p, s, "knockback", lv, 0.0);
        double stunSec = val(p, s, "stun-seconds", lv, 0.0);
        for (LivingEntity t : around(center, radius, p)) {
            if (hasDmg) hit(p, t, dmg);
            if (flat) pureHit(p, t, (fmin + random.nextDouble() * frange) * (1.0 + bonusPct / 100.0));
            knock(center, t, kb);
            stun(t, stunSec);
        }
        World w = center.getWorld();
        if (w != null) {
            double ring = Math.min(radius, 8.0);
            for (int i = 0; i < 32; i++) {
                double ang = Math.PI * 2 * i / 32.0;
                w.spawnParticle(Particle.CLOUD, center.clone().add(Math.cos(ang) * ring, 0.3, Math.sin(ang) * ring), 1, 0, 0, 0, 0.02);
            }
            if (!hasCustomSound(s)) w.playSound(center, Sound.ENTITY_RAVAGER_ROAR, 1.0f, 1.0f);
        }
    }

    /** 포효: 주변 몹이 일정 시간 동안 시전자에게서 멀리 도망친다. */
    private boolean doFear(Player p, SkillDef s, int lv) {
        double radius = radius(p, s, lv, 8.0);
        final double dist = val(p, s, "flee-dist-yd", lv, 16.0) * lengthScale();
        final double secs = val(p, s, "flee-seconds", lv, 3.0);
        final Location from = p.getLocation();
        final long until = System.currentTimeMillis() + (long) (secs * 1000.0);
        for (LivingEntity t : around(from, radius, p)) {
            if (!(t instanceof Mob m)) continue;
            feared.put(m.getUniqueId(), until);
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!m.isValid() || m.isDead() || System.currentTimeMillis() > until) {
                        feared.remove(m.getUniqueId());
                        cancel();
                        return;
                    }
                    m.setTarget(null);
                    Vector away = m.getLocation().toVector().subtract(from.toVector());
                    away.setY(0);
                    if (away.lengthSquared() < 0.01) away = new Vector(random.nextDouble() - 0.5, 0, random.nextDouble() - 0.5);
                    away.normalize().multiply(Math.max(4.0, dist));
                    VersionCompat.moveMob(m, m.getLocation().add(away), 1.4);
                }
            }.runTaskTimer(plugin, 0L, 10L);
        }
        World w = p.getWorld();
        w.spawnParticle(Particle.CLOUD, from.clone().add(0, 1, 0), 40, radius * 0.3, 0.5, radius * 0.3, 0.05);
        w.playSound(from, Sound.ENTITY_RAVAGER_ROAR, 1.2f, 0.8f);
        return true;
    }

    private boolean doWhirlwind(Player p, SkillDef s, int lv) {
        final double radius = radius(p, s, lv, 3.0);
        final double dmg = skillDamage(p, s, lv);
        final int duration = (int) (val(p, s, "duration", lv, 2.0) * 20.0);
        final int interval = Math.max(1, s.sec.getInt("interval", 5));
        final int startSlot = p.getInventory().getHeldItemSlot();
        final String group = s.lock.isEmpty() ? "whirl" : s.lock;
        locks.put(p.getUniqueId(), group);

        // 앞으로 살짝 돌진
        Vector dir = p.getLocation().getDirection();
        dir.setY(0);
        if (dir.lengthSquared() > 0.0001) {
            dir.normalize().multiply(val(p, s, "dash", lv, 0.8)).setY(0.1);
            p.setVelocity(dir);
        }

        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                // 지속 중 핫바 칸을 바꾸면(무기를 놓으면) 멈춘다.
                if (!p.isOnline() || p.isDead() || t >= duration || p.getInventory().getHeldItemSlot() != startSlot) {
                    unlock(p, group);
                    cancel();
                    return;
                }
                Location c = p.getLocation();
                for (int i = 0; i < 12; i++) {
                    double ang = Math.PI * 2 * i / 12.0 + t * 0.6;
                    p.getWorld().spawnParticle(Particle.SWEEP_ATTACK,
                            c.clone().add(Math.cos(ang) * radius * 0.8, 1.0, Math.sin(ang) * radius * 0.8), 1);
                }
                if (t % interval == 0) {
                    for (LivingEntity target : around(c, radius, p)) {
                        hit(p, target, dmg);
                    }
                    p.getWorld().playSound(c, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.0f);
                }
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        return true;
    }

    /** 도약: 뛰어올라 착지하면 주변 적을 밀쳐낸다. 착지 전에는 도약류를 다시 쓸 수 없다. */
    private boolean doLeap(Player p, SkillDef s, int lv) {
        double power = val(p, s, "power", lv, 1.2);
        Vector dir = p.getLocation().getDirection();
        dir.setY(0);
        if (dir.lengthSquared() < 0.0001) dir = new Vector(0, 0, 1);
        dir.normalize().multiply(power).setY(0.65);
        p.setVelocity(dir);
        final String group = s.lock.isEmpty() ? "air" : s.lock;
        locks.put(p.getUniqueId(), group);
        leapGuard.put(p.getUniqueId(), System.currentTimeMillis() + 5000L);
        final double radius = radius(p, s, lv, 3.0);
        final double kb = val(p, s, "knockback", lv, 1.0);
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                if (!p.isOnline() || p.isDead()) {
                    unlock(p, group);
                    cancel();
                    return;
                }
                if ((t > 4 && p.isOnGround()) || t > 40) {
                    cancel();
                    unlock(p, group);
                    Location c = p.getLocation();
                    for (LivingEntity target : around(c, radius, p)) {
                        knock(c, target, kb);
                    }
                    p.setFallDistance(0f);
                    leapGuard.put(p.getUniqueId(), System.currentTimeMillis() + 800L);
                    c.getWorld().spawnParticle(Particle.CLOUD, c, 24, Math.min(radius, 6.0) * 0.4, 0.1, Math.min(radius, 6.0) * 0.4, 0.05);
                    c.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.2f);
                }
            }
        }.runTaskTimer(plugin, 2L, 1L);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1.0f, 0.8f);
        return true;
    }

    /** 도약 공격: 대상 적에게 도약해 신속하게 공격한다. 착지 전에는 도약류를 다시 쓸 수 없다. */
    /**
     * 0.15.2: 돌진 (kind: charge). 위로 뛰지 않고 앞으로만 달려간다. 팔라딘의 유일한 이동기라 대상이 없어도 쓸 수 있다.
     * 대상을 조준했으면 그 몬스터에게 달려가 부딪히면 피해, 대상이 없으면 바라보는 방향으로 달리다 처음 부딪힌 적에게 피해.
     * 벽에 막히거나 거리를 다 가면 멈춘다. 달리는 동안은 다시 쓸 수 없다. [미검증]
     */
    private boolean doCharge(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final double maxDist = val(p, s, "range-yd", lv, 24.0) * lengthScale();
        final LivingEntity t = forced != null ? forced : findTarget(p, maxDist);
        Vector flat = t != null
                ? t.getLocation().toVector().subtract(p.getLocation().toVector())
                : p.getLocation().getDirection();
        flat.setY(0);
        double flatLen = flat.length();
        if (flatLen < 0.0001) {
            flat = new Vector(0, 0, 1);
            flatLen = 1.0;
        }
        final Vector dir = flat.clone().normalize();
        final double dist = t != null ? Math.min(maxDist, flatLen) : maxDist;
        final double speed = s.sec.getDouble("dash-speed", 1.1);
        final double dmg = skillDamage(p, s, lv);
        final double kb = val(p, s, "knockback", lv, 0.0);
        final String group = s.lock.isEmpty() ? "charge" : s.lock;
        locks.put(p.getUniqueId(), group);
        final Location start = p.getLocation().clone();
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1.0f, 0.8f);
        new BukkitRunnable() {
            int tk = 0;
            double lastMoved = 0.0;

            private void finish() {
                cancel();
                unlock(p, group);
                if (p.isOnline()) {
                    Vector v = p.getVelocity();
                    p.setVelocity(new Vector(0.0, Math.min(0.0, v.getY()), 0.0));
                    p.setFallDistance(0f);
                }
            }

            @Override
            public void run() {
                tk++;
                if (!p.isOnline() || p.isDead()) {
                    unlock(p, group);
                    cancel();
                    return;
                }
                Location now = p.getLocation();
                double moved = now.toVector().subtract(start.toVector()).setY(0).length();
                // 부딪힌 적 찾기: 대상을 조준했으면 그 대상만, 아니면 앞쪽에서 가장 가까운 적
                LivingEntity contact = null;
                if (t != null) {
                    if (t.isValid() && !t.isDead() && now.distanceSquared(t.getLocation()) <= 4.84) contact = t;
                } else {
                    Location front = now.clone().add(dir.clone().multiply(0.8));
                    double best = Double.MAX_VALUE;
                    for (LivingEntity e : around(front, 1.6, p)) {
                        double d2 = e.getLocation().distanceSquared(now);
                        if (d2 < best) {
                            best = d2;
                            contact = e;
                        }
                    }
                }
                if (contact != null) {
                    hit(p, contact, dmg);
                    knock(now, contact, kb);
                    contact.getWorld().spawnParticle(Particle.SWEEP_ATTACK, contact.getLocation().add(0, 1, 0), 1);
                    contact.getWorld().playSound(contact.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 0.9f);
                    finish();
                    return;
                }
                boolean blocked = tk > 3 && (moved - lastMoved) < speed * 0.25;
                if (moved >= dist || blocked || tk > 40) {
                    finish();
                    return;
                }
                lastMoved = moved;
                p.setVelocity(new Vector(dir.getX() * speed, Math.min(0.0, p.getVelocity().getY()), dir.getZ() * speed));
                p.setFallDistance(0f);
                p.getWorld().spawnParticle(Particle.CLOUD, now.clone().add(0, 0.2, 0), 2, 0.2, 0.05, 0.2, 0.01);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }

    /**
     * 0.16.0: 전향 (kind: convert). 근접 공격으로 맞은 몹이 확률로 일정 시간 "전향"한다:
     * 그동안 플레이어를 노리지 않고 가까운 다른 몹을 공격한다. (아군 몹 시스템이 아니라 몹 AI의 목표만 바꾼다. 보스는 안 된다.) [미검증]
     */
    private boolean doConvert(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        double range = val(p, s, "range", lv, 4.5);
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + "대상이 없습니다.");
            return false;
        }
        if (s.sec.contains("damage-pct")) hit(p, t, skillDamage(p, s, lv));
        double chance = val(p, s, "convert-chance", lv, 40.0);
        if (t instanceof Mob m && !(t instanceof org.bukkit.entity.Boss) && !t.isDead()
                && random.nextDouble() * 100.0 < chance) {
            startConvert(m, val(p, s, "convert-seconds", lv, 8.0));
            msg(p, ChatColor.LIGHT_PURPLE + "전향!");
        }
        t.getWorld().spawnParticle(Particle.SWEEP_ATTACK, t.getLocation().add(0, 1, 0), 1);
        t.getWorld().playSound(t.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 0.9f);
        return true;
    }

    private void startConvert(Mob m, double seconds) {
        final long until = System.currentTimeMillis() + (long) (seconds * 1000.0);
        converted.put(m.getUniqueId(), until);
        m.setTarget(null);
        new BukkitRunnable() {
            @Override
            public void run() {
                Long u = converted.get(m.getUniqueId());
                if (!m.isValid() || m.isDead() || u == null || u < System.currentTimeMillis()) {
                    converted.remove(m.getUniqueId());
                    cancel();
                    return;
                }
                Mob best = null;
                double bestD = Double.MAX_VALUE;
                for (Entity en : m.getNearbyEntities(12, 6, 12)) {
                    if (!(en instanceof Mob o) || o == m || o.isDead()) continue;
                    if (o instanceof Villager || o instanceof WanderingTrader || o instanceof ArmorStand) continue;
                    if (converted.containsKey(o.getUniqueId())) continue;
                    double d2 = o.getLocation().distanceSquared(m.getLocation());
                    if (d2 < bestD) {
                        bestD = d2;
                        best = o;
                    }
                }
                m.setTarget(best);
                m.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, m.getLocation().add(0, m.getHeight() + 0.3, 0), 3, 0.2, 0.1, 0.2, 0.0);
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    private boolean doLeapAttack(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        double range = val(p, s, "range-yd", lv, 24.0) * lengthScale();
        final LivingEntity target = forced != null ? forced : findTarget(p, range);
        if (target == null) {
            if (!quiet) msg(p, ChatColor.GRAY + "대상이 없습니다.");
            return false;
        }
        Vector flat = target.getLocation().toVector().subtract(p.getLocation().toVector());
        flat.setY(0);
        double dist = flat.length();
        if (dist < 0.01) flat = p.getLocation().getDirection().setY(0);
        if (flat.lengthSquared() < 0.0001) flat = new Vector(0, 0, 1);
        flat.normalize().multiply(Math.min(1.8, 0.5 + dist * 0.18)).setY(0.5);
        p.setVelocity(flat);

        final String group = s.lock.isEmpty() ? "air" : s.lock;
        locks.put(p.getUniqueId(), group);
        leapGuard.put(p.getUniqueId(), System.currentTimeMillis() + 5000L);
        final double dmg = skillDamage(p, s, lv);
        new BukkitRunnable() {
            int t = 0;
            boolean done = false;

            @Override
            public void run() {
                t++;
                if (!p.isOnline() || p.isDead()) {
                    unlock(p, group);
                    cancel();
                    return;
                }
                boolean near = target.isValid() && p.getLocation().distanceSquared(target.getLocation()) < 6.25;
                if (!done && t > 3 && (near || p.isOnGround() || t > 30)) {
                    done = true;
                    if (target.isValid() && !target.isDead()
                            && p.getLocation().distanceSquared(target.getLocation()) < 25.0) {
                        hit(p, target, dmg);
                        target.getWorld().spawnParticle(Particle.SWEEP_ATTACK, target.getLocation().add(0, 1, 0), 1);
                        target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 0.9f);
                    }
                }
                if ((t > 4 && p.isOnGround()) || t > 40) {
                    cancel();
                    unlock(p, group);
                    p.setFallDistance(0f);
                    leapGuard.put(p.getUniqueId(), System.currentTimeMillis() + 800L);
                }
            }
        }.runTaskTimer(plugin, 2L, 1L);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1.0f, 0.8f);
        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onLeapFall(EntityDamageEvent e) {
        if (e.getCause() != DamageCause.FALL || !(e.getEntity() instanceof Player p)) return;
        Long g = leapGuard.get(p.getUniqueId());
        if (g != null && g > System.currentTimeMillis()) e.setCancelled(true);
    }

    private void doBuff(Player p, SkillDef s, int lv) {
        double durSec = val(p, s, "duration", lv, 30.0);
        double radius = radius(p, s, lv, 0.0);
        long until = System.currentTimeMillis() + (long) (durSec * 1000.0);
        List<Player> targets = new ArrayList<>();
        targets.add(p);
        if (radius > 0) {
            for (Entity e : p.getNearbyEntities(radius, radius, radius)) {
                if (e instanceof Player o && !o.isDead()) targets.add(o);
            }
        }
        for (Player t : targets) {
            buffs.computeIfAbsent(t.getUniqueId(), k -> new HashMap<>()).put(s.id, new Buff(s.id, lv, until));
            String exclusive = s.sec.getString("exclusive", "");
            if (!exclusive.isEmpty()) buffs.get(t.getUniqueId()).remove(exclusive); // 폭발적인 속도 <-> 흐리기는 함께 못 쓴다
            bonusCache.remove(t.getUniqueId());
            refreshAttributes(t);
            t.getWorld().spawnParticle(Particle.ENCHANT, t.getLocation().add(0, 1, 0), 30, 0.5, 0.8, 0.5, 0.5);
            if (t != p) msg(t, ChatColor.GREEN + p.getName() + "의 " + s.name + " 효과를 받았습니다.");
        }
        if (!hasCustomSound(s)) p.getWorld().playSound(p.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1.0f, 1.2f);
    }

    // ===================================================================
    //  0.17.0: 아마존  [미검증]
    //   - 창 스킬(찌르기 계열)은 kind: melee + requires-weapon: spear. 번개는 hit-bonuses 로 "적중 한 번에만" 붙인다.
    //   - 투창 스킬은 kind: throw (손에 든 투척 무기를 던진다). 독 구름/번개 분열은 throw 스킬 설정으로 켠다.
    //   - 활 스킬은 kind: arrow (활/쇠뇌를 들고 쏜다). 서버가 직접 날리고 판정한다 (바닐라 화살 피해를 쓰지 않는다).
    //   - 회피 계열(흘리기/회피/피하기)과 관통/간파/치명타는 kind: passive 의 수치 키로 읽는다.
    // ===================================================================

    private boolean isSpearHeld(Player p) {
        ItemStack h = p.getInventory().getItemInMainHand();
        if (h.getType() == Material.TRIDENT) return true;
        ThrowSystem ts = plugin.throwSystem();
        return ts != null && "javelin".equals(ts.typeOf(h));
    }

    private boolean isBowHeld(Player p) {
        Material m = p.getInventory().getItemInMainHand().getType();
        return m == Material.BOW || m == Material.CROSSBOW;
    }

    /** 패시브 스킬 중 key 수치를 가진 것들의 합 (시너지 포함, 스킬 레벨 0이면 제외). */
    private double passiveSum(Player p, String key) {
        if (!enabled()) return 0.0;
        PData d = data(p);
        double sum = 0.0;
        for (SkillDef s : skills.values()) {
            if (!s.kind.equals("passive") || !s.sec.contains(key)) continue;
            int lv = level(p, d, s);
            if (lv > 0) sum += val(p, s, key, lv, 0.0);
        }
        return sum;
    }

    /** extra 옵션 보너스(예: "번개 피해 추가")를 이번 한 번의 피해 계산에만 더해서 r 을 실행한다. */
    private void withTemp(Player p, Map<String, Double> extra, Runnable r) {
        if (extra == null || extra.isEmpty()) {
            r.run();
            return;
        }
        Map<String, Double> prevB = tempBonus;
        UUID prevO = tempOwner;
        tempBonus = extra;
        tempOwner = p.getUniqueId();
        bonusCache.remove(tempOwner);
        try {
            r.run();
        } finally {
            tempBonus = prevB;
            tempOwner = prevO;
            bonusCache.remove(p.getUniqueId());
        }
    }

    /** 스킬의 hit-bonuses (적중 시에만 붙는 옵션 수치, 시너지 포함). 없으면 null. */
    private Map<String, Double> hitBonuses(Player p, SkillDef s, int lv) {
        ConfigurationSection b = s.sec.getConfigurationSection("hit-bonuses");
        if (b == null) return null;
        Map<String, Double> m = new LinkedHashMap<>();
        for (String name : b.getKeys(false)) {
            double v = synBonus(p, s, name, scaled(b, name, lv, 0.0));
            if (v != 0) m.put(name, v);
        }
        return m;
    }

    /**
     * 일반 파이프라인으로 때리되, 스킬의 hit-bonuses 와 물리->원소 전환(convert-element/convert-pct)을 이번 타격에만 적용한다.
     */
    private void hitSkill(Player p, LivingEntity t, double dmg, SkillDef s, int lv) {
        Map<String, Double> extra = hitBonuses(p, s, lv);
        String cel = s.sec.getString("convert-element", "");
        double cpct = cel.isEmpty() ? 0.0 : Math.max(0.0, Math.min(100.0, val(p, s, "convert-pct", lv, 0.0)));
        double phys = dmg;
        if (cpct > 0) {
            double conv = dmg * cpct / 100.0;
            extra = extra == null ? new LinkedHashMap<>() : new LinkedHashMap<>(extra);
            extra.merge(cel + " 피해 추가", conv, Double::sum);
            phys = Math.max(0.5, dmg - conv);
        }
        final double pd = phys;
        withTemp(p, extra, () -> hit(p, t, pd));
    }

    /** 꿰뚫기: 확률로 손에 든 무기의 내구도가 깎인다 (부서지지는 않는다). */
    private void wearWeapon(Player p, SkillDef s, int lv) {
        double chance = val(p, s, "wear-chance", lv, 0.0);
        if (chance <= 0 || random.nextDouble() * 100.0 >= chance) return;
        ItemStack h = p.getInventory().getItemInMainHand();
        if (!(h.getItemMeta() instanceof org.bukkit.inventory.meta.Damageable dm)) return;
        if (dm.isUnbreakable()) return;
        int max = h.getType().getMaxDurability();
        if (max <= 0) return;
        int add = Math.max(1, s.sec.getInt("wear-amount", 5));
        dm.setDamage(Math.min(max - 1, dm.getDamage() + add));
        h.setItemMeta(dm);
        p.getInventory().setItemInMainHand(h);
    }

    private Vector aimPoint(LivingEntity t) {
        return t.getLocation().add(0, t.getHeight() * 0.6, 0).toVector();
    }

    /** 번개 줄기 시각 효과 (피해는 따로). */
    private void sparkLine(Location a, Location b) {
        World w = a.getWorld();
        if (w == null) return;
        Vector v = b.toVector().subtract(a.toVector());
        double len = v.length();
        if (len < 0.01) return;
        v.normalize();
        for (double d = 0.0; d <= len; d += 0.4) {
            w.spawnParticle(Particle.ELECTRIC_SPARK, a.clone().add(v.clone().multiply(d)), 1, 0.05, 0.05, 0.05, 0.0);
        }
        w.playSound(b, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.3f, 2.0f);
    }

    // ---------------------------------------------------------------- 창: 번개 효과

    private void meleeLightning(Player p, SkillDef s, int lv, LivingEntity target) {
        if (!s.sec.contains("charged-bolts") && !s.sec.contains("chain-count")) return;
        Map<String, Double> hb = hitBonuses(p, s, lv);
        double light = hb == null ? 0.0 : hb.getOrDefault("번개 피해 추가", 0.0);
        if (light <= 0) return;
        if (s.sec.contains("charged-bolts")) chargedBolts(p, s, lv, target, light);
        if (s.sec.contains("chain-count")) chainLightning(p, s, lv, target, light);
    }

    /** 전류의 일격: 맞은 적 주변의 적들에게 번개 줄기가 뻗는다. 개수 = charged-bolts. 주변에 적이 없으면 같은 적을 다시 때린다. */
    private void chargedBolts(Player p, SkillDef s, int lv, LivingEntity main, double light) {
        final World w = main.getWorld();
        final int count = Math.max(1, (int) val(p, s, "charged-bolts", lv, 3.0));
        final double r = val(p, s, "bolt-radius-yd", lv, 10.0) * lengthScale();
        final double factor = val(p, s, "bolt-pct", lv, 60.0) / 100.0;
        final Location c = main.getLocation().clone();
        List<LivingEntity> foes = around(c, r, p);
        foes.remove(main);
        foes.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(c)));
        w.playSound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);
        for (int i = 0; i < count; i++) {
            final LivingEntity tg = foes.isEmpty() ? main : foes.get(i % foes.size());
            final long delay = 2L + i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline() || !tg.isValid() || tg.isDead()) return;
                sparkLine(c.clone().add(0, 1.2, 0), tg.getLocation().add(0, tg.getHeight() * 0.6, 0));
                pureHit(p, tg, Math.max(1.0, light * factor));
            }, delay);
        }
    }

    /** 번개의 일격: 맞은 적에서 가까운 다음 적으로 연쇄 번개가 튄다. 한 적에게 한 번만. */
    private void chainLightning(Player p, SkillDef s, int lv, LivingEntity main, double light) {
        final int count = Math.max(1, (int) val(p, s, "chain-count", lv, 3.0));
        final double r = val(p, s, "chain-radius-yd", lv, 8.0) * lengthScale();
        final double factor = val(p, s, "chain-pct", lv, 80.0) / 100.0;
        Set<UUID> seen = new HashSet<>();
        seen.add(main.getUniqueId());
        LivingEntity cur = main;
        for (int i = 0; i < count; i++) {
            LivingEntity best = null;
            double bd = Double.MAX_VALUE;
            for (LivingEntity o : around(cur.getLocation(), r, p)) {
                if (seen.contains(o.getUniqueId())) continue;
                double d = o.getLocation().distanceSquared(cur.getLocation());
                if (d < bd) {
                    bd = d;
                    best = o;
                }
            }
            if (best == null) break;
            seen.add(best.getUniqueId());
            final LivingEntity from = cur;
            final LivingEntity to = best;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline() || !to.isValid() || to.isDead()) return;
                sparkLine(from.getLocation().add(0, from.getHeight() * 0.6, 0), to.getLocation().add(0, to.getHeight() * 0.6, 0));
                pureHit(p, to, Math.max(1.0, light * factor));
            }, 3L * (i + 1));
            cur = best;
        }
    }

    // ---------------------------------------------------------------- 투창: 번개의 격노 / 역병 투창

    private void throwOnHit(Player p, SkillDef s, int lv, LivingEntity hit) {
        if (s == null) return;
        if (s.sec.contains("fury-bolts")) furyBolts(p, s, lv, hit);
    }

    private void throwOnEnd(Player p, SkillDef s, int lv, Location at) {
        if (s == null || at.getWorld() == null) return;
        if (s.sec.contains("end-cloud-radius-yd")) {
            addCloud(p, at, val(p, s, "end-cloud-radius-yd", lv, 5.0) * lengthScale(),
                    val(p, s, "poison-seconds", lv, 3.0), val(p, s, "poison-dps", lv, 4.0), "poison");
            at.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, at, 30, 1.2, 0.4, 1.2, 0.0);
            at.getWorld().playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 0.3f, 1.8f);
        }
    }

    /** 번개의 격노: 투창이 맞은 자리 주변의 적들에게 작은 번개들이 분열한다. */
    private void furyBolts(Player p, SkillDef s, int lv, LivingEntity hit) {
        final int count = Math.max(1, (int) val(p, s, "fury-bolts", lv, 6.0));
        final double r = val(p, s, "fury-radius-yd", lv, 12.0) * lengthScale();
        final double dmg = Math.max(1.0, val(p, s, "fury-lightning", lv, 6.0) * val(p, s, "fury-pct", lv, 100.0) / 100.0);
        final Location c = hit.getLocation().clone();
        List<LivingEntity> foes = around(c, r, p);
        if (foes.isEmpty()) return;
        foes.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(c)));
        c.getWorld().playSound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 1.6f);
        for (int i = 0; i < count; i++) {
            final LivingEntity tg = foes.get(i % foes.size());
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline() || !tg.isValid() || tg.isDead()) return;
                sparkLine(c.clone().add(0, 1.0, 0), tg.getLocation().add(0, tg.getHeight() * 0.6, 0));
                pureHit(p, tg, dmg);
            }, 2L + i);
        }
    }

    // ---------------------------------------------------------------- 독 구름 / 불길

    private void addCloud(Player p, Location loc, double radius, double seconds, double dps, String element) {
        if (loc.getWorld() == null || seconds <= 0 || dps <= 0) return;
        Cloud c = new Cloud();
        c.owner = p.getUniqueId();
        c.world = loc.getWorld();
        c.loc = loc.clone();
        c.radius = Math.max(0.8, radius);
        c.until = System.currentTimeMillis() + (long) (seconds * 1000.0);
        c.dps = dps;
        c.element = element;
        clouds.add(c);
        if (clouds.size() > 300) clouds.remove(0); // 너무 많이 쌓이지 않게
    }

    /** 1초마다: 구름 안의 적에게 초당 피해. 같은 적이 여러 구름에 겹쳐 있으면 가장 센 구름 하나만 적용한다. */
    private void cloudTick() {
        if (clouds.isEmpty()) return;
        long now = System.currentTimeMillis();
        Map<UUID, Map<LivingEntity, Double>> perOwner = new HashMap<>();
        Iterator<Cloud> it = clouds.iterator();
        while (it.hasNext()) {
            Cloud c = it.next();
            Player o = Bukkit.getPlayer(c.owner);
            if (c.until < now || o == null || !o.isOnline() || c.world == null) {
                it.remove();
                continue;
            }
            Particle pt = c.element.equals("fire") ? Particle.FLAME : Particle.HAPPY_VILLAGER;
            c.world.spawnParticle(pt, c.loc.clone().add(0, 0.4, 0), 8, c.radius * 0.5, 0.3, c.radius * 0.5, 0.0);
            if (c.element.equals("poison")) {
                c.world.spawnParticle(Particle.CLOUD, c.loc.clone().add(0, 0.3, 0), 2, c.radius * 0.4, 0.15, c.radius * 0.4, 0.0);
            }
            Map<LivingEntity, Double> m = perOwner.computeIfAbsent(c.owner, k -> new LinkedHashMap<>());
            for (LivingEntity t : around(c.loc, c.radius, o)) {
                m.merge(t, c.dps, Math::max);
            }
        }
        for (Map.Entry<UUID, Map<LivingEntity, Double>> en : perOwner.entrySet()) {
            Player o = Bukkit.getPlayer(en.getKey());
            if (o == null) continue;
            for (Map.Entry<LivingEntity, Double> t : en.getValue().entrySet()) {
                pureHit(o, t.getKey(), t.getValue());
            }
        }
    }

    // ---------------------------------------------------------------- 활: kind arrow

    private boolean takeArrow(Player p) {
        org.bukkit.inventory.PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            if (it == null) continue;
            Material m = it.getType();
            if (m == Material.ARROW || m == Material.SPECTRAL_ARROW || m == Material.TIPPED_ARROW) {
                if (it.getAmount() <= 1) inv.setItem(i, null);
                else {
                    it.setAmount(it.getAmount() - 1);
                    inv.setItem(i, it);
                }
                return true;
            }
        }
        ItemStack off = inv.getItemInOffHand();
        Material om = off.getType();
        if (om == Material.ARROW || om == Material.SPECTRAL_ARROW || om == Material.TIPPED_ARROW) {
            if (off.getAmount() <= 1) inv.setItemInOffHand(null);
            else {
                off.setAmount(off.getAmount() - 1);
                inv.setItemInOffHand(off);
            }
            return true;
        }
        return false;
    }

    private Particle elementParticle(String element) {
        return switch (element) {
            case "fire" -> Particle.FLAME;
            case "cold" -> Particle.SNOWFLAKE;
            case "magic" -> Particle.WITCH;
            case "lightning" -> Particle.ELECTRIC_SPARK;
            case "poison" -> Particle.HAPPY_VILLAGER;
            default -> Particle.CRIT;
        };
    }

    private void freezeMob(LivingEntity t, double seconds) {
        if (seconds <= 0 || t.isDead() || !t.isValid()) return;
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (seconds * 20.0), 6, false, true));
        t.getWorld().spawnParticle(Particle.SNOWFLAKE, t.getLocation().add(0, t.getHeight() * 0.5, 0), 14, 0.3, 0.4, 0.3, 0.02);
    }

    /** 화살 스킬 한 번: 필요한 화살 수/방향을 정해 날린다. */
    private boolean doArrow(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        if (!isBowHeld(p)) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": 활 또는 쇠뇌를 들어야 합니다.");
            return false;
        }
        final double range = val(p, s, "range", lv, 32.0);
        final boolean strafe = s.sec.contains("strafe-radius-yd");
        final Location eye = p.getEyeLocation();
        final List<Vector> dirs = new ArrayList<>();
        final List<LivingEntity> aims = new ArrayList<>();
        final int n = Math.max(1, (int) val(p, s, "arrows", lv, 1.0));
        Vector base = eye.getDirection();
        if (strafe) {
            double r = val(p, s, "strafe-radius-yd", lv, 30.0) * lengthScale();
            List<LivingEntity> foes = around(p.getLocation(), r, p);
            foes.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(p.getLocation())));
            if (foes.isEmpty()) {
                if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 주변에 적이 없습니다.");
                return false;
            }
            for (int i = 0; i < n; i++) {
                LivingEntity f = foes.get(i % foes.size());
                Vector to = aimPoint(f).subtract(eye.toVector());
                aims.add(f);
                dirs.add(to.lengthSquared() < 0.0001 ? base.clone() : to);
            }
        } else {
            LivingEntity t = forced != null ? forced : findTarget(p, range);
            if (t != null) {
                Vector to = aimPoint(t).subtract(eye.toVector());
                if (to.lengthSquared() > 0.0001) base = to;
            }
            base = base.clone().normalize();
            if (n <= 1) {
                dirs.add(base);
                aims.add(t);
            } else {
                double step = Math.toRadians(val(p, s, "spread-step-deg", lv, 6.0));
                double max = Math.toRadians(s.sec.getDouble("spread-max-deg", 90.0));
                double total = Math.min(max, step * (n - 1));
                for (int i = 0; i < n; i++) {
                    double a = -total / 2.0 + total * i / (n - 1);
                    dirs.add(base.clone().rotateAroundY(a));
                    aims.add(null);
                }
            }
        }
        if (s.sec.getBoolean("consume-arrow", true) && !takeArrow(p)) {
            if (!quiet) msg(p, ChatColor.RED + "화살이 없습니다.");
            return false;
        }
        final double dmg = skillDamage(p, s, lv);
        final Set<UUID> once = new HashSet<>();
        final boolean oncePer = n > 1 && !strafe; // 다발 사격: 한 적에게 화살 하나만
        for (int i = 0; i < dirs.size(); i++) {
            final Vector dir = dirs.get(i);
            final LivingEntity aim = aims.get(i);
            Runnable r = () -> {
                if (!p.isOnline() || p.isDead()) return;
                Location e2 = p.getEyeLocation();
                Vector dd = dir;
                if (aim != null && aim.isValid() && !aim.isDead()) {
                    Vector to = aimPoint(aim).subtract(e2.toVector());
                    if (to.lengthSquared() > 0.0001) dd = to;
                }
                Location from = e2.clone().add(dd.clone().normalize().multiply(0.8)).subtract(0, 0.2, 0);
                fireArrow(p, s, lv, from, dd, aim, dmg, range, oncePer ? once : null);
            };
            if (strafe && i > 0) Bukkit.getScheduler().runTaskLater(plugin, r, 2L * i);
            else r.run();
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 1.0f);
        return true;
    }

    /** 화살 하나: 직선(유도 화살은 적을 따라가며)으로 날아가 서버가 직접 판정한다. */
    private void fireArrow(Player p, SkillDef s, int lv, Location from, Vector dir, LivingEntity aim,
                           double dmg, double range, Set<UUID> once) {
        final World w = p.getWorld();
        final Location pos = from.clone();
        final Vector[] d = {dir.clone().normalize()};
        pos.setDirection(d[0]);
        final ItemDisplay disp = w.spawn(pos, ItemDisplay.class);
        disp.setItemStack(new ItemStack(Material.ARROW));
        disp.setPersistent(false);
        final boolean homing = s.sec.getBoolean("homing", false);
        final double pierceChance = (homing || s.sec.getBoolean("no-pierce", false))
                ? 0.0 : Math.min(100.0, passiveSum(p, "pierce-chance"));
        final double speed = Math.max(0.5, s.sec.getDouble("arrow-speed", 2.2));
        final Particle trailP = elementParticle(s.sec.getString("element", ""));
        final double pathR = s.sec.contains("path-freeze-radius-yd") ? val(p, s, "path-freeze-radius-yd", lv, 3.0) * lengthScale() : 0.0;
        final double pathSec = val(p, s, "path-freeze-seconds", lv, 1.0);
        final Set<UUID> struck = new HashSet<>();
        final LivingEntity[] lock = {aim};
        final double[] traveled = {0.0};
        final BukkitTask[] task = new BukkitTask[1];
        task[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!disp.isValid() || !p.isOnline()) {
                disp.remove();
                task[0].cancel();
                return;
            }
            if (homing) { // 유도 화살: 가장 가까운 앞쪽 적을 따라간다
                LivingEntity g = lock[0];
                if (g == null || !g.isValid() || g.isDead() || struck.contains(g.getUniqueId())) {
                    g = null;
                    double bd = Double.MAX_VALUE;
                    for (LivingEntity o : around(pos, 12.0, p)) {
                        if (struck.contains(o.getUniqueId())) continue;
                        Vector to = aimPoint(o).subtract(pos.toVector());
                        if (to.lengthSquared() < 0.01 || to.clone().normalize().dot(d[0]) < 0.0) continue;
                        double dd = o.getLocation().distanceSquared(pos);
                        if (dd < bd) {
                            bd = dd;
                            g = o;
                        }
                    }
                    lock[0] = g;
                }
                if (g != null) {
                    Vector to = aimPoint(g).subtract(pos.toVector()).normalize();
                    d[0] = d[0].clone().multiply(0.65).add(to.multiply(0.35)).normalize();
                    pos.setDirection(d[0]);
                }
            }
            double step = Math.min(speed, range - traveled[0]);
            if (step <= 0.0) {
                arrowEnd(p, s, lv, pos.clone());
                disp.remove();
                task[0].cancel();
                return;
            }
            RayTraceResult br = w.rayTraceBlocks(pos, d[0], step, FluidCollisionMode.NEVER, true);
            double maxD = br == null ? step : pos.toVector().distance(br.getHitPosition());
            RayTraceResult er = maxD <= 0.001 ? null : w.rayTraceEntities(pos, d[0], maxD, 0.4,
                    en -> en != p && !struck.contains(en.getUniqueId()) && en instanceof LivingEntity le && validTarget(p, le));
            w.spawnParticle(trailP, pos, 2, 0.03, 0.03, 0.03, 0.0);
            if (pathR > 0.0) { // 빙결 화살: 지나가는 길의 적을 얼린다
                for (LivingEntity o : around(pos, pathR, p)) freezeMob(o, pathSec);
            }
            if (er != null && er.getHitEntity() instanceof LivingEntity le) {
                struck.add(le.getUniqueId());
                Location hitAt = er.getHitPosition().toLocation(w);
                boolean fresh = once == null || once.add(le.getUniqueId());
                if (fresh) arrowHit(p, s, lv, le, dmg);
                if (br == null && (!fresh || (pierceChance > 0 && random.nextDouble() * 100.0 < pierceChance))) {
                    pos.add(d[0].clone().multiply(step)); // 관통 / 다른 화살이 이미 맞힌 적은 통과
                    traveled[0] += step;
                    disp.teleport(pos);
                    return;
                }
                arrowEnd(p, s, lv, hitAt);
                disp.remove();
                task[0].cancel();
                return;
            }
            if (br != null) {
                Location at = br.getHitPosition().toLocation(w);
                w.playSound(at, Sound.ENTITY_ARROW_HIT, 0.6f, 1.4f);
                arrowEnd(p, s, lv, at);
                disp.remove();
                task[0].cancel();
                return;
            }
            pos.add(d[0].clone().multiply(step));
            traveled[0] += step;
            disp.teleport(pos);
        }, 1L, 1L);
    }

    private void arrowHit(Player p, SkillDef s, int lv, LivingEntity le, double dmg) {
        hitSkill(p, le, dmg, s, lv);
        if (le.isDead() || !le.isValid()) return;
        double slowSec = val(p, s, "slow-seconds", lv, 0.0);
        if (slowSec > 0) {
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (slowSec * 20.0), s.sec.getInt("slow-amplifier", 1), false, true));
        }
        double fz = val(p, s, "freeze-seconds", lv, 0.0);
        if (fz > 0 && !s.sec.contains("explosion-radius-yd")) freezeMob(le, fz); // 얼음 화살: 맞은 적을 얼린다
        le.getWorld().spawnParticle(Particle.CRIT, aimPoint(le).toLocation(le.getWorld()), 6, 0.1, 0.1, 0.1, 0.1);
        le.getWorld().playSound(le.getLocation(), Sound.ENTITY_ARROW_HIT, 1.0f, 1.0f);
    }

    /** 화살이 끝나는 자리: 폭발(explosion-*), 불길(pool-*). */
    private void arrowEnd(Player p, SkillDef s, int lv, Location at) {
        World w = at.getWorld();
        if (w == null) return;
        if (s.sec.contains("explosion-radius-yd")) {
            double er = val(p, s, "explosion-radius-yd", lv, 4.0) * lengthScale();
            double ed = val(p, s, "explosion-damage", lv, 0.0);
            double fz = val(p, s, "freeze-seconds", lv, 0.0);
            for (LivingEntity t : around(at, er, p)) {
                if (ed > 0) pureHit(p, t, ed);
                if (fz > 0) freezeMob(t, fz);
            }
            boolean cold = s.sec.getString("explosion-element", "fire").equals("cold");
            w.spawnParticle(cold ? Particle.SNOWFLAKE : Particle.FLAME, at, 40, er * 0.4, 0.4, er * 0.4, 0.05);
            w.spawnParticle(Particle.CLOUD, at, 12, er * 0.3, 0.3, er * 0.3, 0.02);
            w.playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 0.6f, cold ? 1.8f : 1.2f);
        }
        if (s.sec.contains("pool-seconds")) {
            addCloud(p, at, val(p, s, "pool-radius-yd", lv, 4.0) * lengthScale(),
                    val(p, s, "pool-seconds", lv, 3.0), val(p, s, "pool-dps", lv, 5.0), "fire");
        }
    }

    // ---------------------------------------------------------------- 회피 계열 (흘리기 / 회피 / 피하기)

    @EventHandler
    public void onMoveTrack(PlayerMoveEvent e) {
        Location a = e.getFrom();
        Location b = e.getTo();
        if (b == null) return;
        if (Math.abs(a.getX() - b.getX()) > 0.005 || Math.abs(a.getZ() - b.getZ()) > 0.005) {
            lastMove.put(e.getPlayer().getUniqueId(), System.currentTimeMillis());
        }
    }

    /** 가만히 서 있거나 막 공격(스킬)을 쓴 직후면 "서 있는 상태"로 본다. */
    private boolean isStanding(Player p) {
        long now = System.currentTimeMillis();
        Long t = lastMove.get(p.getUniqueId());
        if (t == null || now - t > 400L) return true;
        Long sw = nextSwing.get(p.getUniqueId());
        return sw != null && sw + 200L > now;
    }

    /** 흘리기(서 있을 때 근접) / 회피(서 있을 때 투사체) / 피하기(움직일 때 근접+투사체). 성공하면 피해를 없앤다. */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onAmazonEvade(EntityDamageByEntityEvent e) {
        if (!enabled() || !(e.getEntity() instanceof Player v)) return;
        Entity dm = e.getDamager();
        boolean proj = dm instanceof Projectile;
        boolean melee = !proj && dm instanceof LivingEntity;
        if (!proj && !melee) return;
        double chance;
        if (isStanding(v)) chance = passiveSum(v, proj ? "avoid-ranged-pct" : "dodge-melee-pct");
        else chance = passiveSum(v, "evade-moving-pct");
        if (chance <= 0) return;
        chance = Math.min(chance, plugin.getConfig().getDouble("dodge.max", 75.0));
        if (random.nextDouble() * 100.0 >= chance) return;
        e.setCancelled(true);
        v.getWorld().playSound(v.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 0.7f, 1.5f);
        v.getWorld().spawnParticle(Particle.CLOUD, v.getLocation().add(0, 1.0, 0), 6, 0.3, 0.4, 0.3, 0.02);
    }

    // ---------------------------------------------------------------- 설명 (스킬 트리 툴팁)

    private void describeAmazon(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        Map<String, Double> hb = hitBonuses(p, s, lv);
        if (hb != null) {
            for (Map.Entry<String, Double> en : hb.entrySet()) {
                out.add(ChatColor.AQUA + en.getKey() + " +" + fmt(en.getValue()) + ChatColor.GRAY + " (이 스킬로 맞힐 때만)");
            }
        }
        if (c.contains("convert-element")) {
            out.add(ChatColor.AQUA + "물리 피해의 " + fmt(val(p, s, "convert-pct", lv, 0)) + "%를 "
                    + c.getString("convert-element") + " 피해로 전환");
        }
        if (c.contains("arrows")) out.add(ChatColor.GRAY + "화살 " + (int) val(p, s, "arrows", lv, 1) + "발" + (c.getBoolean("consume-arrow", true) ? ", 화살 1개 소모" : ", 화살 소모 없음"));
        if (c.contains("charged-bolts")) out.add(ChatColor.AQUA + "번개 줄기 " + (int) val(p, s, "charged-bolts", lv, 3) + "개 (맞은 적 주변)");
        if (c.contains("chain-count")) out.add(ChatColor.AQUA + "연쇄 번개 " + (int) val(p, s, "chain-count", lv, 3) + "회");
        if (c.contains("fury-bolts")) {
            out.add(ChatColor.AQUA + "분열 번개 " + (int) val(p, s, "fury-bolts", lv, 6) + "발, 각 " + fmt(val(p, s, "fury-lightning", lv, 0)) + " 번개 피해");
        }
        if (c.contains("poison-dps")) {
            out.add(ChatColor.GREEN + "독 구름: 초당 " + fmt(val(p, s, "poison-dps", lv, 0)) + ", " + fmt(val(p, s, "poison-seconds", lv, 0)) + "초");
        }
        if (c.contains("trail-spacing-yd")) out.add(ChatColor.GRAY + "날아간 길에 독 구름을 남김");
        if (c.contains("end-cloud-radius-yd")) out.add(ChatColor.GRAY + "맞거나 멈춘 자리에 넓은 독 구름");
        if (c.contains("explosion-damage")) {
            out.add(ChatColor.GOLD + "폭발 " + fmt(val(p, s, "explosion-damage", lv, 0)) + " 피해, 범위 "
                    + fmt(val(p, s, "explosion-radius-yd", lv, 0) * lengthScale()) + "칸");
        }
        if (c.contains("pool-seconds")) {
            out.add(ChatColor.GOLD + "불길: 초당 " + fmt(val(p, s, "pool-dps", lv, 0)) + ", " + fmt(val(p, s, "pool-seconds", lv, 0)) + "초");
        }
        if (c.contains("freeze-seconds")) out.add(ChatColor.AQUA + "빙결 " + fmt(val(p, s, "freeze-seconds", lv, 0)) + "초");
        if (c.contains("slow-seconds")) out.add(ChatColor.GRAY + "감속 " + fmt(val(p, s, "slow-seconds", lv, 0)) + "초");
        if (c.contains("wear-chance")) out.add(ChatColor.RED + "무기 내구도가 " + fmt(val(p, s, "wear-chance", lv, 0)) + "% 확률로 닳음");
        if (c.getBoolean("homing", false)) out.add(ChatColor.GRAY + "적을 따라가며 관통하지 않음");
        if (c.contains("strafe-radius-yd")) out.add(ChatColor.GRAY + "주변 적을 자동으로 조준해 번갈아 쏜다");
        if (c.contains("path-freeze-radius-yd")) out.add(ChatColor.AQUA + "날아가는 길의 적을 얼림");
        if (c.contains("dodge-melee-pct")) out.add(ChatColor.AQUA + "서 있을 때 근접 공격 회피 " + fmt(val(p, s, "dodge-melee-pct", lv, 0)) + "%");
        if (c.contains("avoid-ranged-pct")) out.add(ChatColor.AQUA + "서 있을 때 투사체 회피 " + fmt(val(p, s, "avoid-ranged-pct", lv, 0)) + "%");
        if (c.contains("evade-moving-pct")) out.add(ChatColor.AQUA + "움직일 때 근접/투사체 회피 " + fmt(val(p, s, "evade-moving-pct", lv, 0)) + "%");
        if (c.contains("pierce-chance")) out.add(ChatColor.AQUA + "투창/화살이 적을 관통할 확률 " + fmt(val(p, s, "pierce-chance", lv, 0)) + "%");
        if (c.contains("ranged-damage-pct")) out.add(ChatColor.AQUA + "투창/화살 스킬 피해 +" + fmt(val(p, s, "ranged-damage-pct", lv, 0)) + "%");
    }



    // ---- 0.18.0 저주 추가: 공포 / 유인 / 혼란 / 시야 흐림
    private void startFlee(Mob m, Location from, double seconds) {
        final long until = System.currentTimeMillis() + (long) (seconds * 1000.0);
        feared.put(m.getUniqueId(), until);
        final Location src = from.clone();
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!m.isValid() || m.isDead() || System.currentTimeMillis() > until) {
                    feared.remove(m.getUniqueId());
                    cancel();
                    return;
                }
                m.setTarget(null);
                Vector away = m.getLocation().toVector().subtract(src.toVector());
                away.setY(0);
                if (away.lengthSquared() < 0.01) away = new Vector(random.nextDouble() - 0.5, 0, random.nextDouble() - 0.5);
                away.normalize().multiply(8.0);
                VersionCompat.moveMob(m, m.getLocation().add(away), 1.3);
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    /** 유인: 주변 몹들이 저주 걸린 대상을 향해 몰려든다. */
    private void startAttract(Mob center, double seconds, double radius) {
        final long until = System.currentTimeMillis() + (long) (seconds * 1000.0);
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!center.isValid() || center.isDead() || System.currentTimeMillis() > until) {
                    cancel();
                    return;
                }
                for (Entity en : center.getNearbyEntities(radius, radius / 2.0, radius)) {
                    if (!(en instanceof Mob o) || o == center || o.isDead()) continue;
                    if (o instanceof Villager || o instanceof WanderingTrader || en instanceof org.bukkit.entity.Boss) continue;
                    o.setTarget(center);
                }
                center.getWorld().spawnParticle(Particle.WITCH, center.getLocation().add(0, center.getHeight() + 0.3, 0), 4, 0.2, 0.1, 0.2, 0.0);
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    private void applySpecialCurses(Player p, SkillDef s, int lv, LivingEntity t, double radius) {
        if (s.id.equals("decrepify") && s.sec.isConfigurationSection("curse")) {
            double dur = scaled(s.sec.getConfigurationSection("curse"), "duration", lv, 6.0);
            curses.computeIfAbsent(t.getUniqueId(), k -> new HashMap<>()).put("decrepify", new Curse(0.0, System.currentTimeMillis() + (long) (dur * 1000.0)));
        }
        for (String section : new String[]{"curse", "curse2", "curse3"}) {
            ConfigurationSection c = s.sec.getConfigurationSection(section);
            if (c == null || !(t instanceof Mob m) || t instanceof org.bukkit.entity.Boss) continue;
            String type = c.getString("type", "");
            double secs = scaled(c, "duration", lv, 6.0);
            switch (type) {
                case "terror" -> startFlee(m, p.getLocation(), secs);
                case "confuse" -> startConvert(m, secs);
                case "attract" -> startAttract(m, secs, Math.max(6.0, radius * 2.0));
                default -> { }
            }
        }
    }

    private boolean doCurse(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        // center: self -> 시전자 주변 (도발, 전투의 함성)
        if (s.sec.getString("center", "").equals("self")) {
            applyCurseArea(p, s, lv, p.getLocation());
            return true;
        }
        double range = val(p, s, "range", lv, 20.0);
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        Location center;
        if (t != null) {
            center = t.getLocation();
        } else {
            Location eye = p.getEyeLocation();
            center = eye.clone().add(eye.getDirection().multiply(6.0));
        }
        boolean any = applyCurseArea(p, s, lv, center);
        if (!any && !quiet) msg(p, ChatColor.GRAY + "저주를 걸 대상이 없습니다.");
        return any;
    }

    private boolean applyCurseArea(Player p, SkillDef s, int lv, Location center) {
        double radius = radius(p, s, lv, 4.0);
        boolean aggro = s.sec.getBoolean("aggro", false);
        List<LivingEntity> list = around(center, radius, p);
        for (LivingEntity t : list) {
            applyCurse(t, s, lv);
            applySpecialCurses(p, s, lv, t, radius);
            if (aggro && t instanceof Mob m) {
                Long fu = feared.get(m.getUniqueId());
                if (fu == null || fu < System.currentTimeMillis()) m.setTarget(p);
            }
        }
        World w = center.getWorld();
        if (w != null && !list.isEmpty()) {
            w.spawnParticle(Particle.WITCH, center.clone().add(0, 1, 0), 30, Math.min(radius, 8.0) * 0.4, 0.5, Math.min(radius, 8.0) * 0.4, 0.0);
            w.playSound(center, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 0.8f, 1.0f);
        }
        return !list.isEmpty();
    }

    private boolean doAuraToggle(Player p, SkillDef s) {
        PData d = data(p);
        if (s.id.equals(d.activeAura)) {
            d.activeAura = null;
            msg(p, ChatColor.GRAY + s.name + " 해제");
        } else {
            d.activeAura = s.id;
            msg(p, ChatColor.GREEN + s.name + " 활성화");
        }
        save(p);
        return true;
    }

    // ===================================================================
    //  입력: 좌클릭 / 우클릭 / 숫자키
    // ===================================================================

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        boolean right = a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK;
        boolean left = a == Action.LEFT_CLICK_AIR || a == Action.LEFT_CLICK_BLOCK;
        if (!right && !left) return;
        Player p = e.getPlayer();
        if (!weaponReady(p)) return;
        if (right && a == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable() && !p.isSneaking()) return;

        PData d = data(p);
        if (d.cls == null) return;
        String id = right ? d.right : d.left;
        if (id == null) return;
        SkillDef s = skills.get(id);
        if (s == null) return;
        Result r = tryCast(p, s, null, left);
        if (r != Result.FAIL) {
            if (left) lastLeftCast.put(p.getUniqueId(), tickCounter);
            e.setCancelled(true);
        }
    }

    /** 좌클릭 스킬이 설정되어 있으면 바닐라 근접 공격 대신 스킬을 쓴다(마나 부족 등으로 실패하면 일반 공격). */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onLeftClickAttack(EntityDamageByEntityEvent e) {
        if (casting || pure || reflecting) return;
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != DamageCause.ENTITY_ATTACK) return;
        if (!(e.getEntity() instanceof LivingEntity t) || !validTarget(p, t)) return;
        if (!weaponReady(p)) return;
        PData d = data(p);
        if (d.cls == null || d.left == null) return;
        SkillDef s = skills.get(d.left);
        if (s == null) return;
        Integer last = lastLeftCast.get(p.getUniqueId());
        if (last != null && last == tickCounter) {
            e.setCancelled(true);
            return;
        }
        Result r = tryCast(p, s, t, true);
        if (r != Result.FAIL) {
            lastLeftCast.put(p.getUniqueId(), tickCounter);
            e.setCancelled(true);
        }
    }

    /**
     * 무기(1번 칸)를 든 채로 숫자키 2~9를 누르면, 그 칸에 등록된 스킬이 우클릭 스킬로 장착된다.
     * (웅크린 채 누르면 좌클릭 스킬) 등록이 없는 칸은 평소처럼 아이템이 바뀐다.
     */
    @EventHandler(ignoreCancelled = true)
    public void onHotbar(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        if (!enabled() || e.getPreviousSlot() != 0) return;
        int ns = e.getNewSlot();
        if (ns <= 0 || ns >= 9) return;
        if (!isRpg(p.getInventory().getItem(0))) return;
        PData d = data(p);
        if (d.cls == null || !d.hotkeys) return;
        // 0.13.0: 휠/2번/9번 = 다음/이전 스킬 넘기기 (config skill-system.scroll-cycle)
        if (cycleMode() && (ns == 1 || ns == 8)) {
            e.setCancelled(true);
            cycleSkill(p, d, ns == 1 ? 1 : -1);
            return;
        }
        String id = d.hot[ns];
        if (id == null) return;
        SkillDef s = skills.get(id);
        if (s == null || d.levels.getOrDefault(id, 0) <= 0) return;
        e.setCancelled(true);
        if (p.isSneaking()) {
            d.left = id;
            msg(p, ChatColor.YELLOW + "좌클릭 스킬: " + ChatColor.GOLD + s.name);
        } else {
            d.right = id;
            msg(p, ChatColor.YELLOW + "우클릭 스킬: " + ChatColor.GOLD + s.name);
        }
        save(p);
    }

    // ----- 0.13.0: 숫자키 스킬 단축키 스위치 / 휠 넘기기 -----

    /** 휠 넘기기 모드: 마우스 휠(과 숫자키 2/9)이 스킬을 넘기고, 숫자키 3~8 이 직접 선택이 된다. */
    boolean cycleMode() {
        return plugin.getConfig().getBoolean("skill-system.scroll-cycle", true);
    }

    boolean hasClass(Player p) {
        PData d = data.get(p.getUniqueId());
        return d != null && d.cls != null;
    }

    boolean hotkeysOn(Player p) {
        return data(p).hotkeys;
    }

    void toggleHotkeys(Player p) {
        PData d = data(p);
        d.hotkeys = !d.hotkeys;
        save(p);
    }

    /** 숫자키 3~8 에 등록된 스킬을 순서대로 돌린다. 웅크리면 왼쪽 스킬, 아니면 오른쪽 스킬. dir=+1 다음, -1 이전. */
    private void cycleSkill(Player p, PData d, int dir) {
        List<String> list = new ArrayList<>();
        for (int i = 2; i <= 7; i++) {
            String sid = d.hot[i];
            if (sid == null || skills.get(sid) == null) continue;
            if (d.levels.getOrDefault(sid, 0) <= 0) continue;
            list.add(sid);
        }
        if (list.isEmpty()) {
            msg(p, ChatColor.GRAY + "등록된 스킬이 없습니다. 스킬 창에서 스킬 위에 마우스를 올리고 숫자키 3~8을 누르세요.");
            return;
        }
        boolean left = p.isSneaking();
        String cur = left ? d.left : d.right;
        int idx = cur == null ? -1 : list.indexOf(cur);
        int next = idx < 0 ? (dir > 0 ? 0 : list.size() - 1) : Math.floorMod(idx + dir, list.size());
        String sid = list.get(next);
        SkillDef s = skills.get(sid);
        if (left) {
            d.left = sid;
            msg(p, ChatColor.YELLOW + "좌클릭 스킬: " + ChatColor.GOLD + s.name);
        } else {
            d.right = sid;
            msg(p, ChatColor.YELLOW + "우클릭 스킬: " + ChatColor.GOLD + s.name);
        }
        save(p);
    }

    /** 액션바에 붙일 현재 선택 스킬 표시. 직업이 없으면 빈 문자열. */
    String hudText(Player p) {
        PData d = data.get(p.getUniqueId());
        if (d == null || d.cls == null || !enabled()) return "";
        SkillDef l = d.left == null ? null : skills.get(d.left);
        SkillDef r = d.right == null ? null : skills.get(d.right);
        return ChatColor.YELLOW + "좌:" + (l == null ? "기본" : l.name) + " 우:" + (r == null ? "-" : r.name);
    }

    // ===================================================================
    //  스킬 트리 GUI  (스킬 칸 = 티어(세로) x 열(가로), 오른쪽 한 줄 = 탭/정보)
    // ===================================================================

    private String blockReason(Player p, PData d, SkillDef s) {
        int cur = d.levels.getOrDefault(s.id, 0);
        if (cur >= s.maxLevel) return "최대 레벨";
        if (freePoints(d) <= 0) return "남은 포인트 없음";
        if (s.reqLevel > 0 && d.maxLevel < s.reqLevel) return "필요 레벨 " + s.reqLevel + " (현재 " + d.maxLevel + ")";
        for (String pr : s.prereq) {
            String[] parts = pr.split(":");
            SkillDef ps = skills.get(parts[0].trim());
            int need = 1;
            if (parts.length > 1) {
                try {
                    need = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException ignored) {
                    need = 1;
                }
            }
            if (ps != null && d.levels.getOrDefault(ps.id, 0) < need) return "선행 스킬: " + ps.name + " " + need + "레벨";
        }
        return null;
    }

    private boolean learn(Player p, PData d, SkillDef s) {
        String reason = blockReason(p, d, s);
        if (reason != null) {
            msg(p, ChatColor.RED + s.name + ": " + reason);
            return false;
        }
        d.levels.merge(s.id, 1, Integer::sum);
        save(p);
        return true;
    }

    void openTree(Player p, int tab) {
        PData d = data(p);
        if (d.cls == null || !classes.containsKey(d.cls)) {
            openClassChooser(p);
            return;
        }
        ClassDef c = classes.get(d.cls);
        SkillHolder h = new SkillHolder("tree");
        h.tab = Math.max(0, Math.min(tab, Math.min(3, c.tabs.size()) - 1));
        h.inv = Bukkit.createInventory(h, GUI_SIZE, ChatColor.DARK_RED + "스킬 - " + c.name);
        render(p, h);
        p.openInventory(h.inv);
    }

    private ItemStack named(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        if (lore != null) meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private void render(Player p, SkillHolder h) {
        PData d = data(p);
        ClassDef c = classes.get(d.cls);
        Inventory inv = h.inv;
        inv.clear();
        h.slotSkill.clear();
        if (c == null) return;

        for (int i = 0; i < c.tabs.size() && i < 3; i++) {
            ItemStack it = named(TAB_ICONS[i % TAB_ICONS.length],
                    (i == h.tab ? ChatColor.GOLD + "▶ " : ChatColor.GRAY + "") + c.tabs.get(i), null);
            inv.setItem(i * 9 + 8, it);
        }

        List<String> info = new ArrayList<>();
        info.add(ChatColor.GRAY + "남은 포인트: " + ChatColor.GREEN + freePoints(d) + ChatColor.GRAY + " / 총 " + totalPoints(d));
        info.add(ChatColor.GRAY + "(포인트 = 시작 " + plugin.getConfig().getInt("skill-system.start-points", 1)
                + " + 레벨 x" + plugin.getConfig().getInt("skill-system.points-per-level", 1) + ")");
        info.add(ChatColor.GRAY + "세로 줄 = 티어 (필요 레벨 1/6/12/18/24/30)");
        info.add("");
        info.add(ChatColor.YELLOW + "좌클릭: " + ChatColor.WHITE + "포인트 투자");
        info.add(ChatColor.YELLOW + "우클릭: " + ChatColor.WHITE + "우클릭 스킬로 장착");
        info.add(ChatColor.YELLOW + "Shift+우클릭: " + ChatColor.WHITE + "좌클릭 스킬로 장착");
        if (cycleMode()) {
            info.add(ChatColor.YELLOW + "숫자키 3~8: " + ChatColor.WHITE + "그 칸에 스킬 등록");
            info.add(ChatColor.GRAY + "(마우스 휠 / 숫자키 2, 9 = 등록한 스킬 넘기기)");
        } else {
            info.add(ChatColor.YELLOW + "숫자키 2~9: " + ChatColor.WHITE + "그 칸에 스킬 등록");
        }
        info.add(ChatColor.YELLOW + "Q: " + ChatColor.WHITE + "이 스킬의 등록 해제");
        inv.setItem(STAR_SLOT, named(Material.NETHER_STAR, ChatColor.GOLD + "스킬 포인트", info));

        SkillDef ls = d.left == null ? null : skills.get(d.left);
        SkillDef rs = d.right == null ? null : skills.get(d.right);
        List<String> cur = new ArrayList<>();
        cur.add(ChatColor.GRAY + "좌클릭: " + ChatColor.WHITE + (ls == null ? "기본 공격" : ls.name));
        cur.add(ChatColor.GRAY + "우클릭: " + ChatColor.WHITE + (rs == null ? "(없음)" : rs.name));
        for (int i = 1; i < 9; i++) {
            SkillDef hs = d.hot[i] == null ? null : skills.get(d.hot[i]);
            cur.add(ChatColor.GRAY + "숫자키 " + (i + 1) + ": " + ChatColor.WHITE + (hs == null ? "-" : hs.name));
        }
        cur.add("");
        cur.add(ChatColor.DARK_GRAY + "무기는 1번 칸에 들고 있어야 스킬이 나갑니다.");
        inv.setItem(BOOK_SLOT, named(Material.WRITABLE_BOOK, ChatColor.AQUA + "현재 장착", cur));

        for (SkillDef s : skills.values()) {
            if (!s.classId.equals(d.cls) || s.tab != h.tab) continue;
            int slot = s.row * 9 + s.col;
            if (slot < 0 || slot >= GUI_SIZE) continue;
            inv.setItem(slot, skillIcon(p, d, s));
            h.slotSkill.put(slot, s.id);
        }
    }

    private ItemStack skillIcon(Player p, PData d, SkillDef s) {
        int base = d.levels.getOrDefault(s.id, 0);
        int eff = level(p, d, s);
        String reason = base >= s.maxLevel ? null : blockReason(p, d, s);
        ChatColor color = base > 0 ? ChatColor.GREEN : (reason == null ? ChatColor.YELLOW : ChatColor.RED);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.DARK_GRAY + kindLabel(s.kind) + (s.tier > 0 ? "  |  필요 레벨 " + s.reqLevel : ""));
        if (!s.desc.isEmpty()) lore.add(ChatColor.GRAY + s.desc);
        lore.add("");
        lore.add(ChatColor.WHITE + "레벨: " + base + " / " + s.maxLevel
                + (eff > base ? ChatColor.AQUA + "  (장비/버프 포함 " + eff + ")" : ""));
        lore.addAll(describe(p, s, Math.max(1, eff)));
        if (!s.prereq.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (String pr : s.prereq) {
                String[] parts = pr.split(":");
                SkillDef ps = skills.get(parts[0].trim());
                if (sb.length() > 0) sb.append(", ");
                sb.append(ps == null ? parts[0] : ps.name);
            }
            lore.add(ChatColor.GRAY + "선행: " + sb);
        }
        if (reason != null && base < s.maxLevel) lore.add(ChatColor.RED + "배울 수 없음: " + reason);
        if (!s.kind.equals("passive") && !s.kind.equals("display")) {
            if (d.right != null && d.right.equals(s.id)) lore.add(ChatColor.GOLD + "★ 우클릭 스킬");
            if (d.left != null && d.left.equals(s.id)) lore.add(ChatColor.GOLD + "★ 좌클릭 스킬");
            for (int i = 1; i < 9; i++) {
                if (s.id.equals(d.hot[i])) lore.add(ChatColor.GOLD + "★ 숫자키 " + (i + 1));
            }
        }
        ItemStack it = named(s.icon, color + s.name, lore);
        if (base > 0) it.setAmount(Math.min(64, base));
        return it;
    }

    private String kindLabel(String kind) {
        return switch (kind) {
            case "melee" -> "[공격] 단일 대상";
            case "throw" -> "[공격] 투척 (투척 무기 필요)";
            case "bolt" -> "[공격] 투사체 (관통)";
            case "hammer" -> "[공격] 나선형 망치";
            case "fist" -> "[공격] 번개 + 빛줄기";
            case "aoe" -> "[함성/범위] 주변";
            case "fear" -> "[함성] 공포";
            case "whirlwind" -> "[공격] 회전";
            case "leap" -> "[이동] 도약";
            case "leap_attack" -> "[이동/공격] 대상에게 도약";
            case "charge" -> "[이동/공격] 앞으로 돌진 (대상 없이도 사용)";
            case "convert" -> "[공격] 근접 + 적을 몹끼리 싸우게 함";
            case "arrow" -> "[공격] 화살 (활/쇠뇌 필요)";
            case "buff" -> "[강화] 지속 효과";
            case "passive" -> "[패시브] 항상 적용";
            case "curse" -> "[저주] 주변/대상 몹";
            case "aura" -> "[오라] 켜 두면 주변에 적용";
            case "missile" -> "[공격] 마법 투사체";
            case "corpse" -> "[공격] 시체 사용 (시체를 조준)";
            case "shield" -> "[방어] 피해 흡수";
            case "wall" -> "[지형] 임시 뼈 블록";
            case "raise" -> "[소환] 시체 사용 (시간 제한 있음)";
            case "nova" -> "[공격] 주변 사방";
            case "chain" -> "[공격] 튕기는 번개";
            case "static" -> "[공격] 주변 적의 현재 생명력 비율";
            case "telekinesis" -> "[유틸] 아이템 끌어오기 / 적 밀치기";
            case "teleport" -> "[이동] 시선 방향 순간이동";
            case "eshield" -> "[방어] 피해를 마나로 (다시 쓰면 해제)";
            case "storm" -> "[강화] 일정 시간 주변에 번개";
            case "blizzard" -> "[공격] 조준한 곳에 눈보라";
            case "orb" -> "[공격] 얼음살을 뿜는 구체";
            case "coldarmor" -> "[강화] 냉기 갑옷 (하나만 유지)";
            case "inferno" -> "[공격] 앞으로 불줄기";
            case "blaze" -> "[강화] 이동하며 불길을 남김";
            case "firewall" -> "[공격] 조준한 곳에 화염벽";
            case "enchant" -> "[강화] 무기에 화염 피해 (다른 플레이어에게도 가능)";
            case "meteor" -> "[공격] 조준한 곳에 운석";
            case "hydra" -> "[소환] 불덩이를 쏘는 히드라 (시간 제한)";
            case "decoy" -> "[소환] 적을 유인하는 분신 (시간 제한)";
            case "valkyrie" -> "[소환] 발키리 전사 (하나만)";
            case "shockweb" -> "[공격] 조준한 곳에 번개 그물";
            case "bladesent" -> "[공격] 오가는 표창 (덫 한도에 포함)";
            case "bladefury" -> "[공격] 표창 연사";
            case "animal" -> "[소환] 동물 (다른 동물과 함께 가능)";
            case "spirit" -> "[소환] 오라 정령 (한 종류만)";
            case "raven" -> "[소환] 적을 쪼는 큰까마귀";
            case "plant" -> "[소환] 덩굴 (한 종류만)";
            case "form" -> "[변신] 다시 쓰면 풀림, 변신 중 대부분의 스킬 사용 불가";
            case "shockwave" -> "[공격] 부채꼴 충격파 + 기절";
            case "firestorm" -> "[공격] 땅을 타는 세 갈래 불길";
            case "molten" -> "[공격] 굴러가는 불타는 바위";
            case "arctic" -> "[공격] 냉기 줄기";
            case "fissure" -> "[공격] 무작위 균열";
            case "cyclone" -> "[강화] 원소 피해 흡수";
            case "twister" -> "[공격] 작은 회오리 세 개";
            case "volcano" -> "[설치] 화산";
            case "tornado" -> "[공격] 거대한 회오리바람";
            case "armageddon" -> "[공격] 주변에 운석 비";
            case "hurricane" -> "[강화] 따라다니는 허리케인";
            case "bladeshield" -> "[강화] 몸 주위 표창";
            case "sentry" -> "[설치] 자동으로 쏘는 덫 (최대 5개)";
            case "cloak" -> "[저주] 주변 적의 시야를 가림";
            case "psychic" -> "[공격] 정신 폭발로 밀치기";
            case "mindblast" -> "[공격] 주변 적 기절 + 전향";
            case "shadow" -> "[소환] 내 그림자 (하나만)";
            case "mcharge" -> "[충전] 때리고 충전 쌓기";
            case "kick" -> "[필살기] 발차기 (충전 소모)";
            case "dualstrike" -> "[필살기] 양손 손톱 연타 (충전 소모)";
            case "flight" -> "[필살기] 적에게 순간이동 후 발차기";
            case "golem" -> "[소환] 골렘 (한 번에 한 마리, 시간 제한 없음)";
            case "display" -> "[표시만] 아직 효과 없음";
            default -> kind;
        };
    }

    private String statLabel(String stat) {
        return switch (stat) {
            case "damage-pct", "damage-bonus-pct" -> "피해";
            case "magic-pct" -> "마법 피해";
            case "bolt-magic-pct" -> "빛줄기 마법 피해";
            case "damage" -> "오라 피해";
            case "heal" -> "치유량";
            case "stun-seconds" -> "기절 지속시간";
            case "duration", "stack-seconds" -> "지속시간(초)";
            case "poison-dps" -> "초당 독 피해";
            case "poison-seconds" -> "독 지속시간";
            case "explosion-damage" -> "폭발 피해";
            case "pool-dps" -> "불길 초당 피해";
            case "freeze-seconds" -> "빙결 지속시간";
            case "fury-lightning" -> "분열 번개 피해";
            case "ranged-damage-pct" -> "원거리 피해 증가";
            default -> stat;
        };
    }

    private List<String> describe(Player p, SkillDef s, int lv) {
        List<String> out = new ArrayList<>();
        ConfigurationSection c = s.sec;
        if (c.contains("damage-pct")) {
            out.add(ChatColor.GRAY + "피해: 무기 공격력의 " + fmt(val(p, s, "damage-pct", lv, 0)) + "%"
                    + (c.contains("flat-damage") ? " + " + fmt(val(p, s, "flat-damage", lv, 0)) : "")
                    + (c.getInt("hits", 1) > 1 ? " x" + c.getInt("hits") : ""));
        }
        if (c.contains("magic-pct") || hasSynergyFor(s, "magic-pct")) {
            out.add(ChatColor.LIGHT_PURPLE + "마법(비전) 피해: 무기 공격력의 " + fmt(val(p, s, "magic-pct", lv, 0)) + "% (방어/저항 무시)");
        }
        if (c.contains("bolt-magic-pct")) {
            out.add(ChatColor.LIGHT_PURPLE + "빛줄기: 무기 공격력의 " + fmt(val(p, s, "bolt-magic-pct", lv, 0)) + "% 마법 피해, 최대 "
                    + fmt(val(p, s, "max-bolts", lv, 8)) + "발");
        }
        if (c.contains("undead-bonus-pct")) {
            out.add(ChatColor.GRAY + "언데드/악마에게 +" + fmt(val(p, s, "undead-bonus-pct", lv, 0)) + "% 피해");
        }
        if (c.contains("convert-chance")) {
            out.add(ChatColor.LIGHT_PURPLE + "전향 확률 " + fmt(val(p, s, "convert-chance", lv, 0)) + "%, "
                    + fmt(val(p, s, "convert-seconds", lv, 0)) + "초 (보스 제외)");
        }
        if (c.contains("heal")) out.add(ChatColor.GREEN + "맞은 아군 치유: " + fmt(val(p, s, "heal", lv, 0)));
        if (c.contains("self-damage-pct")) {
            out.add(ChatColor.RED + "사용 시 최대 생명력의 " + fmt(val(p, s, "self-damage-pct", lv, 0)) + "% 소모");
        }
        if (c.contains("thorns-pct")) {
            out.add(ChatColor.GRAY + "근접으로 맞으면 받은 피해의 " + fmt(val(p, s, "thorns-pct", lv, 0)) + "% 반사");
        }
        if (c.getBoolean("undead-only", false)) out.add(ChatColor.GRAY + "언데드에게만 피해");
        if (c.contains("adjacent-radius-yd")) out.add(ChatColor.GRAY + "주변 적을 번갈아 연속 공격");
        if (c.getBoolean("requires-shield", false)) out.add(ChatColor.RED + "왼손에 방패를 들어야 함");
        if (c.getString("requires-weapon", "").equals("spear")) out.add(ChatColor.RED + "창(삼지창/투창)을 들고 찔러야 함");
        else if (!c.getString("requires-weapon", "").isEmpty()) out.add(ChatColor.RED + weaponLabel(c.getString("requires-weapon", "")) + "을(를) 들어야 함");
        if (c.contains("melee-poison-dps")) out.add(ChatColor.GREEN + "맞은 적 중독: 초당 " + fmt(val(p, s, "melee-poison-dps", lv, 0)) + ", " + fmt(val(p, s, "melee-poison-seconds", lv, 3)) + "초");
        describeAmazon(out, p, s, lv);
        describeNecro(out, p, s, lv);
        describeSummon(out, p, s, lv);
        describeSorc(out, p, s, lv);
        describeAmzSummon(out, p, s, lv);
        describeAssassin(out, p, s, lv);
        describeMartial(out, p, s, lv);
        describeDruid(out, p, s, lv);
        describeDruidSummon(out, p, s, lv);
        if (c.contains("max-radius-yd")) out.add(ChatColor.GRAY + "최대 범위: " + fmt(val(p, s, "max-radius-yd", lv, 0) * lengthScale()) + "칸");
        if (c.contains("damage-min")) {
            double mn = val(p, s, "damage-min", lv, 0);
            double bonus = 1.0 + val(p, s, "damage-bonus-pct", lv, 0) / 100.0;
            double rg = scaled(c, "damage-range", lv, 10);
            out.add(ChatColor.GRAY + "피해: " + fmt(mn * bonus) + " ~ " + fmt((mn + rg) * bonus) + " (고정)");
        }
        if (c.contains("radius") || c.contains("radius-yd")) out.add(ChatColor.GRAY + "범위: " + fmt(radius(p, s, lv, 0)) + "칸");
        if (c.contains("range") || c.contains("range-yd")) {
            double r = c.contains("range-yd") ? val(p, s, "range-yd", lv, 0) * lengthScale() : val(p, s, "range", lv, 0);
            out.add(ChatColor.GRAY + "사거리: " + fmt(r) + "칸");
        }
        if (c.contains("duration")) out.add(ChatColor.GRAY + "지속: " + fmt(val(p, s, "duration", lv, 0)) + "초");
        if (c.contains("flee-seconds")) {
            out.add(ChatColor.GRAY + "도망: " + fmt(val(p, s, "flee-seconds", lv, 0)) + "초, "
                    + fmt(val(p, s, "flee-dist-yd", lv, 0) * lengthScale()) + "칸");
        }
        if (c.contains("stun-seconds")) out.add(ChatColor.GRAY + "기절: " + fmt(val(p, s, "stun-seconds", lv, 0)) + "초");
        if (c.contains("knockback")) out.add(ChatColor.GRAY + "밀어내기: " + fmt(val(p, s, "knockback", lv, 0)));
        if (c.contains("attack-speed-max")) {
            out.add(ChatColor.GRAY + "적중마다 공격 속도 최대 +" + fmt(scaled(c, "attack-speed-max", lv, 0)) + "% (" + fmt(val(p, s, "stack-seconds", lv, 6)) + "초 유지)");
        }
        if (c.getBoolean("requires-offhand", false)) out.add(ChatColor.RED + "왼손에도 무기를 들어야 함");
        if (c.getBoolean("dual-targets", false)) out.add(ChatColor.GRAY + "왼손 무기가 있으면 두 대상을 한 번씩 공격");
        for (String section : new String[]{"curse", "curse2", "curse3"}) {
            ConfigurationSection cu = c.getConfigurationSection(section);
            if (cu != null) {
                out.add(ChatColor.GRAY + "저주(" + cu.getString("type", "") + "): " + fmt(scaled(cu, "amount", lv, 0))
                        + (cu.contains("duration") ? " / " + fmt(scaled(cu, "duration", lv, 0)) + "초" : ""));
            }
        }
        ConfigurationSection b = c.getConfigurationSection("bonuses");
        if (b != null) {
            double defScale = plugin.getConfig().getDouble("skill-system.defense-scale", 0.2);
            for (String name : b.getKeys(false)) {
                double v = synBonus(p, s, name, scaled(b, name, lv, 0));
                if (name.equals("방어력 증가")) v *= defScale;
                out.add(ChatColor.AQUA + name + " +" + fmt(v));
            }
            if (!c.getString("weapon", "").isEmpty()) out.add(ChatColor.GRAY + "해당 무기를 들고 있을 때만 적용");
        }
        ConfigurationSection dsp = c.getConfigurationSection("display");
        if (dsp != null) {
            for (String name : dsp.getKeys(false)) {
                out.add(ChatColor.DARK_GRAY + name + " " + fmt(scaled(dsp, name, lv, 0)) + " (표시만)");
            }
        }
        if (c.contains("mana")) out.add(ChatColor.BLUE + "마나: " + fmt(val(p, s, "mana", lv, 0)));
        if (s.speed.equals("attack")) out.add(ChatColor.BLUE + "공격 속도의 영향을 받음");
        if (s.speed.equals("cast")) out.add(ChatColor.BLUE + "시전 속도의 영향을 받음");
        for (Syn sy : s.syn) {
            SkillDef src = skills.get(sy.skill);
            if (src == null) continue;
            out.add(ChatColor.DARK_AQUA + "시너지: " + src.name + " 레벨당 " + statLabel(sy.stat) + " +" + fmt(sy.per)
                    + (sy.pct || sy.stat.endsWith("-pct") ? "%" : ""));
        }
        return out;
    }

    private boolean hasSynergyFor(SkillDef s, String stat) {
        for (Syn sy : s.syn) if (sy.stat.equals(stat)) return true;
        return false;
    }

    private static String fmt(double v) {
        if (Math.abs(v - Math.rint(v)) < 0.005) return String.valueOf((long) Math.rint(v));
        return String.format(Locale.ROOT, "%.1f", v);
    }

    private void openClassChooser(Player p) {
        SkillHolder h = new SkillHolder("class");
        h.inv = Bukkit.createInventory(h, 9, ChatColor.DARK_RED + "직업 선택");
        int slot = 1; // 0.24.1: 직업이 6개가 되어 1~7번 칸(최대 7개)을 쓴다
        for (ClassDef c : classes.values()) {
            if (slot > 7) break;
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + c.desc);
            lore.add("");
            lore.add(ChatColor.YELLOW + "클릭하여 선택");
            h.inv.setItem(slot, named(c.icon, ChatColor.GOLD + c.name, lore));
            h.slotSkill.put(slot, c.id);
            slot++;
        }
        p.openInventory(h.inv);
    }

    private void chooseClass(Player p, String classId) {
        ClassDef c = classes.get(classId);
        if (c == null) return;
        PData d = data(p);
        if (d.cls != null && !d.cls.equals(classId)) {
            msg(p, ChatColor.RED + "이미 직업이 있습니다. /rpgskill reset 으로 초기화 후 다시 고르세요.");
            return;
        }
        d.cls = classId;
        d.maxLevel = Math.max(d.maxLevel, p.getLevel());
        save(p);
        plugin.statSystem().restoreFullLater(p);
        p.sendMessage(ChatColor.GREEN + "직업 선택: " + c.name + ChatColor.GRAY + "  (/rpgskill 로 스킬 트리를 엽니다)");
    }

    @EventHandler
    public void onGuiClick(InventoryClickEvent e) {
        Inventory top = e.getInventory();
        if (!(top.getHolder() instanceof SkillHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != top) return;
        int slot = e.getSlot();

        if (h.type.equals("class")) {
            String cid = h.slotSkill.get(slot);
            if (cid != null) {
                chooseClass(p, cid);
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> openTree(p, 0));
            }
            return;
        }

        // 탭 버튼 (오른쪽 줄 8, 17, 26번 칸)
        ClassDef cd = classes.get(data(p).cls);
        if (cd != null && slot % 9 == 8 && slot / 9 < Math.min(3, cd.tabs.size())) {
            h.tab = slot / 9;
            render(p, h);
            return;
        }

        String id = h.slotSkill.get(slot);
        if (id == null) return;
        SkillDef s = skills.get(id);
        if (s == null) return;
        PData d = data(p);
        ClickType ct = e.getClick();
        boolean bindable = !s.kind.equals("passive") && !s.kind.equals("display");

        if (ct == ClickType.NUMBER_KEY) {
            int b = e.getHotbarButton();
            if (b <= 0 || b > 8) {
                msg(p, ChatColor.GRAY + "숫자키 1은 무기 칸입니다. 2~9를 사용하세요.");
                return;
            }
            if (cycleMode() && (b == 1 || b == 8)) {
                msg(p, ChatColor.GRAY + "숫자키 2와 9는 스킬 넘기기 전용입니다. 3~8을 사용하세요.");
                return;
            }
            if (!bindable) {
                msg(p, ChatColor.GRAY + "이 스킬은 등록할 수 없습니다.");
                return;
            }
            if (d.levels.getOrDefault(id, 0) <= 0) {
                msg(p, ChatColor.RED + "먼저 스킬을 배우세요.");
                return;
            }
            for (int i = 1; i < 9; i++) if (id.equals(d.hot[i])) d.hot[i] = null;
            d.hot[b] = id;
            save(p);
            render(p, h);
            return;
        }
        if (ct == ClickType.DROP || ct == ClickType.CONTROL_DROP) {
            for (int i = 1; i < 9; i++) if (id.equals(d.hot[i])) d.hot[i] = null;
            if (id.equals(d.left)) d.left = null;
            if (id.equals(d.right)) d.right = null;
            save(p);
            render(p, h);
            return;
        }
        if (ct == ClickType.LEFT || ct == ClickType.SHIFT_LEFT) {
            if (learn(p, d, s)) render(p, h);
            return;
        }
        if (ct == ClickType.RIGHT || ct == ClickType.SHIFT_RIGHT) {
            if (!bindable) {
                msg(p, ChatColor.GRAY + "이 스킬은 장착할 수 없습니다.");
                return;
            }
            if (d.levels.getOrDefault(id, 0) <= 0) {
                msg(p, ChatColor.RED + "먼저 스킬을 배우세요.");
                return;
            }
            if (ct == ClickType.SHIFT_RIGHT) d.left = id;
            else d.right = id;
            save(p);
            render(p, h);
        }
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof SkillHolder) e.setCancelled(true);
    }

    // ===================================================================
    //  /rpgskill
    // ===================================================================

    boolean handleCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("플레이어만 사용할 수 있습니다.");
            return true;
        }
        if (!enabled()) {
            sender.sendMessage(ChatColor.RED + "스킬 시스템이 꺼져 있습니다. (config skill-system.enabled)");
            return true;
        }
        PData d = data(p);
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "" -> {
                openTree(p, 0);
                return true;
            }
            case "class" -> {
                if (args.length < 2) {
                    p.sendMessage(ChatColor.YELLOW + "직업 목록:");
                    for (ClassDef c : classes.values()) p.sendMessage(ChatColor.GRAY + " - " + c.id + " (" + c.name + ")");
                    p.sendMessage(ChatColor.GRAY + "현재 직업: " + (d.cls == null ? "없음" : d.cls));
                    return true;
                }
                if (!classes.containsKey(args[1].toLowerCase(Locale.ROOT))) {
                    p.sendMessage(ChatColor.RED + "그런 직업이 없습니다.");
                    return true;
                }
                chooseClass(p, args[1].toLowerCase(Locale.ROOT));
                return true;
            }
            case "mode", "hotkeys" -> {
                d.hotkeys = !d.hotkeys;
                save(p);
                p.sendMessage(ChatColor.YELLOW + "숫자키 스킬 선택: " + (d.hotkeys ? ChatColor.GREEN + "켜짐" : ChatColor.RED + "꺼짐 (숫자키가 평소처럼 아이템을 바꿉니다)"));
                return true;
            }
            case "left", "right" -> {
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "/rpgskill " + sub + " <스킬id|none>");
                    return true;
                }
                String id = args[1].toLowerCase(Locale.ROOT);
                if (id.equals("none")) {
                    if (sub.equals("left")) d.left = null;
                    else d.right = null;
                    save(p);
                    p.sendMessage(ChatColor.GRAY + "해제했습니다.");
                    return true;
                }
                SkillDef s = skills.get(id);
                if (s == null || s.kind.equals("passive") || s.kind.equals("display") || d.levels.getOrDefault(id, 0) <= 0) {
                    p.sendMessage(ChatColor.RED + "배운 액티브 스킬만 장착할 수 있습니다. (/rpgskill info)");
                    return true;
                }
                if (sub.equals("left")) d.left = id;
                else d.right = id;
                save(p);
                p.sendMessage(ChatColor.GREEN + (sub.equals("left") ? "좌클릭" : "우클릭") + " 스킬: " + s.name);
                return true;
            }
            case "bind" -> {
                if (args.length < 3) {
                    p.sendMessage(ChatColor.RED + "/rpgskill bind <2~9> <스킬id|none>");
                    return true;
                }
                int n;
                try {
                    n = Integer.parseInt(args[1]);
                } catch (NumberFormatException ex) {
                    p.sendMessage(ChatColor.RED + "숫자는 2~9 입니다.");
                    return true;
                }
                if (n < 2 || n > 9) {
                    p.sendMessage(ChatColor.RED + "숫자는 2~9 입니다. (1번은 무기 칸)");
                    return true;
                }
                if (cycleMode() && (n == 2 || n == 9)) {
                    p.sendMessage(ChatColor.RED + "숫자키 2와 9는 스킬 넘기기 전용입니다. 3~8을 사용하세요. (config skill-system.scroll-cycle)");
                    return true;
                }
                String id = args[2].toLowerCase(Locale.ROOT);
                if (id.equals("none")) {
                    d.hot[n - 1] = null;
                } else {
                    SkillDef s = skills.get(id);
                    if (s == null || s.kind.equals("passive") || s.kind.equals("display") || d.levels.getOrDefault(id, 0) <= 0) {
                        p.sendMessage(ChatColor.RED + "배운 액티브 스킬만 등록할 수 있습니다.");
                        return true;
                    }
                    d.hot[n - 1] = id;
                }
                save(p);
                p.sendMessage(ChatColor.GREEN + "숫자키 " + n + " 등록 완료");
                return true;
            }
            case "learn" -> {
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "/rpgskill learn <스킬id>");
                    return true;
                }
                SkillDef s = skills.get(args[1].toLowerCase(Locale.ROOT));
                if (s == null || !s.classId.equals(d.cls)) {
                    p.sendMessage(ChatColor.RED + "내 직업의 스킬 id가 아닙니다. (/rpgskill info)");
                    return true;
                }
                if (learn(p, d, s)) p.sendMessage(ChatColor.GREEN + s.name + " Lv" + d.levels.get(s.id));
                return true;
            }
            case "reset" -> {
                if (!plugin.getConfig().getBoolean("skill-system.allow-reset", true) && !p.hasPermission("diablorpg.admin")) {
                    p.sendMessage(ChatColor.RED + "초기화가 허용되지 않습니다.");
                    return true;
                }
                d.cls = null;
                d.levels.clear();
                d.left = null;
                d.right = null;
                d.activeAura = null;
                for (int i = 0; i < d.hot.length; i++) d.hot[i] = null;
                save(p);
                p.sendMessage(ChatColor.YELLOW + "스킬을 초기화했습니다. /rpgskill 로 직업을 다시 고르세요.");
                return true;
            }
            case "points" -> {
                if (args.length >= 3 && args[1].equalsIgnoreCase("give")) {
                    if (!p.hasPermission("diablorpg.admin")) {
                        p.sendMessage(ChatColor.RED + "권한이 없습니다.");
                        return true;
                    }
                    try {
                        d.bonusPoints += Integer.parseInt(args[2]);
                    } catch (NumberFormatException ex) {
                        p.sendMessage(ChatColor.RED + "숫자를 입력하세요.");
                        return true;
                    }
                    save(p);
                }
                p.sendMessage(ChatColor.YELLOW + "스킬 포인트: 남은 " + freePoints(d) + " / 총 " + totalPoints(d)
                        + ChatColor.GRAY + " (최대 도달 레벨 " + d.maxLevel + ", 관리자 지급 " + d.bonusPoints + ")");
                return true;
            }
            case "level" -> {
                // 관리자 테스트용: 스킬 필요 레벨(티어) 조건을 만족시키려고 "도달한 최대 레벨"을 올린다.
                if (!p.hasPermission("diablorpg.admin")) {
                    p.sendMessage(ChatColor.RED + "권한이 없습니다.");
                    return true;
                }
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "/rpgskill level <숫자>  (필요 레벨 테스트용, 포인트도 같이 늘어납니다)");
                    return true;
                }
                try {
                    d.maxLevel = Math.max(d.maxLevel, Integer.parseInt(args[1]));
                    plugin.statSystem().adminSetMaxLevel(p, Integer.parseInt(args[1]));
                } catch (NumberFormatException ex) {
                    p.sendMessage(ChatColor.RED + "숫자를 입력하세요.");
                    return true;
                }
                save(p);
                p.sendMessage(ChatColor.YELLOW + "도달 레벨: " + d.maxLevel + "  남은 포인트: " + freePoints(d));
                return true;
            }
            case "cast" -> {
                if (!p.hasPermission("diablorpg.admin")) {
                    p.sendMessage(ChatColor.RED + "권한이 없습니다.");
                    return true;
                }
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "/rpgskill cast <스킬id>  (무기 칸 조건 없이 시험 시전)");
                    return true;
                }
                SkillDef s = skills.get(args[1].toLowerCase(Locale.ROOT));
                if (s == null) {
                    p.sendMessage(ChatColor.RED + "스킬 id를 찾을 수 없습니다.");
                    return true;
                }
                tryCast(p, s, null, false);
                return true;
            }
            case "info" -> {
                printInfo(p, d);
                return true;
            }
            default -> {
                p.sendMessage(ChatColor.YELLOW + "/rpgskill [class|mode|left|right|bind|learn|reset|points|level|cast|info]");
                return true;
            }
        }
    }

    private void printInfo(Player p, PData d) {
        p.sendMessage(ChatColor.GOLD + "=== 스킬 정보 ===");
        p.sendMessage(ChatColor.YELLOW + "직업: " + ChatColor.WHITE + (d.cls == null ? "없음" : d.cls)
                + ChatColor.YELLOW + "  포인트: " + ChatColor.WHITE + freePoints(d) + "/" + totalPoints(d)
                + ChatColor.YELLOW + "  도달 레벨: " + ChatColor.WHITE + d.maxLevel
                + ChatColor.YELLOW + "  숫자키: " + ChatColor.WHITE + (d.hotkeys ? "켜짐" : "꺼짐"));
        p.sendMessage(ChatColor.YELLOW + "좌: " + ChatColor.WHITE + nz(d.left) + ChatColor.YELLOW + "  우: " + ChatColor.WHITE + nz(d.right)
                + ChatColor.YELLOW + "  오라: " + ChatColor.WHITE + nz(d.activeAura));
        StringBuilder hot = new StringBuilder();
        for (int i = 1; i < 9; i++) if (d.hot[i] != null) hot.append(i + 1).append("=").append(d.hot[i]).append(" ");
        p.sendMessage(ChatColor.YELLOW + "숫자키: " + ChatColor.WHITE + hot);
        for (SkillDef s : skills.values()) {
            if (!s.classId.equals(d.cls)) continue;
            int base = d.levels.getOrDefault(s.id, 0);
            if (base <= 0) continue;
            p.sendMessage(ChatColor.GRAY + " " + s.id + " (" + s.name + ") " + ChatColor.WHITE + base
                    + (level(p, d, s) > base ? ChatColor.AQUA + " → " + level(p, d, s) : ""));
        }
        Gear g = gearOf(p);
        p.sendMessage(ChatColor.YELLOW + "장비: 모든스킬 +" + g.all + " 시전속도 +" + g.castSpeed + "% 직업 " + g.cls + " 스킬레벨 " + g.lv
                + " 오라 " + g.aura + " 발동 " + g.proc);
        p.sendMessage(ChatColor.YELLOW + "스킬 보너스 합계: " + ChatColor.WHITE + cached(p).totals);
        AttributeInstance as = p.getAttribute(VersionCompat.ATTACK_SPEED);
        AttributeInstance ms = p.getAttribute(VersionCompat.MOVEMENT_SPEED);
        p.sendMessage(ChatColor.YELLOW + "공격속도 속성: " + ChatColor.WHITE + (as == null ? "-" : fmt(as.getValue()) + " (기본 " + fmt(as.getBaseValue()) + ")")
                + ChatColor.YELLOW + "  이동속도 속성: " + ChatColor.WHITE + (ms == null ? "-" : String.format(Locale.ROOT, "%.3f", ms.getValue()) + " (기본 " + String.format(Locale.ROOT, "%.3f", ms.getBaseValue()) + ")"));
        Frenzy fz = frenzy.get(p.getUniqueId());
        p.sendMessage(ChatColor.YELLOW + "광분 중첩: " + ChatColor.WHITE + (fz == null || fz.until < System.currentTimeMillis()
                ? "없음(만료)" : fz.stacks + "중첩, 남은 " + ((fz.until - System.currentTimeMillis()) / 1000) + "초"));
        LivingEntity look = findTarget(p, 20);
        if (look != null) {
            Map<String, Curse> m = curses.get(look.getUniqueId());
            p.sendMessage(ChatColor.YELLOW + "바라보는 대상 저주: " + ChatColor.WHITE + (m == null ? "없음" : describeCurses(m)));
        }
    }

    private String describeCurses(Map<String, Curse> m) {
        StringBuilder sb = new StringBuilder();
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Curse> e : m.entrySet()) {
            if (e.getValue().until < now) continue;
            sb.append(e.getKey()).append("=").append(fmt(e.getValue().amount))
                    .append("(").append((e.getValue().until - now) / 1000).append("s) ");
        }
        return sb.length() == 0 ? "없음" : sb.toString();
    }

    // ===================================================================
    //  0.18.0: 네크로맨서 (시체 / 독 / 뼈 / 저주)  [미검증]
    //   - 시체: 몹이 죽으면 "기록"만 남긴다 (엔티티 없음). 시체를 쓰는 직업 플레이어가 근처에 있을 때만 기록하고,
    //     corpse.seconds 가 지나거나 corpse.max-total 을 넘으면 사라진다. 조준한 시체에 스킬을 쓴다.
    //   - kind: missile(투사체: 이빨/뼈 창/뼈 영혼/맹독 확산) / corpse(시체 폭발/맹독 폭발) / shield(뼈 갑옷) / wall(뼈의 벽/뼈 감옥)
    //   - 소환(해골/골렘)은 0.19.0. 지금은 트리에 표시만 된다.
    // ===================================================================

    static final class Corpse {
        World world;
        Location loc;
        org.bukkit.entity.EntityType type;
        double maxHealth;
        long until;
        boolean looted;
    }

    static final class Dot {
        UUID owner;
        double dps;
        long until;
    }

    static final class TempBlock {
        World world;
        int x;
        int y;
        int z;
        long until;
    }

    private final List<Corpse> corpses = new ArrayList<>();
    private final Map<UUID, Dot> dots = new HashMap<>();
    private final Map<UUID, double[]> shields = new HashMap<>();       // {남은 흡수량, 끝나는 시각(ms)}
    private final Map<String, TempBlock> tempBlocks = new LinkedHashMap<>();

    private static String tbKey(World w, int x, int y, int z) {
        return w.getName() + ";" + x + ";" + y + ";" + z;
    }

    // ---------------------------------------------------------------- 시체

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCorpseDeath(org.bukkit.event.entity.EntityDeathEvent e) {
        if (!enabled() || !plugin.getConfig().getBoolean("corpse.enabled", true)) return;
        LivingEntity le = e.getEntity();
        if (isSummonEntity(le)) return;
        if (!(le instanceof Mob) || le instanceof ArmorStand || le instanceof Villager || le instanceof WanderingTrader) return;
        if (le instanceof Tameable tm && tm.isTamed()) return;
        List<String> cls = plugin.getConfig().isList("corpse.record-near-classes")
                ? plugin.getConfig().getStringList("corpse.record-near-classes") : List.of("necromancer");
        double r = plugin.getConfig().getDouble("corpse.record-radius", 48.0);
        boolean near = false;
        for (Player p : le.getWorld().getPlayers()) {
            if (p.getLocation().distanceSquared(le.getLocation()) > r * r) continue;
            String c = data(p).cls;
            if (c != null && cls.contains(c)) {
                near = true;
                break;
            }
            if ("barbarian".equals(c) && (passiveSum(p, "find-item-pct") > 0 || passiveSum(p, "find-potion-pct") > 0)) {
                near = true;
                break;
            }
        }
        if (!near) return;
        Corpse c = new Corpse();
        c.world = le.getWorld();
        c.loc = le.getLocation().clone();
        c.type = le.getType();
        AttributeInstance mh = le.getAttribute(VersionCompat.MAX_HEALTH);
        c.maxHealth = mh == null ? 20.0 : mh.getValue();
        c.until = System.currentTimeMillis() + (long) (plugin.getConfig().getDouble("corpse.seconds", 30.0) * 1000.0);
        corpses.add(c);
        int max = Math.max(10, plugin.getConfig().getInt("corpse.max-total", 200));
        while (corpses.size() > max) corpses.remove(0);
    }

    /** 바바리안 물약/아이템 발견: 시체 가까이에서 웅크리면 시체를 뒤진다 (시체마다 한 번). */
    @EventHandler(ignoreCancelled = true)
    public void onLootSneak(org.bukkit.event.player.PlayerToggleSneakEvent e) {
        if (!e.isSneaking() || !enabled()) return;
        Player p = e.getPlayer();
        double itemPct = passiveSum(p, "find-item-pct");
        double potPct = passiveSum(p, "find-potion-pct");
        if (itemPct <= 0 && potPct <= 0) return;
        long now = System.currentTimeMillis();
        double reach = plugin.getConfig().getDouble("corpse.loot-radius", 3.0);
        Corpse best = null;
        double bd = Double.MAX_VALUE;
        for (Corpse c : corpses) {
            if (c.looted || c.world != p.getWorld() || c.until < now) continue;
            double d = c.loc.distanceSquared(p.getLocation());
            if (d <= reach * reach && d < bd) {
                bd = d;
                best = c;
            }
        }
        if (best == null) return;
        best.looted = true;
        Location at = best.loc.clone().add(0, 0.5, 0);
        boolean any = false;
        GoldSystem gs = plugin.goldSystem();
        if (gs != null && random.nextDouble() * 100.0 < itemPct) {
            ItemStack it = gs.rollCorpseItem(p);
            if (it != null) {
                best.world.dropItemNaturally(at, it);
                any = true;
            }
        }
        if (gs != null && random.nextDouble() * 100.0 < potPct) {
            ItemStack po = gs.rollCorpsePotion();
            if (po != null) {
                best.world.dropItemNaturally(at, po);
                any = true;
            }
        }
        best.world.spawnParticle(any ? Particle.HAPPY_VILLAGER : Particle.SMOKE, at, any ? 12 : 6, 0.3, 0.3, 0.3, 0.0);
        best.world.playSound(at, any ? Sound.ENTITY_ITEM_PICKUP : Sound.BLOCK_GRAVEL_BREAK, 0.8f, any ? 1.2f : 0.8f);
        msg(p, any ? ChatColor.GREEN + "시체에서 무언가를 찾았다!" : ChatColor.GRAY + "시체를 뒤졌지만 아무것도 없었다.");
    }

    /** 시선 방향에 가까운 시체 (사거리 안, 시선에서 2칸 이내 중 가장 가까운 것). */
    private Corpse findCorpse(Player p, double range) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection();
        long now = System.currentTimeMillis();
        Corpse best = null;
        double bs = Double.MAX_VALUE;
        for (Corpse c : corpses) {
            if (c.world != p.getWorld() || c.until < now) continue;
            Vector v = c.loc.toVector().add(new Vector(0, 0.4, 0)).subtract(eye.toVector());
            double t = v.dot(dir);
            if (t < 0 || t > range) continue;
            double perp = v.clone().subtract(dir.clone().multiply(t)).length();
            if (perp > 2.0) continue;
            double score = perp + t * 0.02;
            if (score < bs) {
                bs = score;
                best = c;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- 1초 틱: 시체 표시 / 독 / 임시 블록

    private void necroTick() {
        long now = System.currentTimeMillis();
        Iterator<Corpse> ci = corpses.iterator();
        while (ci.hasNext()) {
            Corpse c = ci.next();
            if (c.until < now || c.world == null) {
                ci.remove();
                continue;
            }
            c.world.spawnParticle(Particle.WITCH, c.loc.clone().add(0, 0.3, 0), 2, 0.25, 0.1, 0.25, 0.0);
        }
        Iterator<Map.Entry<UUID, Dot>> di = dots.entrySet().iterator();
        while (di.hasNext()) {
            Map.Entry<UUID, Dot> en = di.next();
            Dot d = en.getValue();
            Entity ent = Bukkit.getEntity(en.getKey());
            Player owner = Bukkit.getPlayer(d.owner);
            if (d.until < now || owner == null || !(ent instanceof LivingEntity le) || !le.isValid() || le.isDead()) {
                di.remove();
                continue;
            }
            pureHit(owner, le, d.dps);
            le.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, le.getLocation().add(0, le.getHeight() * 0.6, 0), 3, 0.2, 0.3, 0.2, 0.0);
        }
        boolean changed = false;
        Iterator<TempBlock> ti = tempBlocks.values().iterator();
        while (ti.hasNext()) {
            TempBlock tb = ti.next();
            if (tb.until >= now) continue;
            org.bukkit.block.Block b = tb.world.getBlockAt(tb.x, tb.y, tb.z);
            if (b.getType() == Material.BONE_BLOCK) b.setType(Material.AIR);
            ti.remove();
            changed = true;
        }
        if (changed) saveTempBlocks();
    }

    /** 독 지속 피해: 겹치지 않고 가장 센 것 하나만, 지속시간은 늘려 준다. */
    private void poisonDot(Player owner, LivingEntity t, double dps, double seconds) {
        if (dps <= 0 || seconds <= 0 || t.isDead()) return;
        long now = System.currentTimeMillis();
        long until = now + (long) (seconds * 1000.0);
        Dot d = dots.get(t.getUniqueId());
        if (d == null || d.until < now || d.dps <= dps) {
            long keep = d == null ? 0L : d.until;
            d = new Dot();
            d.owner = owner.getUniqueId();
            d.dps = dps;
            d.until = Math.max(until, keep);
            dots.put(t.getUniqueId(), d);
        } else {
            d.until = Math.max(d.until, until);
        }
    }

    // ---------------------------------------------------------------- kind: corpse (시체 폭발 / 맹독 폭발)

    private boolean doCorpse(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        double range = val(p, s, "range", lv, 24.0);
        Corpse c = findCorpse(p, range);
        if (c == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 조준한 곳에 시체가 없습니다.");
            return false;
        }
        corpses.remove(c);
        final Location at = c.loc.clone();
        final World w = c.world;
        if (s.sec.getString("corpse-mode", "explode").equals("poison")) {
            addCloud(p, at, radius(p, s, lv, 5.0), val(p, s, "poison-seconds", lv, 4.0), val(p, s, "poison-dps", lv, 8.0), "poison");
            w.spawnParticle(Particle.HAPPY_VILLAGER, at.clone().add(0, 0.5, 0), 40, 1.0, 0.4, 1.0, 0.0);
            w.playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 0.4f, 1.8f);
        } else {
            double radius = radius(p, s, lv, 6.0);
            double dmg = c.maxHealth * val(p, s, "corpse-hp-pct", lv, 60.0) / 100.0 + val(p, s, "flat-damage", lv, 0.0);
            for (LivingEntity t : around(at, radius, p)) pureHit(p, t, dmg);
            w.spawnParticle(Particle.FLAME, at.clone().add(0, 0.5, 0), 40, radius * 0.3, 0.4, radius * 0.3, 0.05);
            w.spawnParticle(Particle.CLOUD, at.clone().add(0, 0.5, 0), 15, radius * 0.25, 0.3, radius * 0.25, 0.03);
            w.playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 0.9f, 1.0f);
        }
        return true;
    }

    // ---------------------------------------------------------------- kind: missile (이빨 / 뼈 창 / 뼈 영혼 / 맹독 확산)

    private Particle missileParticle(String name) {
        return switch (name) {
            case "poison" -> Particle.HAPPY_VILLAGER;
            case "spirit" -> Particle.WITCH;
            case "fire" -> Particle.FLAME;
            case "cold" -> Particle.SNOWFLAKE;
            case "lightning" -> Particle.ELECTRIC_SPARK;
            default -> Particle.END_ROD; // bone
        };
    }

    private boolean doMissile(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final double range = val(p, s, "range", lv, 28.0);
        final boolean radial = s.sec.getBoolean("radial", false);
        final boolean homing = s.sec.getBoolean("homing", false);
        final boolean pierce = s.sec.getBoolean("pierce", false);
        final int n = Math.max(1, (int) val(p, s, "shots", lv, 1.0));
        final Location eye = p.getEyeLocation();
        LivingEntity t = null;
        Vector base = eye.getDirection();
        if (!radial) {
            t = forced != null ? forced : findTarget(p, range);
            if (t != null) {
                Vector to = aimPoint(t).subtract(eye.toVector());
                if (to.lengthSquared() > 0.0001) base = to;
            }
        }
        base = base.clone().normalize();
        final List<Vector> dirs = new ArrayList<>();
        if (radial) {
            for (int i = 0; i < n; i++) {
                double a = Math.PI * 2.0 * i / n;
                dirs.add(new Vector(Math.cos(a), 0.0, Math.sin(a)));
            }
        } else if (s.sec.contains("random-cone-deg")) {
            double cone = Math.toRadians(s.sec.getDouble("random-cone-deg", 70.0));
            for (int i = 0; i < n; i++) {
                Vector v = base.clone().rotateAroundY((random.nextDouble() - 0.5) * cone);
                v.setY(v.getY() + (random.nextDouble() - 0.5) * 0.4);
                dirs.add(v.normalize());
            }
        } else if (n <= 1) {
            dirs.add(base);
        } else {
            double step = Math.toRadians(val(p, s, "spread-step-deg", lv, 6.0));
            double max = Math.toRadians(s.sec.getDouble("spread-max-deg", 90.0));
            double total = Math.min(max, step * (n - 1));
            for (int i = 0; i < n; i++) {
                dirs.add(base.clone().rotateAroundY(-total / 2.0 + total * i / (n - 1)));
            }
        }
        final double magic = attackPower(p) * val(p, s, "magic-pct", lv, 0.0) / 100.0 + val(p, s, "magic-flat", lv, 0.0);
        final double phys = s.sec.contains("damage-pct") ? skillDamage(p, s, lv) : 0.0;
        final double pdps = val(p, s, "poison-dps", lv, 0.0);
        final double psec = val(p, s, "poison-seconds", lv, 0.0);
        final String mel = s.sec.getString("element", "");
        final double edmg = val(p, s, "elem-damage", lv, 0.0);
        final double mfrz = val(p, s, "freeze-seconds", lv, 0.0);
        final double mslw = val(p, s, "slow-seconds", lv, 0.0);
        final double exR = val(p, s, "explosion-radius", lv, 0.0);
        final Set<UUID> once = n > 1 && s.sec.getBoolean("once-per-target", false) ? new HashSet<>() : null;
        final Particle part = missileParticle(s.sec.getString("particle", "bone"));
        final double speed = s.sec.getDouble("missile-speed", 1.5);
        final LivingEntity aim = t;
        final java.util.function.Consumer<LivingEntity> onHit = le -> {
            if (phys > 0) hitSkill(p, le, phys, s, lv);
            if (magic > 0) pureHit(p, le, magic);
            if (pdps > 0 && psec > 0) poisonDot(p, le, pdps, psec);
            if (edmg > 0 && !mel.isEmpty()) elemHit(p, le, mel, edmg);
            if (mfrz > 0) freezeMob(le, mfrz);
            slowFor(le, mslw, 1);
            if (exR > 0 && !mel.isEmpty()) {
                for (LivingEntity o : around(le.getLocation(), exR, p)) {
                    if (o == le) continue;
                    elemHit(p, o, mel, edmg);
                    if (mfrz > 0) freezeMob(o, mfrz);
                }
                le.getWorld().spawnParticle(mel.equals("fire") ? Particle.FLAME : Particle.SNOWFLAKE, le.getLocation().add(0, 0.8, 0), 25, exR * 0.4, 0.4, exR * 0.4, 0.05);
                le.getWorld().playSound(le.getLocation(), mel.equals("fire") ? Sound.ENTITY_GENERIC_EXPLODE : Sound.BLOCK_GLASS_BREAK, 0.6f, 1.2f);
            }
            le.getWorld().spawnParticle(Particle.CRIT, aimPoint(le).toLocation(le.getWorld()), 5, 0.1, 0.1, 0.1, 0.05);
        };
        for (Vector dir : dirs) {
            Location from = radial ? p.getLocation().add(0, 1.0, 0).add(dir.clone().multiply(0.6))
                    : eye.clone().add(dir.clone().multiply(0.8)).subtract(0, 0.2, 0);
            flyMissile(p, from, dir, speed, range, pierce, homing, aim, part, once, onHit);
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 0.8f, radial ? 0.8f : 1.4f);
        return true;
    }

    /** 입자로 그리는 투사체. pierce 면 관통, homing 이면 앞쪽 적을 따라간다, once 가 있으면 한 적에게 한 번만. */
    private double missileScale; // 0이면 보통 크기. 다음 flyMissile 한 번에만 적용된다.

    private void flyMissile(Player p, Location from, Vector dir, double speed, double range, boolean pierce, boolean homing,
                            LivingEntity aim, Particle particle, Set<UUID> once,
                            java.util.function.Consumer<LivingEntity> onHit) {
        final double sc = missileScale; // 0.24.2: 큰 투사체 (불사조 일격 얼음살)
        missileScale = 0.0;
        final World w = p.getWorld();
        final Vector[] d = {dir.clone().normalize()};
        final Location pos = from.clone();
        final double[] traveled = {0.0};
        final Set<UUID> done = new HashSet<>();
        final LivingEntity[] lock = {aim};
        final BukkitTask[] task = new BukkitTask[1];
        task[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || p.getWorld() != w) {
                task[0].cancel();
                return;
            }
            if (homing) {
                LivingEntity g = lock[0];
                if (g == null || !g.isValid() || g.isDead() || done.contains(g.getUniqueId())) {
                    g = null;
                    double bd = Double.MAX_VALUE;
                    for (LivingEntity o : around(pos, 12.0, p)) {
                        if (done.contains(o.getUniqueId())) continue;
                        Vector to = aimPoint(o).subtract(pos.toVector());
                        if (to.lengthSquared() < 0.01 || to.clone().normalize().dot(d[0]) < 0.0) continue;
                        double dd = o.getLocation().distanceSquared(pos);
                        if (dd < bd) {
                            bd = dd;
                            g = o;
                        }
                    }
                    lock[0] = g;
                }
                if (g != null) {
                    Vector to = aimPoint(g).subtract(pos.toVector()).normalize();
                    d[0] = d[0].clone().multiply(0.65).add(to.multiply(0.35)).normalize();
                }
            }
            double step = Math.min(speed, range - traveled[0]);
            if (step <= 0.0) {
                task[0].cancel();
                return;
            }
            RayTraceResult br = w.rayTraceBlocks(pos, d[0], step, FluidCollisionMode.NEVER, true);
            double maxD = br == null ? step : pos.toVector().distance(br.getHitPosition());
            for (double dd = 0.0; dd <= maxD; dd += 0.6) {
                Location pl = pos.clone().add(d[0].clone().multiply(dd));
                w.spawnParticle(particle, pl, 1, 0.0, 0.0, 0.0, 0.0);
                if (sc > 0.0) {
                    dust(w, pl.getX(), pl.getY(), pl.getZ(), 0xCCE8FF, (float) (2.4 * sc));
                    w.spawnParticle(particle, pl, 4, 0.3 * sc, 0.3 * sc, 0.3 * sc, 0.01);
                }
            }
            Location mid = pos.clone().add(d[0].clone().multiply(maxD / 2.0));
            double rad = maxD / 2.0 + 1.0;
            List<LivingEntity> cand = new ArrayList<>();
            for (Entity en : w.getNearbyEntities(mid, rad, rad, rad)) {
                if (en == p || !(en instanceof LivingEntity le) || done.contains(le.getUniqueId())) continue;
                if (!validTarget(p, le)) continue;
                if (le.getBoundingBox().expand(0.3 + 0.5 * sc).rayTrace(pos.toVector(), d[0], maxD) == null) continue;
                cand.add(le);
            }
            cand.sort(Comparator.comparingDouble(o -> o.getLocation().distanceSquared(pos)));
            for (LivingEntity le : cand) {
                done.add(le.getUniqueId());
                if (once != null && !once.add(le.getUniqueId())) continue; // 다른 투사체가 이미 맞힌 적은 통과
                onHit.accept(le);
                if (!pierce) {
                    task[0].cancel();
                    return;
                }
            }
            if (br != null) {
                task[0].cancel();
                return;
            }
            pos.add(d[0].clone().multiply(step));
            traveled[0] += step;
        }, 1L, 1L);
    }

    // ---------------------------------------------------------------- kind: shield (뼈 갑옷)

    private boolean doShield(Player p, SkillDef s, int lv) {
        double amt = val(p, s, "absorb", lv, 30.0);
        double secs = val(p, s, "shield-seconds", lv, 0.0);
        shields.put(p.getUniqueId(), new double[]{amt, secs > 0 ? System.currentTimeMillis() + secs * 1000.0 : Double.MAX_VALUE});
        p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1.0, 0), 20, 0.5, 0.7, 0.5, 0.02);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 0.8f, 0.7f);
        return true;
    }

    /** 뼈 갑옷: 몹의 물리 공격 피해를 흡수량만큼 막는다. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onShieldAbsorb(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player v)) return;
        double[] sh = shields.get(v.getUniqueId());
        if (sh == null) return;
        if (sh[1] < System.currentTimeMillis()) {
            shields.remove(v.getUniqueId());
            return;
        }
        DamageCause c = e.getCause();
        if (c != DamageCause.ENTITY_ATTACK && c != DamageCause.ENTITY_SWEEP_ATTACK && c != DamageCause.PROJECTILE) return;
        double dmg = e.getDamage();
        if (dmg <= 0) return;
        double a = Math.min(sh[0], dmg);
        sh[0] -= a;
        e.setDamage(dmg - a);
        v.getWorld().spawnParticle(Particle.END_ROD, v.getLocation().add(0, 1.0, 0), 6, 0.4, 0.5, 0.4, 0.02);
        if (sh[0] <= 0.0001) {
            shields.remove(v.getUniqueId());
            msg(v, ChatColor.GRAY + "뼈 갑옷이 부서졌다.");
        }
    }

    // ---------------------------------------------------------------- kind: wall (뼈의 벽 / 뼈 감옥) - 임시 뼈 블록

    private int groundY(World w, int x, int y, int z) {
        if (!w.getBlockAt(x, y, z).getType().isAir()) {
            if (w.getBlockAt(x, y + 1, z).getType().isAir()) return y + 1;
            return Integer.MIN_VALUE;
        }
        int yy = y;
        for (int i = 0; i < 2; i++) {
            if (w.getBlockAt(x, yy - 1, z).getType().isAir()) yy--;
            else break;
        }
        return yy;
    }

    private void placeBone(World w, int x, int y, int z, long until, int cap) {
        if (tempBlocks.size() >= cap) return;
        org.bukkit.block.Block b = w.getBlockAt(x, y, z);
        if (!b.getType().isAir()) return;
        Location c = new Location(w, x + 0.5, y + 0.5, z + 0.5);
        for (Entity en : w.getNearbyEntities(c, 0.6, 0.6, 0.6)) {
            if (en instanceof LivingEntity && !(en instanceof ArmorStand)) return; // 안에 누가 있으면 막지 않는다
        }
        b.setType(Material.BONE_BLOCK);
        TempBlock tb = new TempBlock();
        tb.world = w;
        tb.x = x;
        tb.y = y;
        tb.z = z;
        tb.until = until;
        tempBlocks.put(tbKey(w, x, y, z), tb);
    }

    private boolean doWall(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final World w = p.getWorld();
        final double range = val(p, s, "range", lv, 24.0);
        final boolean ring = s.sec.getString("wall-mode", "line").equals("ring");
        final Location eye = p.getEyeLocation();
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        Location center;
        if (ring) {
            if (t == null) {
                if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 적을 직접 조준해야 합니다.");
                return false;
            }
            center = t.getLocation();
        } else if (t != null) {
            center = t.getLocation();
        } else {
            RayTraceResult r = w.rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
            center = r != null ? r.getHitPosition().toLocation(w) : eye.clone().add(eye.getDirection().multiply(Math.min(range, 10.0)));
        }
        final long until = System.currentTimeMillis() + (long) (val(p, s, "duration", lv, 8.0) * 1000.0);
        final int height = Math.max(1, s.sec.getInt("height", 3));
        final int cap = Math.max(20, plugin.getConfig().getInt("wall.max-blocks", 400));
        Set<String> cols = new HashSet<>();
        List<int[]> columns = new ArrayList<>();
        if (ring) {
            double rr = val(p, s, "ring-radius", lv, 2.5);
            for (int i = 0; i < 48; i++) {
                double a = Math.PI * 2.0 * i / 48.0;
                int bx = (int) Math.floor(center.getX() + Math.cos(a) * rr);
                int bz = (int) Math.floor(center.getZ() + Math.sin(a) * rr);
                if (cols.add(bx + ":" + bz)) columns.add(new int[]{bx, bz});
            }
        } else {
            Vector f = center.toVector().subtract(p.getLocation().toVector());
            f.setY(0);
            if (f.lengthSquared() < 0.01) f = eye.getDirection().setY(0);
            if (f.lengthSquared() < 0.01) f = new Vector(1, 0, 0);
            f.normalize();
            Vector side = new Vector(-f.getZ(), 0, f.getX());
            double half = val(p, s, "length", lv, 5.0) / 2.0;
            for (double d = -half; d <= half + 0.01; d += 0.5) {
                int bx = (int) Math.floor(center.getX() + side.getX() * d);
                int bz = (int) Math.floor(center.getZ() + side.getZ() * d);
                if (cols.add(bx + ":" + bz)) columns.add(new int[]{bx, bz});
            }
        }
        int baseY = center.getBlockY();
        int placed = 0;
        for (int[] col : columns) {
            int gy = groundY(w, col[0], baseY, col[1]);
            if (gy == Integer.MIN_VALUE) continue;
            for (int k = 0; k < height; k++) {
                int before = tempBlocks.size();
                placeBone(w, col[0], gy + k, col[1], until, cap);
                if (tempBlocks.size() > before) placed++;
            }
        }
        if (placed == 0) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 세울 공간이 없습니다.");
            return false;
        }
        saveTempBlocks();
        w.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 0.4f, 0.6f);
        return true;
    }

    private java.io.File tempFile() {
        return new java.io.File(plugin.getDataFolder(), "tempblocks.txt");
    }

    /** 서버가 꺼져도 남은 뼈 블록을 다음 시작 때 지울 수 있게 위치를 기록한다. */
    private void saveTempBlocks() {
        try {
            java.io.File f = tempFile();
            if (tempBlocks.isEmpty()) {
                if (f.exists()) f.delete();
                return;
            }
            plugin.getDataFolder().mkdirs();
            StringBuilder sb = new StringBuilder();
            for (String k : tempBlocks.keySet()) sb.append(k).append('\n');
            java.nio.file.Files.writeString(f.toPath(), sb.toString(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception ex) {
            plugin.getLogger().warning("tempblocks.txt 저장 실패: " + ex.getMessage());
        }
    }

    /** 시작할 때: 지난 번에 남은 뼈 블록(기록된 자리의 BONE_BLOCK)을 공기로 되돌린다. */
    void restoreTempBlocks() {
        try {
            java.io.File f = tempFile();
            if (!f.exists()) return;
            int n = 0;
            for (String line : java.nio.file.Files.readAllLines(f.toPath(), java.nio.charset.StandardCharsets.UTF_8)) {
                String[] a = line.trim().split(";");
                if (a.length != 4) continue;
                World w = Bukkit.getWorld(a[0]);
                if (w == null) continue;
                org.bukkit.block.Block b = w.getBlockAt(Integer.parseInt(a[1]), Integer.parseInt(a[2]), Integer.parseInt(a[3]));
                if (b.getType() == Material.BONE_BLOCK) {
                    b.setType(Material.AIR);
                    n++;
                }
            }
            f.delete();
            if (n > 0) plugin.getLogger().info("[뼈 블록] 지난번에 남은 " + n + "개를 지웠습니다.");
        } catch (Exception ex) {
            plugin.getLogger().warning("tempblocks.txt 복구 실패: " + ex.getMessage());
        }
    }

    /** 플러그인이 꺼질 때: 세워둔 뼈 블록을 전부 지운다. */
    void stop() {
        removeAllSummons();
        for (TempBlock tb : tempBlocks.values()) {
            org.bukkit.block.Block b = tb.world.getBlockAt(tb.x, tb.y, tb.z);
            if (b.getType() == Material.BONE_BLOCK) b.setType(Material.AIR);
        }
        tempBlocks.clear();
        saveTempBlocks();
    }

    /** 뼈 블록을 부수면 아이템이 나오지 않고 기록에서도 빠진다. */
    @EventHandler(ignoreCancelled = true)
    public void onBoneBreak(org.bukkit.event.block.BlockBreakEvent e) {
        org.bukkit.block.Block b = e.getBlock();
        if (b.getType() != Material.BONE_BLOCK) return;
        if (tempBlocks.remove(tbKey(b.getWorld(), b.getX(), b.getY(), b.getZ())) != null) {
            e.setDropItems(false);
            saveTempBlocks();
        }
    }

    // ---------------------------------------------------------------- 생명력 추출 (저주): 저주 걸린 적을 때리면 피해의 일부를 회복

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onLifeTap(EntityDamageByEntityEvent e) {
        Entity dm = e.getDamager();
        Player atk = null;
        if (dm instanceof Player pl) atk = pl;
        else if (dm instanceof Projectile pr && pr.getShooter() instanceof Player pl2) atk = pl2;
        if (atk == null) return;
        double lt = curseAmount(e.getEntity(), "life_tap");
        if (lt <= 0) return;
        double heal = e.getFinalDamage() * lt / 100.0;
        if (heal > 0) healAlly(atk, heal);
    }

    private String weaponLabel(String t) {
        return switch (t) {
            case "spear" -> "창(삼지창/투창)";
            case "sword" -> "검";
            case "axe" -> "도끼";
            case "mace" -> "철퇴";
            case "bow" -> "활/쇠뇌";
            default -> t;
        };
    }

    private void describeNecro(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        if (c.contains("shots")) {
            out.add(ChatColor.GRAY + "발사 " + (int) val(p, s, "shots", lv, 1) + "발" + (c.getBoolean("radial", false) ? " (사방으로)" : "")
                    + (c.getBoolean("pierce", false) ? ", 관통" : "") + (c.getBoolean("homing", false) ? ", 적을 따라감" : ""));
        }
        if (c.contains("magic-flat")) {
            out.add(ChatColor.LIGHT_PURPLE + "마법 피해 " + fmt(val(p, s, "magic-flat", lv, 0)) + " (방어/저항 무시)");
        }
        if (c.contains("corpse-hp-pct")) {
            out.add(ChatColor.GOLD + "시체 생명력의 " + fmt(val(p, s, "corpse-hp-pct", lv, 0)) + "% 폭발 피해, 범위 "
                    + fmt(radius(p, s, lv, 0)) + "칸 (조준한 시체 필요)");
        }
        if (c.getString("corpse-mode", "").equals("poison")) out.add(ChatColor.GRAY + "조준한 시체를 독 구름으로 터뜨림 (시체 필요)");
        if (c.contains("absorb")) out.add(ChatColor.AQUA + "몹의 물리 공격 " + fmt(val(p, s, "absorb", lv, 0)) + " 흡수 (다 쓰면 사라짐)");
        if (c.contains("wall-mode")) {
            out.add(ChatColor.GRAY + (c.getString("wall-mode").equals("ring") ? "조준한 적 둘레에 임시 뼈 벽 (적을 직접 조준)" : "조준한 곳에 임시 뼈 벽")
                    + ", " + fmt(val(p, s, "duration", lv, 8)) + "초");
        }
        if (c.contains("convert-seconds") && s.kind.equals("curse")) {
            out.add(ChatColor.LIGHT_PURPLE + fmt(val(p, s, "convert-seconds", lv, 8)) + "초 동안 몹끼리 싸우게 함 (보스 제외)");
        }
        if (c.contains("max-targets")) out.add(ChatColor.GRAY + "가장 가까운 " + (int) val(p, s, "max-targets", lv, 1) + "마리에게만");
    }


    // ===================================================================
    //  0.19.0: 소환 (해골 / 해골 마법학자 / 골렘 4종)  [미검증]
    //   - 해골/마법학자: 시체를 1개 쓰고, 시간 제한이 있다(summon.skeleton-seconds). 골렘은 시간 제한 없음, 한 번에 한 마리.
    //   - 소환수는 바닐라 몹에 태그(diablo_summon)를 붙여 쓴다. 저장되지 않고(persistent=false), 주인이 나가면 사라진다.
    //   - 강화(숙련/저항)는 소환하는 순간의 값으로 정해진다 (스킬을 올려도 이미 있는 소환수는 그대로).
    // ===================================================================

    static final class Summon {
        UUID owner;
        LivingEntity ent;
        String type = "skeleton"; // skeleton / mage / golem
        String golem = "";
        String element = "";
        long until;               // 0 = 시간 제한 없음
        long lastCast;
        double dmg;
        double slowPct;
        double lifesteal;
        double thorns;
        double fireDps;
        double resist;            // 받는 피해 감소 % (발키리)
        boolean master;           // 그림자 달인
        int castLv;               // 그림자 소환 스킬 레벨
        double radius;            // 유인 반경 (미끼)
        String skillId = "";      // 드루이드: 소환한 스킬
        double stunSec;           // 회색곰: 기절
        double knock;             // 회색곰: 밀쳐냄
        boolean eats;             // 광포한 늑대: 시체를 먹으면 강해짐
        long buffUntil;
        int rgb = 0xFFFFFF;       // 정령 색
    }

    private final Map<UUID, Summon> summons = new LinkedHashMap<>();
    private static final String SUMMON_TAG = "diablo_summon";
    private int summonTickCount;

    private static boolean isSummonEntity(Entity e) {
        return e != null && e.getScoreboardTags().contains(SUMMON_TAG);
    }

    /** 최대 소환 수: 3레벨까지 레벨당 1, 이후 3레벨마다 1 (20레벨 = 8). */
    private int maxSummons(int lv) {
        return lv <= 3 ? Math.max(1, lv) : 3 + (lv - 3) / 3;
    }

    private List<Summon> ownedSummons(UUID owner, String type) {
        List<Summon> l = new ArrayList<>();
        for (Summon s : summons.values()) {
            if (s.owner.equals(owner) && (type == null || s.type.equals(type))) l.add(s);
        }
        return l;
    }

    /** 골렘을 저장 기록 없이 완전히 없앤다 (교체/죽음). */
    private void removeSummon(Summon s, boolean puff) {
        if (s.type.equals("golem")) deleteGolemRecord(s.owner);
        removeSummonKeep(s, puff);
    }

    /** 소환수를 치우되 골렘의 저장 기록은 남긴다 (주인 접속 종료/서버 종료). */
    private void removeSummonKeep(Summon s, boolean puff) {
        if (s.type.equals("golem") && s.ent.isValid() && !s.ent.isDead()) saveGolemRecord(s, s.ent.getHealth());
        summons.remove(s.ent.getUniqueId());
        if (puff && s.ent.isValid()) {
            s.ent.getWorld().spawnParticle(Particle.CLOUD, s.ent.getLocation().add(0, 0.8, 0), 12, 0.3, 0.4, 0.3, 0.02);
        }
        s.ent.remove();
    }

    void removeSummonsOf(UUID owner) {
        for (Summon s : ownedSummons(owner, null)) removeSummonKeep(s, false);
    }

    void removeAllSummons() {
        for (Summon s : new ArrayList<>(summons.values())) removeSummonKeep(s, false);
        for (World w : Bukkit.getWorlds()) {
            for (Entity en : w.getEntities()) {
                if (isSummonEntity(en)) en.remove();
            }
        }
    }

    /** 서버가 비정상 종료됐을 때 남은 소환수를 지운다. */
    @EventHandler
    public void onEntitiesLoad(org.bukkit.event.world.EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (isSummonEntity(en) && !summons.containsKey(en.getUniqueId())) en.remove();
        }
    }

    private ItemStack unbreakable(Material m, int rgb) {
        ItemStack it = new ItemStack(m);
        ItemMeta im = it.getItemMeta();
        if (im != null) {
            im.setUnbreakable(true);
            if (rgb >= 0 && im instanceof org.bukkit.inventory.meta.LeatherArmorMeta lm) lm.setColor(org.bukkit.Color.fromRGB(rgb));
            it.setItemMeta(im);
        }
        return it;
    }

    private void noDrops(org.bukkit.inventory.EntityEquipment eq) {
        eq.setHelmetDropChance(0f);
        eq.setChestplateDropChance(0f);
        eq.setItemInMainHandDropChance(0f);
        eq.setItemInOffHandDropChance(0f);
    }

    private void gearSkeleton(LivingEntity e, boolean mage, int lv, int rgb) {
        org.bukkit.inventory.EntityEquipment eq = e.getEquipment();
        if (eq == null) return;
        if (mage) {
            eq.setHelmet(unbreakable(Material.LEATHER_HELMET, rgb)); // 햇빛에 타지 않도록 투구는 꼭 씌운다
            eq.setChestplate(unbreakable(Material.LEATHER_CHESTPLATE, rgb));
            eq.setItemInMainHand(new ItemStack(Material.AIR));
            eq.setItemInOffHand(new ItemStack(Material.AIR));
        } else {
            eq.setHelmet(unbreakable(lv >= 8 ? Material.CHAINMAIL_HELMET : Material.LEATHER_HELMET, 0x808080));
            if (lv >= 12) eq.setChestplate(unbreakable(Material.CHAINMAIL_CHESTPLATE, -1));
            eq.setItemInMainHand(new ItemStack(lv >= 12 ? Material.IRON_SWORD : lv >= 5 ? Material.STONE_SWORD : Material.WOODEN_SWORD));
            if (lv >= 18) eq.setItemInOffHand(new ItemStack(Material.SHIELD));
        }
        noDrops(eq);
    }

    private void setupSummon(LivingEntity e, String name, double hp, double dmg) {
        e.addScoreboardTag(SUMMON_TAG);
        e.setCustomName(name);
        e.setCustomNameVisible(true);
        e.setRemoveWhenFarAway(false);
        e.setPersistent(false);
        e.setCanPickupItems(false);
        AttributeInstance mh = e.getAttribute(VersionCompat.MAX_HEALTH);
        if (mh != null) mh.setBaseValue(Math.max(1.0, hp));
        e.setHealth(Math.max(1.0, Math.min(hp, mh == null ? hp : mh.getValue())));
        AttributeInstance ad = e.getAttribute(VersionCompat.ATTACK_DAMAGE);
        if (ad != null) ad.setBaseValue(Math.max(0.0, dmg));
    }

    private boolean summonRoomFor(Player p, int replacing) {
        int cap = Math.max(1, plugin.getConfig().getInt("summon.max-server", 40));
        if (summons.size() - replacing >= cap) {
            msg(p, ChatColor.RED + "서버의 소환수 한도(" + cap + ")에 도달했습니다.");
            return false;
        }
        return true;
    }

    private static final String[] ELEMENTS = {"fire", "cold", "lightning", "poison"};

    // ---------------------------------------------------------------- kind: raise (해골 / 마법학자)

    private boolean doRaise(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        Corpse c = findCorpse(p, val(p, s, "range", lv, 24.0));
        if (c == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 조준한 곳에 시체가 없습니다.");
            return false;
        }
        final boolean mage = s.sec.getString("summon-type", "skeleton").equals("mage");
        final String type = mage ? "mage" : "skeleton";
        final UUID id = p.getUniqueId();
        List<Summon> same = ownedSummons(id, type);
        int max = maxSummons(lv);
        int replacing = Math.max(0, same.size() - max + 1);
        if (!summonRoomFor(p, replacing)) return false;
        while (same.size() >= max) removeSummon(same.remove(0), true); // 가장 오래된 것부터 교체
        int pcap = Math.max(1, plugin.getConfig().getInt("summon.max-per-player", 14));
        List<Summon> mine = new ArrayList<>(ownedSummons(id, "skeleton"));
        mine.addAll(ownedSummons(id, "mage"));
        while (mine.size() >= pcap) removeSummon(mine.remove(0), true);
        corpses.remove(c);

        final double hp = val(p, s, "hp", lv, 20.0) * (1.0 + passiveSum(p, "skel-hp-pct") / 100.0);
        final double dmg = val(p, s, "damage", lv, 3.0) * (1.0 + passiveSum(p, "skel-dmg-pct") / 100.0);
        final String el = ELEMENTS[random.nextInt(ELEMENTS.length)];
        final int rgb = switch (el) {
            case "fire" -> 0xD03018;
            case "cold" -> 0x58B8F0;
            case "lightning" -> 0xE8D020;
            default -> 0x40B030;
        };
        final String elName = switch (el) {
            case "fire" -> "화염";
            case "cold" -> "냉기";
            case "lightning" -> "번개";
            default -> "독";
        };
        Location at = c.loc.clone().add(0, 0.1, 0);
        org.bukkit.entity.Skeleton sk = at.getWorld().spawn(at, org.bukkit.entity.Skeleton.class);
        setupSummon(sk, mage ? ChatColor.AQUA + elName + " 해골 마법학자" : ChatColor.GRAY + "해골 전사", hp, mage ? 0.0 : dmg);
        gearSkeleton(sk, mage, lv, rgb);
        sk.setTarget(null);
        Summon sm = new Summon();
        sm.owner = id;
        sm.ent = sk;
        sm.type = type;
        sm.element = mage ? el : "";
        sm.dmg = dmg;
        double secs = plugin.getConfig().getDouble("summon.skeleton-seconds", 90.0);
        sm.until = secs > 0 ? System.currentTimeMillis() + (long) (secs * 1000.0) : 0L;
        summons.put(sk.getUniqueId(), sm);
        at.getWorld().spawnParticle(Particle.WITCH, at.clone().add(0, 0.8, 0), 25, 0.3, 0.5, 0.3, 0.05);
        at.getWorld().playSound(at, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 0.8f, 1.0f);
        msg(p, ChatColor.GRAY + s.name + " (" + (ownedSummons(id, type).size()) + "/" + max + ")");
        return true;
    }

    // ---------------------------------------------------------------- kind: golem

    private boolean metalGear(Material m) {
        String n = m.name();
        boolean metal = n.startsWith("IRON_") || n.startsWith("GOLDEN_") || n.startsWith("NETHERITE_") || n.startsWith("CHAINMAIL_");
        return metal && (n.endsWith("_SWORD") || n.endsWith("_AXE") || n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE")
                || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS"));
    }

    private org.bukkit.entity.Item nearestMetalItem(Player p, double r) {
        org.bukkit.entity.Item best = null;
        double bd = Double.MAX_VALUE;
        for (Entity en : p.getNearbyEntities(r, 4.0, r)) {
            if (!(en instanceof org.bukkit.entity.Item it) || !metalGear(it.getItemStack().getType())) continue;
            double d = it.getLocation().distanceSquared(p.getLocation());
            if (d < bd) {
                bd = d;
                best = it;
            }
        }
        return best;
    }

    /** 희생한 장비의 공격력: 장비에 붙은 공격력 수치, 없으면 재질로 추정. */
    private double gearDamage(ItemStack st) {
        double sum = 0.0;
        ItemMeta im = st.getItemMeta();
        if (im != null && im.hasAttributeModifiers()) {
            java.util.Collection<AttributeModifier> mods = im.getAttributeModifiers(VersionCompat.ATTACK_DAMAGE);
            if (mods != null) {
                for (AttributeModifier am : mods) {
                    if (am.getOperation() == AttributeModifier.Operation.ADD_NUMBER) sum += am.getAmount();
                }
            }
        }
        if (sum > 0) return sum;
        String n = st.getType().name();
        boolean top = n.startsWith("NETHERITE_");
        boolean gold = n.startsWith("GOLDEN_");
        if (n.endsWith("_SWORD")) return top ? 8.0 : gold ? 4.0 : 6.0;
        if (n.endsWith("_AXE")) return top ? 10.0 : gold ? 7.0 : 9.0;
        return 0.0;
    }

    /** 희생한 방어구 한 조각이 주는 생명력. */
    private double gearHp(ItemStack st) {
        String n = st.getType().name();
        if (n.endsWith("_SWORD") || n.endsWith("_AXE")) return 0.0;
        double base = n.startsWith("NETHERITE_") ? 40.0 : n.startsWith("IRON_") ? 25.0 : n.startsWith("CHAINMAIL_") ? 20.0 : 15.0;
        double mul = n.endsWith("_CHESTPLATE") ? 1.5 : n.endsWith("_LEGGINGS") ? 1.2 : n.endsWith("_BOOTS") ? 0.8 : 1.0;
        return base * mul;
    }

    private boolean doGolem(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final String g = s.sec.getString("golem-type", "clay");
        final UUID id = p.getUniqueId();
        List<Summon> old = ownedSummons(id, "golem");
        if (!summonRoomFor(p, old.size())) return false;
        final World w = p.getWorld();
        Location at;
        double bonusDmg = 0.0;
        double bonusHp = 0.0;
        org.bukkit.entity.Item sacrifice = null;
        if (g.equals("iron")) {
            sacrifice = nearestMetalItem(p, 8.0);
            if (sacrifice == null) {
                if (!quiet) msg(p, ChatColor.RED + s.name + ": 가까운 바닥에 금속 무기/방어구(철·금·네더라이트·사슬)를 떨어뜨려 두세요.");
                return false;
            }
            ItemStack st = sacrifice.getItemStack();
            bonusDmg = gearDamage(st);
            bonusHp = gearHp(st);
            at = sacrifice.getLocation().clone();
        } else {
            Location eye = p.getEyeLocation();
            double range = val(p, s, "range", lv, 12.0);
            LivingEntity t = forced != null ? forced : findTarget(p, range);
            if (t != null) {
                at = t.getLocation().clone();
            } else {
                RayTraceResult r = w.rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
                at = r != null ? r.getHitPosition().toLocation(w).add(0, 0.3, 0) : eye.clone().add(eye.getDirection().multiply(3.0)).subtract(0, 1.0, 0);
            }
        }
        for (Summon o : old) removeSummon(o, true); // 골렘은 한 마리만
        if (sacrifice != null) sacrifice.remove();

        double hp = (val(p, s, "hp", lv, 100.0) + bonusHp) * (1.0 + passiveSum(p, "golem-hp-pct") / 100.0);
        double dmg = val(p, s, "damage", lv, 5.0) + bonusDmg;
        spawnGolemEntity(p, g, at, hp, dmg, val(p, s, "slow-pct", lv, 0.0), val(p, s, "lifesteal-pct", lv, 0.0),
                val(p, s, "thorns", lv, 0.0), val(p, s, "fire-dps", lv, 0.0), hp);
        w.spawnParticle(Particle.CLOUD, at.clone().add(0, 0.5, 0), 25, 0.5, 0.3, 0.5, 0.03);
        w.playSound(at, Sound.ENTITY_IRON_GOLEM_REPAIR, 1.0f, 0.8f);
        msg(p, ChatColor.GRAY + s.name + ": 생명력 " + fmt(hp) + ", 공격력 " + fmt(dmg));
        return true;
    }

    // ---------------------------------------------------------------- 0.5초 틱: 따라다니기 / 공격 대상 / 마법학자 시전

    private LivingEntity nearestEnemy(Summon sm, Player owner, double r) {
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        Location from = sm.ent.getLocation();
        for (Entity en : sm.ent.getNearbyEntities(r, r / 2.0, r)) {
            if (!(en instanceof Mob m) || m.isDead() || isSummonEntity(m)) continue;
            if (m instanceof Villager || m instanceof WanderingTrader) continue;
            if (m instanceof Tameable tm && tm.isTamed()) continue;
            LivingEntity mt = m.getTarget();
            boolean hostile = m instanceof org.bukkit.entity.Enemy;
            if (!hostile && !(mt != null && (mt.equals(owner) || isSummonEntity(mt)))) continue;
            if (m.getWorld() != owner.getWorld() || m.getLocation().distanceSquared(owner.getLocation()) > 26.0 * 26.0) continue;
            double d = m.getLocation().distanceSquared(from);
            if (d < bd) {
                bd = d;
                best = m;
            }
        }
        return best;
    }

    private void summonTick() {
        if (summons.isEmpty()) return;
        summonTickCount++;
        long now = System.currentTimeMillis();
        double tp = plugin.getConfig().getDouble("summon.teleport-distance", 28.0);
        double follow = plugin.getConfig().getDouble("summon.follow-distance", 6.0);
        double mageMs = plugin.getConfig().getDouble("summon.mage-interval-sec", 2.0) * 1000.0;
        boolean taunt = plugin.getConfig().getBoolean("summon.golem-taunt", true);
        for (Summon sm : new ArrayList<>(summons.values())) {
            LivingEntity e = sm.ent;
            if (e == null || !e.isValid() || e.isDead()) {
                summons.values().remove(sm);
                continue;
            }
            Player o = Bukkit.getPlayer(sm.owner);
            if (o == null || !o.isOnline()) {
                removeSummonKeep(sm, false);
                continue;
            }
            if (o.isDead()) continue;
            if (sm.until > 0 && sm.until < now) {
                removeSummon(sm, true);
                continue;
            }
            if (sm.type.equals("decoy")) {
                decoyTick(sm, o);
                continue;
            }
            if (sm.type.equals("spirit")) {
                spiritTick(sm, o, now);
                continue;
            }
            if (sm.eats) direTick(sm, now);
            double dist2 = e.getWorld() == o.getWorld() ? e.getLocation().distanceSquared(o.getLocation()) : Double.MAX_VALUE;
            if (dist2 > tp * tp) {
                e.teleport(o.getLocation().add(random.nextDouble() * 4.0 - 2.0, 0.2, random.nextDouble() * 4.0 - 2.0));
                continue;
            }
            LivingEntity enemy = nearestEnemy(sm, o, sm.type.equals("mage") ? 14.0 : 12.0);
            if (sm.type.equals("shadow") && enemy != null) shadowCast(sm, o, enemy, now);
            Mob m = e instanceof Mob mm ? mm : null;
            if (sm.type.equals("mage")) {
                if (enemy != null) {
                    Location from = e.getEyeLocation();
                    Vector to = aimPoint(enemy).subtract(from.toVector());
                    double len = to.length();
                    if (len > 0.5) {
                        e.setRotation((float) Math.toDegrees(Math.atan2(-to.getX(), to.getZ())), (float) -Math.toDegrees(Math.asin(to.getY() / len)));
                        if (len < 16.0 && now - sm.lastCast >= mageMs
                                && e.getWorld().rayTraceBlocks(from, to.clone().normalize(), len, FluidCollisionMode.NEVER, true) == null) {
                            sm.lastCast = now;
                            castMage(sm, o, enemy, from, to.clone().normalize());
                        }
                    }
                } else if (m != null && dist2 > follow * follow) {
                    VersionCompat.moveMob(m, o.getLocation(), 1.2);
                }
                continue;
            }
            if (m != null) {
                if (enemy != null) {
                    m.setTarget(enemy);
                } else {
                    if (m.getTarget() != null) m.setTarget(null);
                    if (dist2 > follow * follow) VersionCompat.moveMob(m, o.getLocation(), 1.25);
                }
            }
            if (sm.type.equals("golem") || sm.type.equals("valk")) {
                if (taunt && m != null) {
                    for (Entity en : e.getNearbyEntities(6.0, 3.0, 6.0)) {
                        if (en instanceof Mob h && !isSummonEntity(h) && h.getTarget() != null && h.getTarget().equals(o)) h.setTarget(e);
                    }
                }
                if (sm.golem.equals("fire")) {
                    e.getWorld().spawnParticle(Particle.FLAME, e.getLocation().add(0, 1.0, 0), 5, 0.4, 0.6, 0.4, 0.01);
                    if (summonTickCount % 2 == 0 && sm.fireDps > 0) {
                        for (LivingEntity t : around(e.getLocation(), 3.5, o)) pureHit(o, t, sm.fireDps);
                    }
                } else if (sm.golem.equals("clay")) {
                    dust(e.getWorld(), e.getLocation().getX(), e.getLocation().getY() + 0.3, e.getLocation().getZ(), 0xB07840, 1.2f);
                }
            }
        }
    }

    private void castMage(Summon sm, Player o, LivingEntity enemy, Location from, Vector dir) {
        final double dmg = sm.dmg;
        final String el = sm.element;
        Particle part = switch (el) {
            case "fire" -> Particle.FLAME;
            case "cold" -> Particle.SNOWFLAKE;
            case "lightning" -> Particle.ELECTRIC_SPARK;
            default -> Particle.HAPPY_VILLAGER;
        };
        flyMissile(o, from, dir, 1.4, 16.0, false, false, enemy, part, null, le -> {
            pureHit(o, le, dmg);
            switch (el) {
                case "fire" -> le.setFireTicks(60);
                case "cold" -> le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1, false, true));
                case "poison" -> poisonDot(o, le, dmg * 0.4, 4.0);
                default -> { }
            }
        });
        from.getWorld().playSound(from, Sound.ENTITY_EVOKER_CAST_SPELL, 0.6f, 1.6f);
    }

    // ---------------------------------------------------------------- 소환수 이벤트

    /** 주인/다른 소환수를 때리지 않는다, 주인이 소환수를 때리지도 못한다. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSummonFriendly(EntityDamageByEntityEvent e) {
        Entity victim = e.getEntity();
        Entity dm = e.getDamager();
        if (dm instanceof Projectile pr && pr.getShooter() instanceof Entity sh) dm = sh;
        boolean vs = isSummonEntity(victim);
        boolean ds = isSummonEntity(dm);
        if (vs && (dm instanceof Player || ds)) e.setCancelled(true);
        else if (ds && victim instanceof Player) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSummonStrike(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof LivingEntity v)) return;
        Summon atk = summons.get(e.getDamager().getUniqueId());
        if (atk != null && !isSummonEntity(v)) {
            Player o = Bukkit.getPlayer(atk.owner);
            if (atk.slowPct > 0) {
                v.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, Math.max(0, (int) (atk.slowPct / 20.0)), false, true));
            }
            if (atk.golem.equals("fire")) v.setFireTicks(60);
            if (atk.stunSec > 0) stun(v, atk.stunSec);
            if (atk.knock > 0 && !isBossLike(v)) {
                Vector away = v.getLocation().toVector().subtract(atk.ent.getLocation().toVector()).setY(0);
                if (away.lengthSquared() > 0.01) v.setVelocity(away.normalize().multiply(atk.knock).setY(0.3));
            }
            if (atk.lifesteal > 0) {
                double heal = e.getFinalDamage() * atk.lifesteal / 100.0;
                AttributeInstance mh = atk.ent.getAttribute(VersionCompat.MAX_HEALTH);
                double max = mh == null ? 20.0 : mh.getValue();
                atk.ent.setHealth(Math.min(max, atk.ent.getHealth() + heal));
                if (o != null) healAlly(o, heal);
            }
        }
        Summon def = summons.get(v.getUniqueId());
        if (def != null && def.thorns > 0) {
            LivingEntity att = mobAttacker(e.getDamager());
            Player o = Bukkit.getPlayer(def.owner);
            if (att != null && o != null && !isSummonEntity(att)) pureHit(o, att, def.thorns);
        }
    }

    /** 소환수 저항, 화염 골렘의 화염 흡수. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSummonHurt(EntityDamageEvent e) {
        Summon sm = summons.get(e.getEntity().getUniqueId());
        if (sm == null) return;
        if (sm.golem.equals("fire")) {
            DamageCause c = e.getCause();
            if (c == DamageCause.FIRE || c == DamageCause.FIRE_TICK || c == DamageCause.LAVA || c == DamageCause.HOT_FLOOR) {
                e.setCancelled(true);
                sm.ent.setFireTicks(0);
                AttributeInstance mh = sm.ent.getAttribute(VersionCompat.MAX_HEALTH);
                sm.ent.setHealth(Math.min(mh == null ? 20.0 : mh.getValue(), sm.ent.getHealth() + e.getDamage()));
                return;
            }
        }
        if (sm.type.equals("valk") && e instanceof EntityDamageByEntityEvent be) {
            Entity dmgr = be.getDamager();
            boolean proj = dmgr instanceof Projectile;
            Player ow = Bukkit.getPlayer(sm.owner);
            if ((proj || dmgr instanceof LivingEntity) && ow != null) {
                double ch = passiveSum(ow, proj ? "avoid-ranged-pct" : "dodge-melee-pct");
                if (sm.ent.getVelocity().lengthSquared() > 0.01) ch = Math.max(ch, passiveSum(ow, "evade-moving-pct"));
                ch = Math.min(ch, plugin.getConfig().getDouble("dodge.max", 75.0));
                if (ch > 0 && random.nextDouble() * 100.0 < ch) {
                    e.setCancelled(true);
                    sm.ent.getWorld().spawnParticle(Particle.CLOUD, sm.ent.getLocation().add(0, 1.0, 0), 5, 0.3, 0.4, 0.3, 0.02);
                    return;
                }
            }
        }
        if (sm.resist > 0) e.setDamage(e.getDamage() * (1.0 - Math.min(85.0, sm.resist) / 100.0));
        Player o = Bukkit.getPlayer(sm.owner);
        if (o == null) return;
        double res = Math.min(75.0, passiveSum(o, "summon-resist-pct"));
        if (res > 0) e.setDamage(e.getDamage() * (1.0 - res / 100.0));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSummonDeath(org.bukkit.event.entity.EntityDeathEvent e) {
        if (!isSummonEntity(e.getEntity())) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        Summon dead = summons.remove(e.getEntity().getUniqueId());
        if (dead != null && dead.type.equals("golem")) deleteGolemRecord(dead.owner);
    }

    // ===================================================================
    //  0.19.0: 오라 / 저주 이펙트 (색 입자 DUST)  [미검증]
    //   오라: 시전자 발밑에 오라마다 다른 색/모양, 저주: 걸린 몹 머리 위에 저주마다 다른 색/모양.
    //   입자 수는 적게 유지하고 (config effects.*), 오라 효과는 0.3초마다 한 번 그린다.
    // ===================================================================

    private final Map<UUID, Map<String, Integer>> fxAuras = new HashMap<>();

    private void dust(World w, double x, double y, double z, int rgb, float size) {
        w.spawnParticle(Particle.DUST, x, y, z, 1, 0.0, 0.0, 0.0, 0.0,
                new Particle.DustOptions(org.bukkit.Color.fromRGB(rgb & 0xFFFFFF), size));
    }

    private static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** 오라 id -> {모양, 색1, 색2, 개수}. 모양: 1 가시 2 번개 3 안개 4 소용돌이 5 빛무리 6 도는 점 7 물결 고리 8 솟는 입자 9 흩뿌림 10 무지개 */
    private int[] auraStyle(String id) {
        return switch (id) {
            case "holy_shock" -> new int[]{2, 0xFFFFFF, 0xCCDDFF, 8};
            case "holy_fire" -> new int[]{1, 0xFFD020, 0xFF8800, 14};
            case "holy_freeze" -> new int[]{3, 0xDDEEFF, 0x88AAFF, 10};
            case "fanaticism" -> new int[]{4, 0xFF4400, 0xFFAA00, 3};
            case "might" -> new int[]{1, 0xFFD870, 0xFFB030, 10};
            case "conviction" -> new int[]{5, 0x30FF30, 0x90FF60, 10};
            case "blessed_aim" -> new int[]{6, 0xFF3020, 0xFF7030, 6};
            case "thorns" -> new int[]{1, 0xFFC820, 0xFFE880, 12};
            case "concentration" -> new int[]{7, 0x60E0D0, 0xA0FFF0, 24};
            case "sanctuary" -> new int[]{1, 0xFFFFFF, 0xFFF4C0, 12};
            case "prayer" -> new int[]{8, 0x3860FF, 0x80B0FF, 8};
            case "cleansing" -> new int[]{6, 0xFFFFFF, 0xA0FFA0, 6};
            case "meditation" -> new int[]{3, 0xE8E8E8, 0x6090FF, 8};
            case "defiance" -> new int[]{9, 0x4090FF, 0x80C0FF, 8};
            case "vigor" -> new int[]{6, 0xFF9020, 0xFFC050, 8};
            case "redemption" -> new int[]{4, 0xFF3000, 0xFF7040, 3};
            case "salvation" -> new int[]{10, 0xFF3030, 0x3030FF, 18};
            case "resist_fire" -> new int[]{7, 0xFF8820, 0xFFC040, 24};
            case "resist_cold" -> new int[]{7, 0x3880FF, 0x90C8FF, 24};
            case "resist_lightning" -> new int[]{7, 0xFFFFFF, 0xD8D8E8, 24};
            default -> new int[]{7, 0xB080FF, 0xE0C0FF, 20};
        };
    }

    private void drawAura(World w, Location base, String id, double radius, long t) {
        int[] st = auraStyle(id);
        double R = Math.max(1.2, Math.min(radius, plugin.getConfig().getDouble("effects.aura-radius", 3.2)));
        double y = base.getY() + 0.12;
        double cx = base.getX();
        double cz = base.getZ();
        double rot = t * 0.05;
        int n = st[3];
        switch (st[0]) {
            case 1 -> { // 가시: 바깥으로 뻗는 뾰족한 선
                for (int i = 0; i < n; i++) {
                    double a = Math.PI * 2 * i / n + rot * 0.2;
                    for (int k = 1; k <= 3; k++) {
                        double rr = R * (0.3 + 0.24 * k);
                        dust(w, cx + Math.cos(a) * rr, y, cz + Math.sin(a) * rr, mix(st[1], st[2], k / 3.0), (float) (1.3 - 0.25 * k));
                    }
                }
            }
            case 2 -> { // 번개: 발밑에서 튀는 흰 줄기
                for (int i = 0; i < n; i++) {
                    double a = random.nextDouble() * Math.PI * 2;
                    double rr = random.nextDouble() * R;
                    dust(w, cx + Math.cos(a) * rr, y, cz + Math.sin(a) * rr, st[1], 0.9f);
                }
                w.spawnParticle(Particle.ELECTRIC_SPARK, cx, y + 0.1, cz, 3, R * 0.4, 0.05, R * 0.4, 0.02);
            }
            case 3 -> { // 안개
                for (int i = 0; i < n; i++) {
                    double a = random.nextDouble() * Math.PI * 2;
                    double rr = random.nextDouble() * R;
                    dust(w, cx + Math.cos(a) * rr, y + random.nextDouble() * 0.3, cz + Math.sin(a) * rr, mix(st[1], st[2], random.nextDouble() * 0.4), 1.8f);
                }
                dust(w, cx + (random.nextDouble() - 0.5) * R, y + 0.6 + random.nextDouble() * 0.5, cz + (random.nextDouble() - 0.5) * R, st[2], 0.8f);
            }
            case 4 -> { // 소용돌이 팔
                for (int arm = 0; arm < n; arm++) {
                    for (int k = 1; k <= 5; k++) {
                        double f = k / 5.0;
                        double a = rot + Math.PI * 2 * arm / n + f * 2.2;
                        dust(w, cx + Math.cos(a) * R * f, y, cz + Math.sin(a) * R * f, mix(st[1], st[2], f), 1.2f);
                    }
                }
            }
            case 5 -> { // 빛무리
                for (int i = 0; i < n; i++) {
                    double a = random.nextDouble() * Math.PI * 2;
                    double rr = random.nextDouble() * R * 0.7;
                    dust(w, cx + Math.cos(a) * rr, y + 0.05, cz + Math.sin(a) * rr, mix(st[1], st[2], random.nextDouble()), 1.6f);
                }
                dust(w, cx, y + 0.1, cz, st[2], 2.0f);
            }
            case 6 -> { // 고리를 도는 점
                for (int i = 0; i < n; i++) {
                    double a = rot * 1.5 + Math.PI * 2 * i / n;
                    dust(w, cx + Math.cos(a) * R * 0.85, y + 0.05, cz + Math.sin(a) * R * 0.85, st[1], 1.6f);
                    dust(w, cx + Math.cos(a) * R * 0.85, y + 0.05, cz + Math.sin(a) * R * 0.85, st[2], 0.8f);
                }
            }
            case 7 -> { // 물결 고리
                for (int i = 0; i < n; i++) {
                    double a = Math.PI * 2 * i / n;
                    double rr = R * (0.9 + 0.1 * Math.sin(a * 3 + rot * 3));
                    dust(w, cx + Math.cos(a) * rr, y, cz + Math.sin(a) * rr, mix(st[1], st[2], 0.5 + 0.5 * Math.sin(a * 2 + rot)), 1.1f);
                }
            }
            case 8 -> { // 솟는 입자
                for (int i = 0; i < n; i++) {
                    double a = random.nextDouble() * Math.PI * 2;
                    double rr = random.nextDouble() * R * 0.8;
                    dust(w, cx + Math.cos(a) * rr, y + random.nextDouble() * 1.6, cz + Math.sin(a) * rr, mix(st[1], st[2], random.nextDouble()), 1.1f);
                }
            }
            case 9 -> { // 흩어진 조각
                for (int i = 0; i < n; i++) {
                    double a = random.nextDouble() * Math.PI * 2;
                    double rr = (0.4 + random.nextDouble() * 0.6) * R;
                    dust(w, cx + Math.cos(a) * rr, y, cz + Math.sin(a) * rr, mix(st[1], st[2], random.nextDouble()), 1.4f);
                }
            }
            default -> { // 무지개 고리
                int[] cols = {0xFF3030, 0xFF9020, 0xFFF030, 0x30E030, 0x3090FF, 0xA040FF};
                for (int i = 0; i < n; i++) {
                    double a = rot + Math.PI * 2 * i / n;
                    dust(w, cx + Math.cos(a) * R * 0.9, y + 0.05, cz + Math.sin(a) * R * 0.9, cols[i % cols.length], 1.2f);
                }
            }
        }
        if (id.equals("sanctuary") || id.equals("holy_freeze")) {
            w.spawnParticle(id.equals("sanctuary") ? Particle.END_ROD : Particle.SNOWFLAKE, cx, y + 0.3, cz, 1, R * 0.4, 0.2, R * 0.4, 0.0);
        }
    }

    private void drawCurse(LivingEntity ent, Set<String> types, long t) {
        World w = ent.getWorld();
        Location l = ent.getLocation();
        double top = l.getY() + ent.getHeight() + 0.45;
        double cx = l.getX();
        double cz = l.getZ();
        double rot = t * 0.12;
        if (types.contains("decrepify")) {
            for (int i = 0; i < 4; i++) {
                dust(w, cx + (random.nextDouble() - 0.5) * 0.7, top - random.nextDouble() * 0.8, cz + (random.nextDouble() - 0.5) * 0.7, 0x909090, 1.3f);
            }
            return;
        }
        int shown = 0;
        for (String ty : types) {
            if (shown >= 2) break;
            switch (ty) {
                case "amplify" -> {
                    for (int i = 0; i < 6; i++) {
                        double a = rot + Math.PI * 2 * i / 6;
                        dust(w, cx + Math.cos(a) * 0.45, top, cz + Math.sin(a) * 0.45, 0xFF2020, 1.1f);
                    }
                }
                case "weaken" -> {
                    for (int i = 0; i < 3; i++) {
                        dust(w, cx + (random.nextDouble() - 0.5) * 0.6, top + random.nextDouble() * 0.3, cz + (random.nextDouble() - 0.5) * 0.6, 0x5028A0, 1.6f);
                    }
                }
                case "reflect" -> {
                    for (int i = 0; i < 4; i++) {
                        double a = Math.PI / 2 * i + rot * 0.3;
                        dust(w, cx + Math.cos(a) * 0.3, top + 0.15, cz + Math.sin(a) * 0.3, 0xB0B0B0, 1.0f);
                        dust(w, cx + Math.cos(a) * 0.3, top - 0.15, cz + Math.sin(a) * 0.3, 0x707070, 1.0f);
                    }
                }
                case "terror" -> {
                    for (int i = 0; i < 3; i++) {
                        dust(w, cx + (random.nextDouble() - 0.5) * 0.5, top + random.nextDouble() * 0.8, cz + (random.nextDouble() - 0.5) * 0.5, 0xFFE040, 1.0f);
                    }
                }
                case "confuse" -> {
                    for (int i = 0; i < 4; i++) {
                        double a = rot * 2.0 + Math.PI * 2 * i / 4;
                        dust(w, cx + Math.cos(a) * 0.5, top + 0.1 * Math.sin(a * 2), cz + Math.sin(a) * 0.5, i % 2 == 0 ? 0xFF60FF : 0xA040FF, 1.1f);
                    }
                }
                case "life_tap" -> {
                    for (int i = 0; i < 3; i++) {
                        dust(w, cx + (random.nextDouble() - 0.5) * 0.5, top + 0.5 - random.nextDouble() * 0.9, cz + (random.nextDouble() - 0.5) * 0.5, 0xC80000, 1.0f);
                    }
                }
                case "attract" -> {
                    w.spawnParticle(Particle.HEART, cx, top + 0.2, cz, 1, 0.25, 0.1, 0.25, 0.0);
                    dust(w, cx + (random.nextDouble() - 0.5) * 0.5, top, cz + (random.nextDouble() - 0.5) * 0.5, 0xFF70B0, 1.1f);
                }
                case "dim_vision" -> {
                    for (int i = 0; i < 4; i++) {
                        dust(w, cx + (random.nextDouble() - 0.5) * 0.6, top - 0.1 + random.nextDouble() * 0.4, cz + (random.nextDouble() - 0.5) * 0.6, 0x202020, 1.7f);
                    }
                }
                case "lower_resist" -> {
                    int[] cols = {0xFF8820, 0x3880FF, 0xFFFFFF};
                    for (int i = 0; i < 3; i++) {
                        double a = rot * 1.5 + Math.PI * 2 * i / 3;
                        dust(w, cx + Math.cos(a) * 0.45, top, cz + Math.sin(a) * 0.45, cols[i], 1.2f);
                    }
                }
                default -> w.spawnParticle(Particle.WITCH, cx, top, cz, 2, 0.25, 0.1, 0.25, 0.0);
            }
            shown++;
        }
    }

    /** 0.3초마다: 오라 모양, 저주 모양을 그린다. */
    private void fxTick() {
        if (!plugin.getConfig().getBoolean("effects.enabled", true)) return;
        long t = tickCounter;
        for (Map.Entry<UUID, Map<String, Integer>> en : fxAuras.entrySet()) {
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null || !p.isOnline() || p.isDead()) continue;
            for (Map.Entry<String, Integer> a : en.getValue().entrySet()) {
                SkillDef s = skills.get(a.getKey());
                if (s == null) continue;
                drawAura(p.getWorld(), p.getLocation(), s.id, radius(p, s, a.getValue(), 10.0), t);
            }
        }
        for (Map.Entry<UUID, ColdArmor> ca : coldArmors.entrySet()) {
            Player cp = Bukkit.getPlayer(ca.getKey());
            if (cp == null || !cp.isOnline() || ca.getValue().until < System.currentTimeMillis()) continue;
            Location cl = cp.getLocation();
            for (int i = 0; i < 3; i++) {
                double a = t * 0.15 + Math.PI * 2 * i / 3;
                dust(cp.getWorld(), cl.getX() + Math.cos(a) * 0.7, cl.getY() + 0.9 + 0.3 * Math.sin(a * 2), cl.getZ() + Math.sin(a) * 0.7, 0x9FD8FF, 1.0f);
            }
        }
        int cap = Math.max(5, plugin.getConfig().getInt("effects.max-cursed-drawn", 40));
        int n = 0;
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Map<String, Curse>> e : curses.entrySet()) {
            if (n >= cap) break;
            Entity ent = Bukkit.getEntity(e.getKey());
            if (!(ent instanceof LivingEntity le) || !le.isValid() || le.isDead()) continue;
            Set<String> types = new java.util.LinkedHashSet<>();
            for (Map.Entry<String, Curse> c : e.getValue().entrySet()) {
                if (c.getValue().until >= now) types.add(c.getKey());
            }
            if (types.isEmpty()) continue;
            drawCurse(le, types, t);
            n++;
        }
    }

    private void describeSummon(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        if (s.kind.equals("raise")) {
            out.add(ChatColor.GRAY + "최대 " + maxSummons(lv) + "마리, 시체 1개 사용, "
                    + fmt(plugin.getConfig().getDouble("summon.skeleton-seconds", 90.0)) + "초 동안 유지");
        }
        if (c.contains("hp")) out.add(ChatColor.GREEN + "생명력 " + fmt(val(p, s, "hp", lv, 0)));
        if (c.contains("damage") && !s.kind.equals("aura")) out.add(ChatColor.RED + "공격력 " + fmt(val(p, s, "damage", lv, 0)));
        if (c.contains("slow-pct")) out.add(ChatColor.GRAY + "맞은 적 감속 " + fmt(val(p, s, "slow-pct", lv, 0)) + "%");
        if (c.contains("lifesteal-pct")) out.add(ChatColor.RED + "피해의 " + fmt(val(p, s, "lifesteal-pct", lv, 0)) + "% 생명력 흡수 (주인도 회복)");
        if (c.contains("thorns")) out.add(ChatColor.GRAY + "맞으면 " + fmt(val(p, s, "thorns", lv, 0)) + " 피해 반사, 바닥의 금속 장비를 희생해서 소환");
        if (c.contains("fire-dps")) out.add(ChatColor.GOLD + "주변 적에게 초당 " + fmt(val(p, s, "fire-dps", lv, 0)) + " 화염 피해, 화염 피해는 생명력으로");
    }


    // ===================================================================
    //  0.20.0: 소서리스 (냉기 / 번개)  [미검증]
    //   마법 피해는 elemHit() 로 일반 피해 계산(원소 저항 포함)에 태운다. 손에 든 무기의 옵션은 섞이지 않는다.
    //   kind: nova / chain / static / telekinesis / teleport / eshield / storm / blizzard / orb / coldarmor (+ missile 확장)
    // ===================================================================

    private boolean spellFlag;

    boolean isSpellHit() {
        return spellFlag;
    }

    private String elLabel(String el) {
        return switch (el) {
            case "fire" -> "화염";
            case "cold" -> "냉기";
            case "lightning" -> "번개";
            case "poison" -> "독";
            default -> "비전";
        };
    }

    private void elemHit(Player p, LivingEntity t, String el, double dmg) {
        elemHit(p, t, el, dmg, true);
    }

    private void elemHit(Player p, LivingEntity t, String el, double dmg, boolean mastery) {
        if (dmg <= 0 || t.isDead() || !t.isValid() || isSummonEntity(t)) return;
        t.setNoDamageTicks(0); // 연속 마법 피해가 무적 시간에 막히지 않게
        double d = dmg;
        Map<String, Double> extra = new LinkedHashMap<>();
        if (mastery) {
            d *= 1.0 + passiveSum(p, el + "-dmg-pct") / 100.0;
            double rr = passiveSum(p, el + "-res-red");
            if (rr > 0) extra.put(elLabel(el) + " 저항 감소", rr);
        }
        extra.put(elLabel(el) + " 피해 추가", d);
        boolean prev = spellFlag;
        spellFlag = true;
        try {
            withTemp(p, extra, () -> hit(p, t, 0.01));
        } finally {
            spellFlag = prev;
        }
    }

    private void slowFor(LivingEntity t, double seconds, int amp) {
        if (seconds <= 0 || t.isDead()) return;
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (seconds * 20.0), amp, false, true));
    }

    private boolean isBossLike(LivingEntity t) {
        return t instanceof org.bukkit.entity.Boss || t.getType() == org.bukkit.entity.EntityType.WARDEN
                || t.getType() == org.bukkit.entity.EntityType.ELDER_GUARDIAN;
    }

    // ---------------------------------------------------------------- nova (서릿발 / 번개 파장)

    private boolean doNova(Player p, SkillDef s, int lv) {
        final String el = s.sec.getString("element", "cold");
        final double radius = radius(p, s, lv, 6.0);
        final double dmg = val(p, s, "elem-damage", lv, 0.0);
        final double frz = val(p, s, "freeze-seconds", lv, 0.0);
        final double slw = val(p, s, "slow-seconds", lv, 0.0);
        final Location c = p.getLocation();
        for (LivingEntity t : around(c, radius, p)) {
            elemHit(p, t, el, dmg);
            if (frz > 0) freezeMob(t, frz);
            slowFor(t, slw, 1);
        }
        final World w = c.getWorld();
        final int color = el.equals("cold") ? 0x9FD8FF : el.equals("fire") ? 0xFF7020 : 0xFFF060;
        new BukkitRunnable() {
            int step = 0;

            @Override
            public void run() {
                step++;
                double r = Math.min(radius, 10.0) * step / 4.0;
                for (int i = 0; i < 24; i++) {
                    double a = Math.PI * 2 * i / 24.0;
                    dust(w, c.getX() + Math.cos(a) * r, c.getY() + 0.3, c.getZ() + Math.sin(a) * r, color, 1.3f);
                }
                if (step >= 4) cancel();
            }
        }.runTaskTimer(plugin, 0L, 2L);
        w.playSound(c, el.equals("cold") ? Sound.BLOCK_GLASS_BREAK : Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, el.equals("cold") ? 1.2f : 1.6f);
        return true;
    }

    // ---------------------------------------------------------------- chain (연쇄 번개)

    private boolean doChain(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final double range = val(p, s, "range", lv, 28.0);
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + "대상이 없습니다.");
            return false;
        }
        final int bounces = Math.max(0, (int) val(p, s, "bounces", lv, 3.0));
        final double br = val(p, s, "bounce-radius", lv, 6.0);
        final double dmg = val(p, s, "elem-damage", lv, 0.0);
        final double decay = s.sec.getDouble("decay-pct", 0.0) / 100.0;
        Set<UUID> done = new HashSet<>();
        LivingEntity cur = t;
        Location from = p.getEyeLocation().add(0, -0.3, 0);
        double d = dmg;
        for (int i = 0; i <= bounces && cur != null; i++) {
            done.add(cur.getUniqueId());
            Location to = aimPoint(cur).toLocation(cur.getWorld());
            sparkLine(from, to);
            elemHit(p, cur, "lightning", d);
            from = to;
            d *= (1.0 - decay);
            LivingEntity next = null;
            double bd = Double.MAX_VALUE;
            for (LivingEntity o : around(cur.getLocation(), br, p)) {
                if (done.contains(o.getUniqueId())) continue;
                double dd = o.getLocation().distanceSquared(cur.getLocation());
                if (dd < bd) {
                    bd = dd;
                    next = o;
                }
            }
            cur = next;
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.5f, 1.8f);
        return true;
    }

    // ---------------------------------------------------------------- static (전자기장)

    private boolean doStatic(Player p, SkillDef s, int lv) {
        final double radius = radius(p, s, lv, 8.0);
        final double pct = val(p, s, "hp-pct", lv, 25.0);
        final Location c = p.getLocation();
        for (LivingEntity t : around(c, radius, p)) {
            AttributeInstance mh = t.getAttribute(VersionCompat.MAX_HEALTH);
            double max = mh == null ? 20.0 : mh.getValue();
            double cur = t.getHealth();
            double dmg = cur * pct / 100.0;
            if (isBossLike(t)) dmg = Math.min(dmg, Math.max(0.0, cur - max * 0.5)); // 보스는 최대 생명력의 절반까지만
            elemHit(p, t, "lightning", dmg, false);
        }
        final World w = c.getWorld();
        for (int i = 0; i < 30; i++) {
            double a = random.nextDouble() * Math.PI * 2;
            double r = random.nextDouble() * Math.min(radius, 10.0);
            dust(w, c.getX() + Math.cos(a) * r, c.getY() + 0.2 + random.nextDouble() * 0.8, c.getZ() + Math.sin(a) * r, 0xFFF060, 1.0f);
        }
        w.spawnParticle(Particle.ELECTRIC_SPARK, c.clone().add(0, 1.0, 0), 20, radius * 0.3, 0.6, radius * 0.3, 0.05);
        w.playSound(c, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.6f, 2.0f);
        return true;
    }

    // ---------------------------------------------------------------- telekinesis (염력)

    private boolean doTelekinesis(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final double range = val(p, s, "range", lv, 14.0);
        boolean any = false;
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        if (t != null) {
            if (!isBossLike(t)) {
                Vector away = t.getLocation().toVector().subtract(p.getLocation().toVector());
                away.setY(0);
                if (away.lengthSquared() < 0.01) away = p.getEyeLocation().getDirection().setY(0);
                t.setVelocity(away.normalize().multiply(1.3).setY(0.35));
            }
            elemHit(p, t, "lightning", val(p, s, "elem-damage", lv, 1.0));
            any = true;
        } else {
            Vector look = p.getEyeLocation().getDirection();
            for (Entity en : p.getNearbyEntities(range, range / 2.0, range)) {
                if (!(en instanceof org.bukkit.entity.Item it)) continue;
                UUID own = it.getOwner();
                if (own != null && !own.equals(p.getUniqueId())) continue; // 남의 아이템은 끌어오지 않는다
                Vector to = it.getLocation().toVector().subtract(p.getLocation().toVector());
                if (to.lengthSquared() > 0.01 && to.clone().normalize().dot(look) < 0.5) continue;
                sparkLine(it.getLocation().add(0, 0.3, 0), p.getLocation().add(0, 1.0, 0));
                it.teleport(p.getLocation().add(0, 0.5, 0));
                it.setPickupDelay(0);
                any = true;
            }
        }
        if (!any && !quiet) msg(p, ChatColor.GRAY + s.name + ": 끌어올 아이템이나 밀칠 적이 없습니다.");
        return any;
    }

    // ---------------------------------------------------------------- teleport (순간이동)

    /** 발이 닿을 안전한 자리(위 아래 2칸이 비어 있고 바닥이 단단함)를 아래로 최대 8칸 찾는다. 없으면 null. */
    private Location safeSpot(World w, double x, double y, double z) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        int by = (int) Math.floor(y);
        for (int i = 0; i <= 8; i++) {
            org.bukkit.block.Block feet = w.getBlockAt(bx, by - i, bz);
            org.bukkit.block.Block head = feet.getRelative(0, 1, 0);
            org.bukkit.block.Block below = feet.getRelative(0, -1, 0);
            if (!feet.isPassable() || !head.isPassable() || feet.isLiquid() || head.isLiquid()) {
                if (i == 0) return null;
                continue;
            }
            if (below.isPassable() || below.isLiquid()) continue;
            Material bm = below.getType();
            if (bm == Material.MAGMA_BLOCK || bm == Material.CACTUS || bm == Material.FIRE) return null;
            if (feet.getType() == Material.FIRE || feet.getType() == Material.LAVA) return null;
            return new Location(w, bx + 0.5, by - i, bz + 0.5);
        }
        return null;
    }

    private boolean doTeleport(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final double range = val(p, s, "range", lv, 30.0);
        final World w = p.getWorld();
        final Location eye = p.getEyeLocation();
        final Vector dir = eye.getDirection().normalize();
        RayTraceResult r = w.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        double blockDist = r == null ? range : eye.toVector().distance(r.getHitPosition());
        Location dest = null;
        LivingEntity t = forced != null ? forced : findTarget(p, blockDist);
        if (t != null) { // 적을 보고 쓰면 그 바로 앞으로
            Vector back = t.getLocation().toVector().subtract(dir.clone().multiply(1.3));
            dest = safeSpot(w, back.getX(), t.getLocation().getY(), back.getZ());
        } else if (r != null && r.getHitBlockFace() == org.bukkit.block.BlockFace.UP) { // 바닥을 보면 그 위로
            Vector h = r.getHitPosition();
            dest = safeSpot(w, h.getX(), h.getY() + 0.2, h.getZ());
        } else if (r != null) { // 벽: 벽 너머에 설 곳이 있으면 건너가고, 없으면 벽 앞에 선다
            double thick = Math.max(1.0, s.sec.getDouble("wall-pass-blocks", 8.0));
            for (double d = blockDist + 0.5; d <= Math.min(range, blockDist + thick) && dest == null; d += 0.5) {
                Vector v = eye.toVector().add(dir.clone().multiply(d));
                dest = safeSpot(w, v.getX(), v.getY() - 0.5, v.getZ());
            }
            for (double d = blockDist - 0.6; d >= 1.0 && dest == null; d -= 0.5) {
                Vector v = eye.toVector().add(dir.clone().multiply(d));
                dest = safeSpot(w, v.getX(), v.getY() - 0.5, v.getZ());
            }
        } else { // 허공: 가장 먼 안전한 곳
            for (double d = range; d >= 2.0 && dest == null; d -= 0.5) {
                Vector v = eye.toVector().add(dir.clone().multiply(d));
                dest = safeSpot(w, v.getX(), v.getY() - 0.5, v.getZ());
            }
        }
        if (dest == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 이동할 안전한 곳이 없습니다.");
            return false;
        }
        Location from = p.getLocation();
        dest.setYaw(from.getYaw());
        dest.setPitch(from.getPitch());
        w.spawnParticle(Particle.END_ROD, from.clone().add(0, 1.0, 0), 20, 0.3, 0.6, 0.3, 0.05);
        p.teleport(dest);
        p.setFallDistance(0.0f);
        removeDecoyOf(p); // 순간이동하면 분신은 사라진다
        w.spawnParticle(Particle.END_ROD, dest.clone().add(0, 1.0, 0), 20, 0.3, 0.6, 0.3, 0.05);
        w.playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 0.7f, 1.2f);
        return true;
    }

    // ---------------------------------------------------------------- eshield (마력 보호막)

    private final Map<UUID, double[]> eshields = new HashMap<>(); // {끝나는 시각, 흡수 %, 피해당 마나}

    private boolean doEShield(Player p, SkillDef s, int lv) {
        if (eshields.remove(p.getUniqueId()) != null) { // 다시 쓰면 끈다
            msg(p, ChatColor.GRAY + s.name + " 해제");
            return true;
        }
        double pct = Math.min(95.0, val(p, s, "absorb-pct", lv, 20.0));
        double mpd = Math.max(0.5, val(p, s, "mana-per-damage", lv, 3.0));
        double secs = val(p, s, "shield-seconds", lv, 120.0);
        eshields.put(p.getUniqueId(), new double[]{System.currentTimeMillis() + secs * 1000.0, pct, mpd});
        p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 2.2, 0), 8, 0.3, 0.1, 0.3, 0.01);
        msg(p, ChatColor.AQUA + s.name + ": 받는 피해의 " + fmt(pct) + "%를 마나로 받습니다. (피해 1당 마나 " + fmt(mpd) + ")");
        return true;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEShield(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player v)) return;
        double[] sh = eshields.get(v.getUniqueId());
        if (sh == null) return;
        if (sh[0] < System.currentTimeMillis()) {
            eshields.remove(v.getUniqueId());
            return;
        }
        DamageCause c = e.getCause();
        if (c == DamageCause.VOID || c == DamageCause.SUICIDE) return;
        StatSystem ss = plugin.statSystem();
        double mana = ss.getMana(v);
        if (mana <= 0) {
            eshields.remove(v.getUniqueId());
            msg(v, ChatColor.GRAY + "마나가 바닥나 마력 보호막이 사라졌다.");
            return;
        }
        double dmg = e.getDamage();
        double absorbed = dmg * sh[1] / 100.0;
        double cost = absorbed * sh[2];
        if (cost > mana) {
            absorbed = mana / sh[2];
            cost = mana;
        }
        ss.setMana(v, mana - cost);
        e.setDamage(Math.max(0.0, dmg - absorbed));
        v.getWorld().spawnParticle(Particle.END_ROD, v.getLocation().add(0, 2.2, 0), 2, 0.2, 0.05, 0.2, 0.0);
        if (mana - cost <= 0.0001) {
            eshields.remove(v.getUniqueId());
            msg(v, ChatColor.GRAY + "마나가 바닥나 마력 보호막이 사라졌다.");
        }
    }

    // ---------------------------------------------------------------- storm (뇌우)

    private final Map<UUID, BukkitTask> storms = new HashMap<>();

    private boolean doStorm(Player p, SkillDef s, int lv) {
        BukkitTask old = storms.remove(p.getUniqueId());
        if (old != null) old.cancel();
        final double dur = val(p, s, "storm-seconds", lv, 24.0);
        final double interval = Math.max(0.5, val(p, s, "interval-seconds", lv, 4.0));
        final double radius = radius(p, s, lv, 8.0);
        final double dmg = val(p, s, "elem-damage", lv, 10.0);
        final long end = System.currentTimeMillis() + (long) (dur * 1000.0);
        final BukkitTask[] ref = new BukkitTask[1];
        ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || p.isDead() || System.currentTimeMillis() > end) {
                ref[0].cancel();
                storms.remove(p.getUniqueId());
                return;
            }
            List<LivingEntity> list = around(p.getLocation(), radius, p);
            World w = p.getWorld();
            Location top = p.getLocation().add(0, 3.2, 0);
            for (int i = 0; i < 8; i++) {
                dust(w, top.getX() + (random.nextDouble() - 0.5) * 2.5, top.getY(), top.getZ() + (random.nextDouble() - 0.5) * 2.5, 0x505058, 2.0f);
            }
            if (list.isEmpty()) return;
            LivingEntity best = list.get(random.nextInt(list.size()));
            w.strikeLightningEffect(best.getLocation());
            elemHit(p, best, "lightning", dmg);
        }, 10L, Math.max(10L, (long) (interval * 20.0)));
        storms.put(p.getUniqueId(), ref[0]);
        msg(p, ChatColor.YELLOW + s.name + ": " + fmt(dur) + "초 동안 주변 적에게 번개가 내립니다.");
        return true;
    }

    // ---------------------------------------------------------------- blizzard (눈보라)

    private int activeZones;

    private boolean doBlizzard(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final int maxZones = Math.max(1, plugin.getConfig().getInt("spell.max-zones", 8));
        if (activeZones >= maxZones) {
            if (!quiet) msg(p, ChatColor.GRAY + "지금은 눈보라를 더 만들 수 없습니다. (동시 한도)");
            return false;
        }
        final double range = val(p, s, "range", lv, 28.0);
        final World w = p.getWorld();
        Location eye = p.getEyeLocation();
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        final Location center;
        if (t != null) {
            center = t.getLocation().clone();
        } else {
            RayTraceResult r = w.rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
            if (r == null) {
                if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 땅을 바라보고 쓰세요.");
                return false;
            }
            center = r.getHitPosition().toLocation(w);
        }
        final double radius = val(p, s, "radius", lv, 5.0);
        final double dur = val(p, s, "duration", lv, 4.0);
        final double dmg = val(p, s, "elem-damage", lv, 10.0);
        final double slw = val(p, s, "slow-seconds", lv, 2.0);
        final int ticks = (int) (dur * 20.0 / 3.0);
        activeZones++;
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (n++ >= ticks || !p.isOnline()) {
                    activeZones = Math.max(0, activeZones - 1);
                    cancel();
                    return;
                }
                int shards = 1 + random.nextInt(2);
                for (int i = 0; i < shards; i++) {
                    double a = random.nextDouble() * Math.PI * 2;
                    double rr = Math.sqrt(random.nextDouble()) * radius;
                    final Location at = center.clone().add(Math.cos(a) * rr, 0.0, Math.sin(a) * rr);
                    w.spawnParticle(Particle.SNOWFLAKE, at.clone().add(0, 4.0, 0), 8, 0.1, 2.0, 0.1, 0.0);
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        dust(w, at.getX(), at.getY() + 0.2, at.getZ(), 0xCCE8FF, 1.6f);
                        w.spawnParticle(Particle.SNOWFLAKE, at.clone().add(0, 0.3, 0), 6, 0.3, 0.2, 0.3, 0.02);
                        for (LivingEntity o : around(at, 1.8, p)) {
                            elemHit(p, o, "cold", dmg);
                            slowFor(o, slw, 1);
                        }
                    }, 6L);
                }
                if (n % 4 == 0) w.playSound(center, Sound.BLOCK_GLASS_BREAK, 0.5f, 1.5f);
            }
        }.runTaskTimer(plugin, 0L, 3L);
        return true;
    }

    // ---------------------------------------------------------------- orb (얼음 보주)

    private boolean doOrb(Player p, SkillDef s, int lv) {
        final World w = p.getWorld();
        final Vector dir = p.getEyeLocation().getDirection().setY(0.0);
        if (dir.lengthSquared() < 0.01) return false;
        dir.normalize();
        final Location pos = p.getEyeLocation().add(dir.clone().multiply(1.5)).subtract(0, 0.4, 0);
        final double range = val(p, s, "range", lv, 22.0);
        final double dmg = val(p, s, "elem-damage", lv, 8.0);
        final int bolts = Math.max(2, (int) val(p, s, "bolts", lv, 4.0));
        final double slw = val(p, s, "slow-seconds", lv, 2.0);
        new BukkitRunnable() {
            int step = 0;
            double traveled = 0.0;

            @Override
            public void run() {
                step++;
                if (!p.isOnline() || traveled >= range || step > 80 || !pos.getBlock().isPassable()) {
                    w.spawnParticle(Particle.SNOWFLAKE, pos, 20, 0.5, 0.5, 0.5, 0.05);
                    cancel();
                    return;
                }
                pos.add(dir.clone().multiply(0.45));
                traveled += 0.45;
                dust(w, pos.getX(), pos.getY(), pos.getZ(), 0xCCE8FF, 2.6f);
                w.spawnParticle(Particle.SNOWFLAKE, pos, 3, 0.2, 0.2, 0.2, 0.01);
                if (step % 5 == 0) {
                    double off = step * 0.7;
                    for (int i = 0; i < bolts; i++) {
                        double a = off + Math.PI * 2 * i / bolts;
                        Vector v = new Vector(Math.cos(a), 0.0, Math.sin(a));
                        flyMissile(p, pos.clone(), v, 1.4, 8.0, false, false, null, Particle.SNOWFLAKE, null, le -> {
                            elemHit(p, le, "cold", dmg);
                            slowFor(le, slw, 1);
                        });
                    }
                    w.playSound(pos, Sound.BLOCK_GLASS_BREAK, 0.3f, 1.8f);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
        return true;
    }

    // ---------------------------------------------------------------- coldarmor (얼어붙은 / 오한 / 냉기 갑옷)

    static final class ColdArmor {
        String type;
        double dmg;
        double freeze;
        long until;
    }

    private final Map<UUID, ColdArmor> coldArmors = new HashMap<>();

    private boolean doColdArmor(Player p, SkillDef s, int lv) {
        ColdArmor ca = new ColdArmor();
        ca.type = s.sec.getString("armor-type", "frozen");
        ca.dmg = val(p, s, "elem-damage", lv, 0.0);
        ca.freeze = val(p, s, "freeze-seconds", lv, 1.0);
        ca.until = System.currentTimeMillis() + (long) (val(p, s, "armor-seconds", lv, 120.0) * 1000.0);
        coldArmors.put(p.getUniqueId(), ca); // 냉기 갑옷은 하나만 유지
        p.getWorld().spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(0, 1.0, 0), 25, 0.4, 0.7, 0.4, 0.02);
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_GLASS_BREAK, 0.8f, 1.0f);
        msg(p, ChatColor.AQUA + s.name + ": " + fmt(val(p, s, "armor-seconds", lv, 120.0)) + "초");
        return true;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onColdArmorHit(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player v)) return;
        ColdArmor ca = coldArmors.get(v.getUniqueId());
        if (ca == null) return;
        if (ca.until < System.currentTimeMillis()) {
            coldArmors.remove(v.getUniqueId());
            return;
        }
        final LivingEntity att = mobAttacker(e.getDamager());
        if (att == null || isSummonEntity(att) || !att.isValid()) return;
        boolean ranged = e.getDamager() instanceof Projectile;
        switch (ca.type) {
            case "frozen" -> {
                if (!ranged) freezeMob(att, ca.freeze);
            }
            case "shiver" -> {
                if (!ranged) {
                    elemHit(v, att, "cold", ca.dmg);
                    slowFor(att, ca.freeze, 1);
                }
            }
            default -> {
                if (ranged) { // 냉기 갑옷: 원거리 공격자에게 얼음살로 보복
                    Vector to = aimPoint(att).subtract(v.getEyeLocation().toVector());
                    if (to.lengthSquared() > 0.01) {
                        final double d = ca.dmg;
                        final double fz = ca.freeze;
                        flyMissile(v, v.getEyeLocation().add(0, -0.2, 0), to.normalize(), 1.4, 28.0, false, false, att, Particle.SNOWFLAKE, null, le -> {
                            elemHit(v, le, "cold", d);
                            slowFor(le, fz, 1);
                        });
                    }
                }
            }
        }
    }

    private void describeSorc(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        String el = c.getString("element", "");
        if (c.contains("elem-damage")) {
            out.add(ChatColor.AQUA + (el.isEmpty() ? "" : elLabel(el) + " ") + "마법 피해 " + fmt(val(p, s, "elem-damage", lv, 0))
                    + " (원소 저항 적용" + (el.isEmpty() ? "" : ", " + elLabel(el) + " 숙련 반영") + ")");
        }
        if (c.contains("freeze-seconds")) out.add(ChatColor.AQUA + "빙결 " + fmt(val(p, s, "freeze-seconds", lv, 0)) + "초");
        if (c.contains("slow-seconds")) out.add(ChatColor.GRAY + "감속 " + fmt(val(p, s, "slow-seconds", lv, 0)) + "초");
        if (c.contains("explosion-radius")) out.add(ChatColor.GRAY + "폭발 범위 " + fmt(val(p, s, "explosion-radius", lv, 0)) + "칸");
        if (c.contains("bounces")) out.add(ChatColor.YELLOW + "최대 " + (int) val(p, s, "bounces", lv, 0) + "번 튕김");
        if (c.contains("hp-pct")) out.add(ChatColor.YELLOW + "현재 생명력의 " + fmt(val(p, s, "hp-pct", lv, 0)) + "% (보스는 절반까지만)");
        if (c.contains("storm-seconds")) out.add(ChatColor.YELLOW + fmt(val(p, s, "storm-seconds", lv, 0)) + "초 동안 " + fmt(val(p, s, "interval-seconds", lv, 0)) + "초마다 번개");
        if (c.contains("armor-seconds")) out.add(ChatColor.AQUA + "지속 " + fmt(val(p, s, "armor-seconds", lv, 0)) + "초 (냉기 갑옷은 하나만 유지)");
        if (c.contains("absorb-pct")) out.add(ChatColor.AQUA + "받는 피해의 " + fmt(Math.min(95.0, val(p, s, "absorb-pct", lv, 0))) + "%를 마나로 (피해 1당 마나 " + fmt(Math.max(0.5, val(p, s, "mana-per-damage", lv, 3))) + ")");
        if (c.contains("bolts")) out.add(ChatColor.GRAY + "얼음살 " + (int) val(p, s, "bolts", lv, 0) + "발씩 뿜음");
        if (c.contains("flame-seconds")) out.add(ChatColor.GOLD + fmt(val(p, s, "flame-seconds", lv, 0)) + "초 동안 불줄기 (0.25초마다 피해, 사거리 " + fmt(val(p, s, "range", lv, 0)) + "칸)");
        if (c.contains("blaze-seconds")) out.add(ChatColor.GOLD + fmt(val(p, s, "blaze-seconds", lv, 0)) + "초 동안 이동속도 증가 + 지나간 자리에 불길");
        if (c.contains("wall-width")) out.add(ChatColor.GOLD + "화염벽 너비 " + fmt(val(p, s, "wall-width", lv, 0)) + "칸, 지속 " + fmt(val(p, s, "zone-seconds", lv, 0)) + "초 (0.5초마다 피해)");
        if (c.contains("enchant-seconds")) out.add(ChatColor.GOLD + "지속 " + fmt(val(p, s, "enchant-seconds", lv, 0)) + "초 (원거리는 1/3, 바라보는 플레이어에게 걸 수 있음)");
        if (c.contains("delay-seconds")) out.add(ChatColor.GOLD + "낙하까지 " + fmt(val(p, s, "delay-seconds", lv, 0)) + "초, 불길 피해 " + fmt(val(p, s, "zone-damage", lv, 0)) + " x " + fmt(val(p, s, "zone-seconds", lv, 0)) + "초");
        if (c.contains("hydra-seconds")) out.add(ChatColor.GOLD + "히드라 " + fmt(val(p, s, "hydra-seconds", lv, 0)) + "초 (머리 " + c.getInt("heads", 3) + "개, 머리당 최대 " + c.getInt("bolts-per-head", 8) + "발)");
        if (c.contains("cast-seconds")) out.add(ChatColor.GRAY + "시전 지연 " + fmt(c.getDouble("cast-seconds", 0.8)) + "초 (시전 속도로 줄어듦)");
        if (c.contains("passive-note")) out.add(ChatColor.GRAY + c.getString("passive-note", ""));
    }

    // ===================================================================
    //  0.20.0: 골렘 저장 (서버를 껐다 켜거나 다시 접속해도 그대로)  [미검증]
    // ===================================================================

    private java.io.File golemFile() {
        return new java.io.File(plugin.getDataFolder(), "golems.yml");
    }

    private void saveGolemRecord(Summon sm, double health) {
        try {
            org.bukkit.configuration.file.YamlConfiguration y = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(golemFile());
            String k = sm.owner.toString();
            y.set(k + ".golem", sm.golem);
            y.set(k + ".max-hp", sm.ent.getAttribute(VersionCompat.MAX_HEALTH) == null ? 100.0 : sm.ent.getAttribute(VersionCompat.MAX_HEALTH).getBaseValue());
            y.set(k + ".health", health);
            y.set(k + ".damage", sm.dmg);
            y.set(k + ".slow-pct", sm.slowPct);
            y.set(k + ".lifesteal", sm.lifesteal);
            y.set(k + ".thorns", sm.thorns);
            y.set(k + ".fire-dps", sm.fireDps);
            plugin.getDataFolder().mkdirs();
            y.save(golemFile());
        } catch (Exception ex) {
            plugin.getLogger().warning("golems.yml 저장 실패: " + ex.getMessage());
        }
    }

    private void deleteGolemRecord(UUID owner) {
        try {
            if (!golemFile().exists()) return;
            org.bukkit.configuration.file.YamlConfiguration y = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(golemFile());
            if (!y.contains(owner.toString())) return;
            y.set(owner.toString(), null);
            y.save(golemFile());
        } catch (Exception ex) {
            plugin.getLogger().warning("golems.yml 삭제 실패: " + ex.getMessage());
        }
    }

    /** 접속하면 저장된 골렘을 같은 능력치로 다시 불러온다. */
    private void respawnGolem(Player p) {
        try {
            if (!p.isOnline() || !golemFile().exists()) return;
            org.bukkit.configuration.file.YamlConfiguration y = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(golemFile());
            String k = p.getUniqueId().toString();
            if (!y.contains(k) || !ownedSummons(p.getUniqueId(), "golem").isEmpty()) return;
            if (!summonRoomFor(p, 0)) return;
            String g = y.getString(k + ".golem", "clay");
            Summon sm = spawnGolemEntity(p, g, p.getLocation().add(1.5, 0.2, 0.0), y.getDouble(k + ".max-hp", 100.0),
                    y.getDouble(k + ".damage", 5.0), y.getDouble(k + ".slow-pct", 0.0), y.getDouble(k + ".lifesteal", 0.0),
                    y.getDouble(k + ".thorns", 0.0), y.getDouble(k + ".fire-dps", 0.0), y.getDouble(k + ".health", 1.0));
            msg(p, ChatColor.GRAY + "골렘이 돌아왔습니다. (생명력 " + fmt(sm.ent.getHealth()) + ")");
        } catch (Exception ex) {
            plugin.getLogger().warning("골렘 복구 실패: " + ex.getMessage());
        }
    }

    private Summon spawnGolemEntity(Player p, String g, Location at, double hp, double dmg, double slowPct, double lifesteal,
                                    double thorns, double fireDps, double health) {
        final World w = at.getWorld();
        String nm = switch (g) {
            case "blood" -> ChatColor.DARK_RED + "피 골렘";
            case "iron" -> ChatColor.WHITE + "강철 골렘";
            case "fire" -> ChatColor.GOLD + "화염 골렘";
            default -> ChatColor.YELLOW + "점토 골렘";
        };
        LivingEntity ent;
        if (g.equals("blood")) {
            org.bukkit.entity.Zombie z = w.spawn(at, org.bukkit.entity.Zombie.class);
            z.setBaby(false);
            org.bukkit.inventory.EntityEquipment eq = z.getEquipment();
            if (eq != null) {
                eq.setHelmet(unbreakable(Material.LEATHER_HELMET, 0x8B0000));
                eq.setChestplate(unbreakable(Material.LEATHER_CHESTPLATE, 0x8B0000));
                eq.setLeggings(unbreakable(Material.LEATHER_LEGGINGS, 0x8B0000));
                eq.setBoots(unbreakable(Material.LEATHER_BOOTS, 0x8B0000));
                eq.setItemInMainHand(new ItemStack(Material.AIR));
                eq.setItemInOffHand(new ItemStack(Material.AIR));
                noDrops(eq);
                eq.setLeggingsDropChance(0f);
                eq.setBootsDropChance(0f);
            }
            ent = z;
        } else {
            org.bukkit.entity.IronGolem ig = w.spawn(at, org.bukkit.entity.IronGolem.class);
            ig.setPlayerCreated(true);
            ent = ig;
        }
        setupSummon(ent, nm, hp, dmg);
        ent.setHealth(Math.max(1.0, Math.min(health, hp)));
        if (g.equals("fire")) ent.setVisualFire(true);
        Summon sm = new Summon();
        sm.owner = p.getUniqueId();
        sm.ent = ent;
        sm.type = "golem";
        sm.golem = g;
        sm.dmg = dmg;
        sm.slowPct = slowPct;
        sm.lifesteal = lifesteal;
        sm.thorns = thorns;
        sm.fireDps = fireDps;
        sm.until = 0L; // 골렘은 시간 제한 없음
        summons.put(ent.getUniqueId(), sm);
        saveGolemRecord(sm, ent.getHealth());
        return sm;
    }


    // ===================================================================
    //  0.21.0: 소서리스 화염 탭 + 히드라  [미검증]
    // ===================================================================

    private int fireZones;

    private Location groundTarget(Player p, double range, LivingEntity forced) {
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        if (t != null) return t.getLocation().clone();
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
        if (r == null) return null;
        return r.getHitPosition().toLocation(p.getWorld());
    }

    /** 바닥 불길: 반경 안의 적에게 0.5초마다 화염 피해. */
    private void fireZone(Player p, Location c, double radius, double seconds, double dmg) {
        final int cap = Math.max(1, plugin.getConfig().getInt("spell.max-fire-zones", 30));
        if (fireZones >= cap) return;
        fireZones++;
        final World w = c.getWorld();
        final int pulses = Math.max(1, (int) (seconds * 2.0));
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (n++ >= pulses || !p.isOnline()) {
                    fireZones = Math.max(0, fireZones - 1);
                    cancel();
                    return;
                }
                for (int i = 0; i < 5; i++) {
                    double a = random.nextDouble() * Math.PI * 2;
                    double r = Math.sqrt(random.nextDouble()) * radius;
                    w.spawnParticle(Particle.FLAME, c.getX() + Math.cos(a) * r, c.getY() + 0.15, c.getZ() + Math.sin(a) * r, 1, 0.05, 0.1, 0.05, 0.01);
                }
                for (LivingEntity o : around(c, radius, p)) elemHit(p, o, "fire", dmg);
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    // ---------------------------------------------------------------- inferno (지옥불)

    private boolean doInferno(Player p, SkillDef s, int lv) {
        final double secs = val(p, s, "flame-seconds", lv, 3.0);
        final double range = val(p, s, "range", lv, 6.0);
        final double dmg = val(p, s, "elem-damage", lv, 5.0);
        final int ticks = Math.max(1, (int) (secs * 4.0));
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (n++ >= ticks || !p.isOnline() || p.isDead()) {
                    cancel();
                    return;
                }
                World w = p.getWorld();
                Location eye = p.getEyeLocation();
                Vector d = eye.getDirection().normalize();
                for (double k = 1.0; k <= range; k += 0.5) {
                    Location l = eye.clone().add(d.clone().multiply(k)).add(0, -0.3, 0);
                    w.spawnParticle(Particle.FLAME, l, 2, 0.08 * k, 0.08 * k, 0.08 * k, 0.01);
                }
                for (LivingEntity t : around(p.getLocation(), range + 1.0, p)) {
                    Vector to = aimPoint(t).subtract(eye.toVector());
                    double dist = to.length();
                    if (dist > range + 0.5 || dist < 0.3) continue;
                    if (to.normalize().dot(d) < 0.9) continue;
                    elemHit(p, t, "fire", dmg);
                }
                if (n % 2 == 1) w.playSound(p.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 0.8f, 1.2f);
            }
        }.runTaskTimer(plugin, 0L, 5L);
        return true;
    }

    // ---------------------------------------------------------------- blaze (불길)

    private boolean doBlaze(Player p, SkillDef s, int lv) {
        final double secs = val(p, s, "blaze-seconds", lv, 4.0);
        final double zsec = val(p, s, "zone-seconds", lv, 3.0);
        final double radius = val(p, s, "zone-radius", lv, 1.6);
        final double dmg = val(p, s, "elem-damage", lv, 4.0);
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, (int) (secs * 20.0), 1, false, false));
        final int steps = Math.max(1, (int) (secs * 2.0));
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (n++ >= steps || !p.isOnline() || p.isDead()) {
                    cancel();
                    return;
                }
                fireZone(p, p.getLocation(), radius, zsec, dmg);
            }
        }.runTaskTimer(plugin, 0L, 10L);
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_FIRECHARGE_USE, 0.8f, 1.0f);
        return true;
    }

    // ---------------------------------------------------------------- firewall (화염벽)

    private boolean doFireWall(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        Location c = groundTarget(p, val(p, s, "range", lv, 24.0), forced);
        if (c == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 땅을 바라보고 쓰세요.");
            return false;
        }
        final int cap = Math.max(1, plugin.getConfig().getInt("spell.max-fire-zones", 30));
        if (fireZones >= cap) {
            if (!quiet) msg(p, ChatColor.GRAY + "지금은 불길을 더 만들 수 없습니다. (동시 한도)");
            return false;
        }
        fireZones++;
        final double width = val(p, s, "wall-width", lv, 6.0);
        final double secs = val(p, s, "zone-seconds", lv, 3.5);
        final double dmg = val(p, s, "elem-damage", lv, 9.0);
        Vector look = p.getEyeLocation().getDirection().setY(0.0);
        if (look.lengthSquared() < 0.01) look = new Vector(1, 0, 0);
        look.normalize();
        final Vector side = new Vector(-look.getZ(), 0.0, look.getX());
        final List<Location> pts = new ArrayList<>();
        for (double k = -width / 2.0; k <= width / 2.0 + 0.01; k += 1.0) pts.add(c.clone().add(side.clone().multiply(k)));
        final World w = c.getWorld();
        final int pulses = Math.max(1, (int) (secs * 2.0));
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (n++ >= pulses || !p.isOnline()) {
                    fireZones = Math.max(0, fireZones - 1);
                    cancel();
                    return;
                }
                Set<UUID> hit = new HashSet<>();
                for (Location l : pts) {
                    w.spawnParticle(Particle.FLAME, l.getX(), l.getY() + 0.5, l.getZ(), 4, 0.25, 0.4, 0.25, 0.01);
                    for (LivingEntity o : around(l, 1.1, p)) {
                        if (hit.add(o.getUniqueId())) elemHit(p, o, "fire", dmg);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 10L);
        w.playSound(c, Sound.ITEM_FIRECHARGE_USE, 1.0f, 0.8f);
        return true;
    }

    // ---------------------------------------------------------------- enchant (마법부여)

    private final Map<UUID, double[]> enchants = new HashMap<>(); // {끝나는 시각, 추가 화염 피해}

    private boolean doEnchant(Player p, SkillDef s, int lv) {
        Player target = p;
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceEntities(eye, eye.getDirection(), val(p, s, "range", lv, 16.0), 0.6,
                en -> en instanceof Player && !en.equals(p));
        if (r != null && r.getHitEntity() instanceof Player o) target = o;
        double secs = val(p, s, "enchant-seconds", lv, 120.0);
        double dmg = val(p, s, "elem-damage", lv, 8.0);
        enchants.put(target.getUniqueId(), new double[]{System.currentTimeMillis() + secs * 1000.0, dmg});
        target.getWorld().spawnParticle(Particle.FLAME, target.getLocation().add(0, 1.0, 0), 25, 0.4, 0.6, 0.4, 0.03);
        target.getWorld().playSound(target.getLocation(), Sound.ITEM_FIRECHARGE_USE, 0.8f, 1.4f);
        if (target != p) {
            msg(p, ChatColor.GOLD + target.getName() + "에게 " + s.name + " (" + fmt(secs) + "초)");
            msg(target, ChatColor.GOLD + p.getName() + "의 " + s.name + ": 공격에 화염 피해 +" + fmt(dmg) + " (" + fmt(secs) + "초)");
        } else {
            msg(p, ChatColor.GOLD + s.name + ": 공격에 화염 피해 +" + fmt(dmg) + " (" + fmt(secs) + "초)");
        }
        return true;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEnchantStrike(EntityDamageByEntityEvent e) {
        if (spellFlag || enchants.isEmpty()) return;
        Player a = null;
        double mul = 1.0;
        if (e.getDamager() instanceof Player pl) {
            a = pl;
        } else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player pl2) {
            a = pl2;
            mul = 1.0 / 3.0; // 원거리는 1/3
        }
        if (a == null) return;
        double[] en = enchants.get(a.getUniqueId());
        if (en == null) return;
        if (en[0] < System.currentTimeMillis()) {
            enchants.remove(a.getUniqueId());
            return;
        }
        if (!(e.getEntity() instanceof LivingEntity t) || t instanceof Player || isSummonEntity(t)) return;
        final Player fa = a;
        final double dm = en[1] * mul;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!t.isValid() || t.isDead()) return;
            elemHit(fa, t, "fire", dm);
            t.getWorld().spawnParticle(Particle.FLAME, t.getLocation().add(0, 1.0, 0), 8, 0.25, 0.4, 0.25, 0.02);
        });
    }

    // ---------------------------------------------------------------- meteor (운석 낙하)

    private boolean doMeteor(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final Location c = groundTarget(p, val(p, s, "range", lv, 28.0), forced);
        if (c == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 땅을 바라보고 쓰세요.");
            return false;
        }
        final double radius = radius(p, s, lv, 4.5);
        final double dmg = val(p, s, "elem-damage", lv, 40.0);
        final double zdmg = val(p, s, "zone-damage", lv, 6.0);
        final double zsec = val(p, s, "zone-seconds", lv, 6.0);
        final int steps = Math.max(2, (int) (val(p, s, "delay-seconds", lv, 2.0) * 10.0)); // 2틱마다
        final World w = c.getWorld();
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                n++;
                double left = Math.max(0.0, 1.0 - (double) n / steps);
                // 떨어질 자리 표시
                for (int i = 0; i < 12; i++) {
                    double a = Math.PI * 2 * i / 12.0;
                    dust(w, c.getX() + Math.cos(a) * radius, c.getY() + 0.2, c.getZ() + Math.sin(a) * radius, 0xFF6020, 1.0f);
                }
                Location m = c.clone().add(left * 8.0, left * 20.0, left * 4.0);
                w.spawnParticle(Particle.FLAME, m, 14, 0.4, 0.4, 0.4, 0.03);
                dust(w, m.getX(), m.getY(), m.getZ(), 0xFF8030, 3.0f);
                if (n >= steps) {
                    cancel();
                    for (LivingEntity o : around(c, radius, p)) elemHit(p, o, "fire", dmg);
                    w.spawnParticle(Particle.EXPLOSION, c.clone().add(0, 0.5, 0), 4, radius * 0.4, 0.3, radius * 0.4, 0.0);
                    w.spawnParticle(Particle.FLAME, c.clone().add(0, 0.5, 0), 60, radius * 0.5, 0.5, radius * 0.5, 0.08);
                    w.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.7f);
                    fireZone(p, c, radius * 0.9, zsec, zdmg);
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);
        return true;
    }

    // ---------------------------------------------------------------- hydra (히드라)

    private final Map<UUID, java.util.ArrayDeque<BukkitTask>> hydras = new HashMap<>();

    private boolean doHydra(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final Location c = groundTarget(p, val(p, s, "range", lv, 24.0), forced);
        if (c == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 땅을 바라보고 쓰세요.");
            return false;
        }
        c.setY(Math.floor(c.getY()));
        final double secs = val(p, s, "hydra-seconds", lv, 10.0);
        final double sight = val(p, s, "sight", lv, 16.0);
        final double dmg = val(p, s, "elem-damage", lv, 10.0);
        final int heads = Math.max(1, s.sec.getInt("heads", 3));
        final int maxBolts = heads * Math.max(1, s.sec.getInt("bolts-per-head", 8));
        final int cap = Math.max(1, plugin.getConfig().getInt("spell.max-hydras", 6));
        final java.util.ArrayDeque<BukkitTask> dq = hydras.computeIfAbsent(p.getUniqueId(), k -> new java.util.ArrayDeque<>());
        while (dq.size() >= cap) {
            BukkitTask old = dq.pollFirst();
            if (old != null) old.cancel();
        }
        final World w = c.getWorld();
        final long end = System.currentTimeMillis() + (long) (secs * 1000.0);
        final int[] fired = {0};
        final int[] tick = {0};
        final BukkitTask[] ref = new BukkitTask[1];
        ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || System.currentTimeMillis() > end || fired[0] >= maxBolts) {
                w.spawnParticle(Particle.LARGE_SMOKE, c.clone().add(0, 1.0, 0), 12, 0.4, 0.5, 0.4, 0.02);
                ref[0].cancel();
                dq.remove(ref[0]);
                return;
            }
            tick[0]++;
            final Location[] hp = new Location[heads];
            for (int i = 0; i < heads; i++) {
                double a = Math.PI * 2 * i / heads + tick[0] * 0.1;
                hp[i] = c.clone().add(Math.cos(a) * 0.6, 1.7 + 0.15 * Math.sin(tick[0] * 0.7 + i), Math.sin(a) * 0.6);
                for (double y = 0.2; y < hp[i].getY() - c.getY(); y += 0.35) {
                    dust(w, hp[i].getX(), c.getY() + y, hp[i].getZ(), 0xC03010, 1.4f);
                }
                dust(w, hp[i].getX(), hp[i].getY(), hp[i].getZ(), 0xFF8020, 2.2f);
                w.spawnParticle(Particle.FLAME, hp[i], 2, 0.1, 0.1, 0.1, 0.01);
            }
            // 머리 하나씩 번갈아 발사
            LivingEntity best = null;
            double bd = Double.MAX_VALUE;
            for (LivingEntity o : around(c, sight, p)) {
                double dd = o.getLocation().distanceSquared(c);
                if (dd < bd) {
                    bd = dd;
                    best = o;
                }
            }
            if (best == null) return;
            Location from = hp[tick[0] % heads];
            Vector dir = aimPoint(best).subtract(from.toVector());
            if (dir.lengthSquared() < 0.01) return;
            fired[0]++;
            flyMissile(p, from.clone(), dir.normalize(), 1.3, sight + 4.0, false, false, best, Particle.FLAME, null,
                    le -> elemHit(p, le, "fire", dmg));
            w.playSound(from, Sound.ENTITY_BLAZE_SHOOT, 0.5f, 1.4f);
        }, 0L, 6L);
        dq.addLast(ref[0]);
        w.playSound(c, Sound.ENTITY_BLAZE_AMBIENT, 1.0f, 0.6f);
        msg(p, ChatColor.GOLD + s.name + ": " + fmt(secs) + "초 (동시 최대 " + cap + "마리)");
        return true;
    }


    // ===================================================================
    //  0.22.0: 아마존 미끼 / 발키리 (소환 시스템 사용)  [미검증]
    // ===================================================================

    private Location summonSpot(Player p, double range, LivingEntity forced) {
        Location at = groundTarget(p, range, forced);
        if (at == null) {
            Vector f = p.getEyeLocation().getDirection().setY(0.0);
            if (f.lengthSquared() < 0.01) f = new Vector(1, 0, 0);
            return p.getLocation().add(f.normalize().multiply(2.0)).add(0, 0.1, 0);
        }
        Vector back = p.getLocation().toVector().subtract(at.toVector()).setY(0.0);
        if (back.lengthSquared() > 4.0) at.add(back.normalize().multiply(1.5)); // 조준한 곳 바로 앞
        return at.add(0, 0.1, 0);
    }

    private ItemStack unbr(Material m) {
        ItemStack it = new ItemStack(m);
        org.bukkit.inventory.meta.ItemMeta im = it.getItemMeta();
        if (im != null) {
            im.setUnbreakable(true);
            it.setItemMeta(im);
        }
        return it;
    }

    private void removeDecoyOf(Player p) {
        for (Summon sm : ownedSummons(p.getUniqueId(), "decoy")) removeSummon(sm, true);
    }

    private boolean doDecoy(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final UUID id = p.getUniqueId();
        List<Summon> old = ownedSummons(id, "decoy");
        if (!summonRoomFor(p, old.size())) return false;
        for (Summon o : old) removeSummon(o, true); // 새로 만들면 기존 분신은 사라진다
        final Location at = summonSpot(p, val(p, s, "range", lv, 24.0), forced);
        final double hp = val(p, s, "hp", lv, 100.0);
        org.bukkit.entity.Zombie z = at.getWorld().spawn(at, org.bukkit.entity.Zombie.class);
        z.setBaby(false);
        setupSummon(z, ChatColor.GRAY + p.getName() + " 분신", hp, 0.0);
        z.setAI(false);
        z.setSilent(true);
        org.bukkit.inventory.EntityEquipment eq = z.getEquipment();
        if (eq != null) {
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            org.bukkit.inventory.meta.SkullMeta sk = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta();
            if (sk != null) {
                sk.setOwningPlayer(p);
                head.setItemMeta(sk);
            }
            eq.setHelmet(head);
            org.bukkit.inventory.PlayerInventory pi = p.getInventory();
            if (pi.getChestplate() != null) eq.setChestplate(pi.getChestplate().clone());
            if (pi.getLeggings() != null) eq.setLeggings(pi.getLeggings().clone());
            if (pi.getBoots() != null) eq.setBoots(pi.getBoots().clone());
            ItemStack hand = pi.getItemInMainHand();
            if (hand != null && hand.getType() != Material.AIR) eq.setItemInMainHand(hand.clone());
            eq.setHelmetDropChance(0f);
            eq.setChestplateDropChance(0f);
            eq.setLeggingsDropChance(0f);
            eq.setBootsDropChance(0f);
            eq.setItemInMainHandDropChance(0f);
        }
        Summon sm = new Summon();
        sm.owner = id;
        sm.ent = z;
        sm.type = "decoy";
        sm.radius = val(p, s, "aggro-radius", lv, 10.0);
        sm.until = System.currentTimeMillis() + (long) (val(p, s, "decoy-seconds", lv, 10.0) * 1000.0);
        summons.put(z.getUniqueId(), sm);
        at.getWorld().spawnParticle(Particle.CLOUD, at.clone().add(0, 1.0, 0), 20, 0.3, 0.6, 0.3, 0.03);
        at.getWorld().playSound(at, Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 0.8f, 1.2f);
        msg(p, ChatColor.GRAY + s.name + ": " + fmt(val(p, s, "decoy-seconds", lv, 10.0)) + "초 (순간이동하거나 새로 만들면 사라짐)");
        return true;
    }

    /** 미끼: 주변 적(보스 제외)이 플레이어보다 분신이 더 가까우면 분신을 노린다. */
    private void decoyTick(Summon sm, Player o) {
        LivingEntity e = sm.ent;
        double r = Math.max(4.0, sm.radius);
        for (Entity en : e.getNearbyEntities(r, r / 2.0, r)) {
            if (!(en instanceof Mob h) || isSummonEntity(h) || !(h instanceof org.bukkit.entity.Enemy) || isBossLike(h)) continue;
            LivingEntity t = h.getTarget();
            if (t != null && !(t instanceof Player) && !t.equals(e)) continue;
            if (t instanceof Player && h.getLocation().distanceSquared(t.getLocation()) < h.getLocation().distanceSquared(e.getLocation())) continue;
            h.setTarget(e);
        }
        dust(e.getWorld(), e.getLocation().getX(), e.getLocation().getY() + 2.3, e.getLocation().getZ(), 0xB0B0FF, 1.0f);
    }

    private boolean doValkyrie(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final UUID id = p.getUniqueId();
        List<Summon> old = ownedSummons(id, "valk");
        if (!summonRoomFor(p, old.size())) return false;
        for (Summon o : old) removeSummon(o, true); // 하나만 유지
        final Location at = summonSpot(p, val(p, s, "range", lv, 20.0), forced);
        final double hp = val(p, s, "hp", lv, 150.0);
        final double dmg = val(p, s, "damage", lv, 6.0);
        org.bukkit.entity.Zombie z = at.getWorld().spawn(at, org.bukkit.entity.Zombie.class);
        z.setBaby(false);
        setupSummon(z, ChatColor.GOLD + "발키리", hp, dmg);
        String tier = lv >= 20 ? "NETHERITE" : lv >= 10 ? "DIAMOND" : "IRON";
        org.bukkit.inventory.EntityEquipment eq = z.getEquipment();
        if (eq != null) {
            eq.setHelmet(unbr(Material.GOLDEN_HELMET));
            eq.setChestplate(unbr(Material.valueOf(tier + "_CHESTPLATE")));
            eq.setLeggings(unbr(Material.valueOf(tier + "_LEGGINGS")));
            eq.setBoots(unbr(Material.valueOf(tier + "_BOOTS")));
            eq.setItemInMainHand(new ItemStack(Material.LIGHTNING_ROD)); // 창 모양 (무기 공격력 보정이 없는 아이템)
            eq.setItemInOffHand(new ItemStack(Material.AIR));
            eq.setHelmetDropChance(0f);
            eq.setChestplateDropChance(0f);
            eq.setLeggingsDropChance(0f);
            eq.setBootsDropChance(0f);
            eq.setItemInMainHandDropChance(0f);
        }
        Summon sm = new Summon();
        sm.owner = id;
        sm.ent = z;
        sm.type = "valk";
        sm.dmg = dmg;
        sm.resist = Math.min(85.0, val(p, s, "resist-pct", lv, 0.0));
        sm.until = 0L;
        summons.put(z.getUniqueId(), sm);
        at.getWorld().spawnParticle(Particle.END_ROD, at.clone().add(0, 1.0, 0), 30, 0.3, 0.8, 0.3, 0.05);
        at.getWorld().playSound(at, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 0.8f, 1.4f);
        msg(p, ChatColor.GOLD + s.name + ": 생명력 " + fmt(hp) + ", 공격력 " + fmt(dmg) + ", 모든 저항 " + fmt(sm.resist) + "%");
        return true;
    }

    private void describeAmzSummon(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        if (c.contains("decoy-seconds")) out.add(ChatColor.GRAY + "지속 " + fmt(val(p, s, "decoy-seconds", lv, 0)) + "초, 주변 " + fmt(val(p, s, "aggro-radius", lv, 0)) + "칸의 적(보스 제외)을 유인");
        if (c.contains("decoy-seconds")) out.add(ChatColor.GRAY + "움직이거나 공격하지 못함. 새로 만들거나 순간이동하면 사라짐");
        if (c.contains("resist-pct")) out.add(ChatColor.AQUA + "받는 피해 감소 " + fmt(Math.min(85.0, val(p, s, "resist-pct", lv, 0))) + "% (하나만 유지, 흘리기/회피/피하기 적용)");
    }


    // ===================================================================
    //  0.23.0: 어새신 덫 + 그림자 단련  [미검증]
    //   덫(센트리)은 입자로만 그리는 설치물 (히드라와 같은 방식). 종류 무관하게 플레이어당 최대 trap.max 개.
    //   표창 계열 물리 피해는 pureHit (무기 공격력의 75%를 더한다).
    // ===================================================================

    private boolean isClaw(ItemStack it) {
        return it != null && it.getType().name().endsWith("_HOE"); // 손톱 = 괭이 (임시 규칙)
    }

    private final Map<UUID, java.util.ArrayDeque<BukkitTask>> traps = new HashMap<>();
    private int trapZones;

    /** 덫 하나를 시작한다. body 는 호출마다 진행 번호를 받고, true 를 돌려주면 끝. */
    private void startTrap(Player p, long delay, long period, java.util.function.IntPredicate body) {
        final int cap = Math.max(1, plugin.getConfig().getInt("trap.max", 5));
        final java.util.ArrayDeque<BukkitTask> dq = traps.computeIfAbsent(p.getUniqueId(), k -> new java.util.ArrayDeque<>());
        while (dq.size() >= cap) {
            BukkitTask old = dq.pollFirst();
            if (old != null) old.cancel(); // 가장 오래된 덫부터 사라진다
        }
        final BukkitTask[] ref = new BukkitTask[1];
        final int[] n = {0};
        ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            boolean done;
            try {
                done = !p.isOnline() || body.test(n[0]++);
            } catch (Exception ex) {
                done = true;
            }
            if (done) {
                ref[0].cancel();
                dq.remove(ref[0]);
            }
        }, delay, period);
        dq.addLast(ref[0]);
    }

    private double bladeBase(Player p) {
        AttributeInstance a = p.getAttribute(VersionCompat.ATTACK_DAMAGE);
        return a == null ? 0.0 : a.getValue() * 0.75;
    }

    private LivingEntity nearestTo(Location c, double r, Player p) {
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity o : around(c, r, p)) {
            double d = o.getLocation().distanceSquared(c);
            if (d < bd) {
                bd = d;
                best = o;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- shockweb (감전 그물)

    private boolean doShockWeb(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final Location c = groundTarget(p, val(p, s, "range", lv, 24.0), forced);
        if (c == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 땅을 바라보고 쓰세요.");
            return false;
        }
        final int cap = Math.max(1, plugin.getConfig().getInt("trap.max-zones", 20));
        if (trapZones >= cap) {
            if (!quiet) msg(p, ChatColor.GRAY + "지금은 그물을 더 만들 수 없습니다. (동시 한도)");
            return false;
        }
        trapZones++;
        final int spikes = Math.max(1, (int) val(p, s, "spikes", lv, 5.0));
        final double radius = val(p, s, "radius", lv, 6.0);
        final double dmg = val(p, s, "elem-damage", lv, 8.0);
        final int pulses = Math.max(1, (int) val(p, s, "web-seconds", lv, 8.0));
        final World w = c.getWorld();
        final List<Location> pts = new ArrayList<>();
        for (int i = 0; i < spikes; i++) {
            double a = random.nextDouble() * Math.PI * 2;
            double r = Math.sqrt(random.nextDouble()) * radius;
            pts.add(c.clone().add(Math.cos(a) * r, 0.0, Math.sin(a) * r));
        }
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (n++ >= pulses || !p.isOnline()) {
                    trapZones = Math.max(0, trapZones - 1);
                    cancel();
                    return;
                }
                Set<UUID> hit = new HashSet<>();
                for (Location l : pts) {
                    w.spawnParticle(Particle.ELECTRIC_SPARK, l.getX(), l.getY() + 0.6, l.getZ(), 6, 0.15, 0.4, 0.15, 0.05);
                    dust(w, l.getX(), l.getY() + 0.2, l.getZ(), 0xFFF060, 1.2f);
                    for (LivingEntity o : around(l, 1.5, p)) {
                        if (hit.add(o.getUniqueId())) elemHit(p, o, "lightning", dmg);
                    }
                }
            }
        }.runTaskTimer(plugin, 5L, 20L);
        w.playSound(c, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.5f, 2.0f);
        return true;
    }

    // ---------------------------------------------------------------- bladesent (파수꾼의 칼날)

    private boolean doBladeSentinel(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final double range = val(p, s, "range", lv, 20.0);
        final World w = p.getWorld();
        final Location from = p.getLocation().add(0, 1.0, 0);
        Vector dir;
        double dist = range;
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        if (t != null) {
            dir = aimPoint(t).subtract(from.toVector());
            dist = Math.min(range, dir.length());
        } else {
            dir = p.getEyeLocation().getDirection();
        }
        dir.setY(dir.getY() * 0.3);
        if (dir.lengthSquared() < 0.0001) return false;
        final Vector d = dir.normalize();
        final double total = Math.max(4.0, dist);
        final double dmg = val(p, s, "damage", lv, 10.0) + bladeBase(p);
        final Map<UUID, Integer> last = new HashMap<>();
        final int passes = Math.max(2, (int) val(p, s, "passes", lv, 6.0)); // 한 방향을 1회로 센다 (6 = 세 번 왕복)
        startTrap(p, 0L, 1L, i -> {
            double travel = i * 0.6;
            if (travel >= total * passes) return true;
            double m = travel % (total * 2.0);
            double pos = m <= total ? m : total * 2.0 - m;
            Location l = from.clone().add(d.clone().multiply(pos));
            dust(w, l.getX(), l.getY(), l.getZ(), 0xC8C8D8, 1.6f);
            if (i % 3 == 0) w.spawnParticle(Particle.CRIT, l, 2, 0.1, 0.1, 0.1, 0.0);
            for (LivingEntity o : around(l, 1.4, p)) {
                Integer lh = last.get(o.getUniqueId());
                if (lh != null && i - lh < 20) continue; // 같은 적은 1초에 한 번
                last.put(o.getUniqueId(), i);
                pureHit(p, o, dmg);
            }
            return false;
        });
        w.playSound(from, Sound.ITEM_TRIDENT_THROW, 0.7f, 1.4f);
        return true;
    }

    // ---------------------------------------------------------------- bladefury (분노의 칼날)

    private final Map<UUID, Long> furyUntil = new HashMap<>();

    private boolean doBladeFury(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final long now = System.currentTimeMillis();
        Long fu = furyUntil.get(p.getUniqueId());
        if (fu != null && fu > now) return false; // 우클릭을 꾹 눌러도 쓰는 동안엔 다시 나가지 않는다
        final double secs = val(p, s, "fury-seconds", lv, 2.0);
        AttributeInstance ad = p.getAttribute(VersionCompat.ATTACK_DAMAGE);
        final double dmg = (ad == null ? 0.0 : ad.getValue()) * val(p, s, "weapon-pct", lv, 75.0) / 100.0;
        final int shots = Math.max(2, (int) (secs * 20.0 / 3.0));
        furyUntil.put(p.getUniqueId(), now + (long) (secs * 1000.0) + 150L);
        final World w = p.getWorld();
        final int[] n = {0};
        final BukkitTask[] ref = new BukkitTask[1];
        ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (n[0]++ >= shots || p.isDead() || !p.isOnline()) {
                furyUntil.remove(p.getUniqueId());
                ref[0].cancel();
                return;
            }
            Location eye = p.getEyeLocation();
            Vector v = eye.getDirection().clone();
            v.rotateAroundY((random.nextDouble() - 0.5) * 0.22);
            v.setY(v.getY() + (random.nextDouble() - 0.5) * 0.06);
            flyMissile(p, eye.clone().add(0, -0.3, 0), v.normalize(), 1.6, 22.0, false, false, null, Particle.CRIT, null,
                    le -> pureHit(p, le, dmg));
            if (n[0] % 2 == 1) w.playSound(eye, Sound.ITEM_TRIDENT_THROW, 0.4f, 1.8f);
        }, 0L, 3L);
        return true;
    }

    // ---------------------------------------------------------------- bladeshield (칼날 방패)

    private final Map<UUID, BukkitTask> bladeShields = new HashMap<>();

    private boolean doBladeShield(Player p, SkillDef s, int lv) {
        BukkitTask old = bladeShields.remove(p.getUniqueId());
        if (old != null) old.cancel();
        final double secs = val(p, s, "shield-seconds", lv, 20.0);
        final double dmg = val(p, s, "damage", lv, 6.0) + bladeBase(p);
        final double rad = val(p, s, "shield-radius", lv, 2.6);
        final long end = System.currentTimeMillis() + (long) (secs * 1000.0);
        final int[] n = {0};
        final BukkitTask[] ref = new BukkitTask[1];
        ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || p.isDead() || System.currentTimeMillis() > end) {
                ref[0].cancel();
                bladeShields.remove(p.getUniqueId());
                return;
            }
            n[0]++;
            World w = p.getWorld();
            Location c = p.getLocation();
            for (int i = 0; i < 4; i++) {
                double a = n[0] * 0.5 + Math.PI * 2 * i / 4.0;
                dust(w, c.getX() + Math.cos(a) * 1.5, c.getY() + 1.0, c.getZ() + Math.sin(a) * 1.5, 0xC8C8D8, 1.4f);
            }
            if (n[0] % 5 == 0) for (LivingEntity o : around(c, rad, p)) pureHit(p, o, dmg);
        }, 0L, 4L);
        bladeShields.put(p.getUniqueId(), ref[0]);
        msg(p, ChatColor.GRAY + s.name + ": " + fmt(secs) + "초");
        return true;
    }

    // ---------------------------------------------------------------- sentry (덫: 번개줄기 / 불의 파동 / 번개 / 지옥불 / 죽음)

    private boolean doSentry(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final Location at = summonSpot(p, val(p, s, "range", lv, 14.0), forced);
        final String type = s.sec.getString("sentry-type", "bolt");
        final int shots = Math.max(1, (int) val(p, s, "shots", lv, 10.0));
        final double dmg = val(p, s, "elem-damage", lv, 10.0);
        final double sight = val(p, s, "sight", lv, 14.0);
        final double waveLen = val(p, s, "wave-length", lv, 7.0);
        final long period = Math.max(3L, (long) (val(p, s, "interval-seconds", lv, 1.0) * 20.0));
        final boolean fire = type.equals("wave") || type.equals("inferno");
        final String el = fire ? "fire" : "lightning";
        final int rgb = fire ? 0xE05020 : 0xFFF060;
        final World w = at.getWorld();
        final int[] fired = {0};
        startTrap(p, 20L, period, i -> {
            // 몸체 (작은 기둥)
            for (double y = 0.1; y < 1.1; y += 0.3) dust(w, at.getX(), at.getY() + y, at.getZ(), fire ? 0x803010 : 0x707080, 1.4f);
            dust(w, at.getX(), at.getY() + 1.2, at.getZ(), rgb, 1.8f);
            if (fired[0] >= shots) {
                w.spawnParticle(Particle.LARGE_SMOKE, at.clone().add(0, 0.8, 0), 10, 0.2, 0.3, 0.2, 0.02);
                return true;
            }
            final Location muzzle = at.clone().add(0, 1.2, 0);
            if (type.equals("death")) {
                Corpse best = null;
                double bd = Double.MAX_VALUE;
                for (Corpse c : new ArrayList<>(corpses)) {
                    if (c.world != w) continue;
                    double d = c.loc.distanceSquared(at);
                    if (c.until >= System.currentTimeMillis() && d < sight * sight && d < bd) {
                        bd = d;
                        best = c;
                    }
                }
                if (best != null) { // 시체가 있으면 먼저 시체 폭발
                    corpses.remove(best);
                    fired[0]++;
                    double cr = val(p, s, "corpse-radius", lv, 4.0);
                    double cd = best.maxHealth * val(p, s, "corpse-hp-pct", lv, 60.0) / 100.0;
                    for (LivingEntity t : around(best.loc, cr, p)) pureHit(p, t, cd);
                    w.spawnParticle(Particle.EXPLOSION, best.loc.clone().add(0, 0.5, 0), 3, cr * 0.3, 0.3, cr * 0.3, 0.0);
                    w.playSound(best.loc, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.1f);
                    return false;
                }
            }
            LivingEntity t = nearestTo(at, sight, p);
            if (t == null) return false;
            fired[0]++;
            Vector to = aimPoint(t).subtract(muzzle.toVector());
            if (to.lengthSquared() < 0.01) return false;
            final Vector dir = to.normalize();
            switch (type) {
                case "bolt", "death" -> flyMissile(p, muzzle.clone(), dir, 1.2, sight + 4.0, false, true, t, Particle.ELECTRIC_SPARK, null,
                        le -> elemHit(p, le, "lightning", dmg));
                case "beam" -> {
                    flyMissile(p, muzzle.clone(), dir, 2.2, sight + 6.0, true, false, null, Particle.ELECTRIC_SPARK, new HashSet<>(),
                            le -> elemHit(p, le, "lightning", dmg));
                    w.playSound(muzzle, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.3f, 2.0f);
                }
                default -> { // wave / inferno: 적 쪽으로 V자 불길
                    for (double k = 1.0; k <= waveLen; k += 0.7) {
                        Location l = muzzle.clone().add(dir.clone().multiply(k));
                        w.spawnParticle(Particle.FLAME, l, 3, 0.12 * k, 0.1 * k, 0.12 * k, 0.01);
                    }
                    for (LivingEntity o : around(at, waveLen + 1.0, p)) {
                        Vector tv = aimPoint(o).subtract(muzzle.toVector());
                        double len = tv.length();
                        if (len > waveLen + 0.5 || len < 0.3) continue;
                        if (tv.normalize().dot(dir) < 0.6) continue;
                        elemHit(p, o, "fire", dmg);
                    }
                    w.playSound(muzzle, Sound.ITEM_FIRECHARGE_USE, 0.6f, 1.2f);
                }
            }
            return false;
        });
        w.spawnParticle(Particle.CLOUD, at.clone().add(0, 0.4, 0), 8, 0.2, 0.2, 0.2, 0.02);
        w.playSound(at, Sound.BLOCK_ANVIL_PLACE, 0.5f, 1.6f);
        return true;
    }

    // ---------------------------------------------------------------- 그림자 단련

    private final Map<UUID, Long> cloakUntil = new HashMap<>();

    private boolean doCloak(Player p, SkillDef s, int lv) {
        long now = System.currentTimeMillis();
        Long cu = cloakUntil.get(p.getUniqueId());
        if (cu != null && cu > now) {
            msg(p, ChatColor.GRAY + s.name + ": 지속 중에는 다시 쓸 수 없습니다.");
            return false;
        }
        double dur = scaled(s.sec.getConfigurationSection("curse"), "duration", lv, 8.0);
        cloakUntil.put(p.getUniqueId(), now + (long) (dur * 1000.0));
        final double radius = radius(p, s, lv, 12.0);
        for (LivingEntity t : around(p.getLocation(), radius, p)) applyCurse(t, s, lv);
        World w = p.getWorld();
        Location c = p.getLocation();
        for (int i = 0; i < 40; i++) {
            double a = Math.PI * 2 * i / 40.0;
            dust(w, c.getX() + Math.cos(a) * Math.min(radius, 10.0), c.getY() + 0.3, c.getZ() + Math.sin(a) * Math.min(radius, 10.0), 0x302040, 1.8f);
        }
        w.playSound(c, Sound.ENTITY_ENDERMAN_AMBIENT, 0.8f, 0.6f);
        return true;
    }

    private boolean doPsychic(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        LivingEntity t = forced != null ? forced : findTarget(p, val(p, s, "range", lv, 12.0));
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + "대상이 없습니다.");
            return false;
        }
        pureHit(p, t, val(p, s, "damage", lv, 8.0));
        if (!isBossLike(t)) {
            Vector away = t.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
            if (away.lengthSquared() < 0.01) away = p.getEyeLocation().getDirection().setY(0);
            t.setVelocity(away.normalize().multiply(1.4).setY(0.4));
        }
        t.getWorld().spawnParticle(Particle.WITCH, t.getLocation().add(0, 1.0, 0), 20, 0.3, 0.5, 0.3, 0.05);
        t.getWorld().playSound(t.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 0.8f, 0.8f);
        return true;
    }

    private boolean doMindBlast(Player p, SkillDef s, int lv) {
        final double radius = radius(p, s, lv, 8.0);
        final double dmg = val(p, s, "damage", lv, 5.0);
        final double stun = val(p, s, "stun-seconds", lv, 1.5);
        final double chance = Math.min(40.0, val(p, s, "convert-chance", lv, 10.0));
        final double csec = val(p, s, "convert-seconds", lv, 8.0);
        for (LivingEntity t : around(p.getLocation(), radius, p)) {
            pureHit(p, t, dmg);
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (stun * 20.0), 7, false, true));
            if (t instanceof Mob m && !isBossLike(t) && !t.isDead() && random.nextDouble() * 100.0 < chance) startConvert(m, csec);
        }
        final World w = p.getWorld();
        final Location c = p.getLocation();
        new BukkitRunnable() {
            int step = 0;

            @Override
            public void run() {
                step++;
                double r = Math.min(radius, 12.0) * step / 4.0;
                for (int i = 0; i < 24; i++) {
                    double a = Math.PI * 2 * i / 24.0;
                    dust(w, c.getX() + Math.cos(a) * r, c.getY() + 0.4, c.getZ() + Math.sin(a) * r, 0xA050E0, 1.3f);
                }
                if (step >= 4) cancel();
            }
        }.runTaskTimer(plugin, 0L, 2L);
        w.playSound(c, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.4f, 1.6f);
        return true;
    }

    /** 손톱 숙련 / 무기 막기. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onClawMastery(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player a) || spellFlag || pure) return;
        if (!isClaw(a.getInventory().getItemInMainHand())) return;
        double pct = passiveSum(a, "claw-dmg-pct");
        if (pct > 0) e.setDamage(e.getDamage() * (1.0 + pct / 100.0));
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onWeaponBlock(EntityDamageByEntityEvent e) {
        if (!enabled() || !(e.getEntity() instanceof Player v)) return;
        if (!isClaw(v.getInventory().getItemInMainHand()) || !isClaw(v.getInventory().getItemInOffHand())) return;
        Entity dm = e.getDamager();
        if (!(dm instanceof Projectile) && !(dm instanceof LivingEntity)) return;
        double ch = Math.min(65.0, passiveSum(v, "weapon-block-pct"));
        if (ch <= 0 || random.nextDouble() * 100.0 >= ch) return;
        e.setCancelled(true);
        v.getWorld().playSound(v.getLocation(), Sound.ITEM_SHIELD_BLOCK, 0.8f, 1.4f);
        v.getWorld().spawnParticle(Particle.CRIT, v.getLocation().add(0, 1.2, 0), 8, 0.3, 0.3, 0.3, 0.1);
    }

    // ---------------------------------------------------------------- shadow (그림자 전사 / 그림자 달인)

    private static final Set<String> SHADOW_KINDS = Set.of("missile", "nova", "chain", "inferno", "firewall", "blizzard", "meteor", "orb", "static", "storm");

    private boolean doShadow(Player p, SkillDef s, int lv) {
        final UUID id = p.getUniqueId();
        List<Summon> old = ownedSummons(id, "shadow");
        if (!summonRoomFor(p, old.size())) return false;
        for (Summon o : old) removeSummon(o, true); // 그림자는 하나만
        final boolean master = s.sec.getBoolean("master", false);
        final Location at = p.getLocation().add(1.5, 0.1, 0.0);
        final double hp = val(p, s, "hp", lv, 100.0);
        final double dmg = val(p, s, "damage", lv, 6.0);
        org.bukkit.entity.Zombie z = at.getWorld().spawn(at, org.bukkit.entity.Zombie.class);
        z.setBaby(false);
        setupSummon(z, ChatColor.DARK_GRAY + p.getName() + (master ? " 그림자 달인" : " 그림자 전사"), hp, dmg);
        org.bukkit.inventory.EntityEquipment eq = z.getEquipment();
        if (eq != null) {
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            org.bukkit.inventory.meta.SkullMeta sk = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta();
            if (sk != null) {
                sk.setOwningPlayer(p);
                head.setItemMeta(sk);
            }
            eq.setHelmet(head);
            org.bukkit.inventory.PlayerInventory pi = p.getInventory();
            if (pi.getChestplate() != null) eq.setChestplate(pi.getChestplate().clone());
            if (pi.getLeggings() != null) eq.setLeggings(pi.getLeggings().clone());
            if (pi.getBoots() != null) eq.setBoots(pi.getBoots().clone());
            eq.setItemInMainHand(new ItemStack(Material.AIR));
            eq.setHelmetDropChance(0f);
            eq.setChestplateDropChance(0f);
            eq.setLeggingsDropChance(0f);
            eq.setBootsDropChance(0f);
        }
        Summon sm = new Summon();
        sm.owner = id;
        sm.ent = z;
        sm.type = "shadow";
        sm.dmg = dmg;
        sm.master = master;
        sm.castLv = lv;
        sm.resist = Math.min(75.0, val(p, s, "resist-pct", lv, 40.0));
        sm.until = System.currentTimeMillis() + (long) (val(p, s, "shadow-seconds", lv, 40.0) * 1000.0);
        summons.put(z.getUniqueId(), sm);
        at.getWorld().spawnParticle(Particle.LARGE_SMOKE, at.clone().add(0, 1.0, 0), 25, 0.3, 0.6, 0.3, 0.03);
        at.getWorld().playSound(at, Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 0.7f);
        msg(p, ChatColor.DARK_GRAY + s.name + ": " + fmt(val(p, s, "shadow-seconds", lv, 40.0)) + "초, 생명력 " + fmt(hp) + ", 공격력 " + fmt(dmg));
        return true;
    }

    /** 그림자가 일정 간격으로 주인이 배운 공격 스킬 하나를 (주인 위치에서) 시전한다. */
    private void shadowCast(Summon sm, Player o, LivingEntity enemy, long now) {
        long gap = (long) (plugin.getConfig().getDouble("shadow.cast-interval-sec", 4.0) * 1000.0);
        if (now - sm.lastCast < gap) return;
        if (sm.ent.getWorld() != enemy.getWorld() || sm.ent.getLocation().distanceSquared(enemy.getLocation()) > 18.0 * 18.0) return;
        PData d = data(o);
        List<SkillDef> pool = new ArrayList<>();
        for (SkillDef s : skills.values()) {
            if (SHADOW_KINDS.contains(s.kind) && level(o, d, s) > 0) pool.add(s);
        }
        if (pool.isEmpty()) return;
        SkillDef s = pool.get(random.nextInt(pool.size()));
        int lv = level(o, d, s);
        if (sm.master) lv = Math.max(1, (int) (lv / 2.0 + sm.castLv / 3.0)); // (내 스킬 레벨/2) + (달인 레벨/3)
        sm.lastCast = now;
        try {
            execute(o, s, lv, enemy, true);
        } catch (Exception ex) {
            plugin.getLogger().warning("그림자 시전 실패(" + s.id + "): " + ex.getMessage());
        }
    }

    private void describeAssassin(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        if (c.contains("spikes")) out.add(ChatColor.YELLOW + "쐐기 " + (int) val(p, s, "spikes", lv, 0) + "개, " + fmt(val(p, s, "web-seconds", lv, 0)) + "초 동안 1초마다 피해");
        if (c.contains("sentry-type")) {
            out.add(ChatColor.GRAY + "덫 설치 (종류 무관 최대 " + plugin.getConfig().getInt("trap.max", 5) + "개, 넘으면 오래된 것부터 사라짐)");
            out.add(ChatColor.GRAY + "발사 " + (int) val(p, s, "shots", lv, 0) + "회 후 사라짐");
        }
        if (c.contains("passes")) out.add(ChatColor.GRAY + "표창이 " + (int) val(p, s, "passes", lv, 6) + "번 오가며 적을 관통 (같은 적은 1초에 한 번)");
        if (c.contains("fury-seconds")) out.add(ChatColor.GRAY + fmt(val(p, s, "fury-seconds", lv, 0)) + "초 동안 앞으로 표창 연사 (표창 하나당 무기 공격력의 " + fmt(val(p, s, "weapon-pct", lv, 75)) + "%)");
        if (c.contains("shield-seconds")) out.add(ChatColor.GRAY + fmt(val(p, s, "shield-seconds", lv, 0)) + "초 동안 주변 적에게 1초마다 물리 피해");
        if (c.contains("stun-seconds")) out.add(ChatColor.LIGHT_PURPLE + "기절 " + fmt(val(p, s, "stun-seconds", lv, 0)) + "초, 전향 확률 " + fmt(Math.min(40.0, val(p, s, "convert-chance", lv, 0))) + "% (보스 제외)");
        if (c.contains("shadow-seconds")) out.add(ChatColor.DARK_GRAY + "지속 " + fmt(val(p, s, "shadow-seconds", lv, 0)) + "초, 물리 피해 감소 " + fmt(Math.min(75.0, val(p, s, "resist-pct", lv, 0))) + "%, 내 공격 스킬을 따라 씀 (하나만)");
        if (c.contains("claw-dmg-pct")) out.add(ChatColor.AQUA + "손톱(괭이) 공격력 +" + fmt(val(p, s, "claw-dmg-pct", lv, 0)) + "%");
        if (c.contains("weapon-block-pct")) out.add(ChatColor.AQUA + "양손에 손톱(괭이) 장비 시 막기 " + fmt(Math.min(65.0, val(p, s, "weapon-block-pct", lv, 0))) + "%");
    }


    // ===================================================================
    //  0.24.0: 어새신 무술 (충전 / 필살기)  [미검증]
    //   충전 기술(호랑이 일격 등)은 한 번 때리고 충전을 쌓는다 (최대 3단계, 15초).
    //   필살기(발차기/용의 손톱/용의 비상)나 일반 공격으로 때리면 충전이 한 단계씩 소모되며 효과가 붙는다.
    // ===================================================================

    private final Map<UUID, Map<String, long[]>> charges = new HashMap<>(); // 종류 -> {개수, 끝나는 시각}

    private void addCharge(Player p, SkillDef s, int n) {
        long secs = plugin.getConfig().getLong("martial.charge-seconds", 15L);
        Map<String, long[]> m = charges.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashMap<>());
        long now = System.currentTimeMillis();
        long[] c = m.get(s.id);
        if (c == null || c[1] < now) c = new long[]{0L, 0L};
        c[0] = Math.min(3L, c[0] + n);
        c[1] = now + secs * 1000L;
        m.put(s.id, c);
        p.getWorld().spawnParticle(Particle.ENCHANT, p.getLocation().add(0, 1.0, 0), 12 + (int) c[0] * 6, 0.4, 0.7, 0.4, 0.5);
        msg(p, ChatColor.GOLD + s.name + ChatColor.GRAY + " 충전 " + c[0] + "/3 (" + secs + "초)");
    }

    /** 활성 충전을 한 단계씩 소모하고, 소모 직전 단계를 돌려준다. */
    private Map<String, Integer> takeCharges(Player p) {
        Map<String, long[]> m = charges.get(p.getUniqueId());
        if (m == null || m.isEmpty()) return Map.of();
        long now = System.currentTimeMillis();
        Map<String, Integer> snap = new LinkedHashMap<>();
        for (java.util.Iterator<Map.Entry<String, long[]>> it = m.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<String, long[]> en = it.next();
            long[] c = en.getValue();
            if (c[1] < now || c[0] <= 0) {
                it.remove();
                continue;
            }
            snap.put(en.getKey(), (int) Math.min(3L, c[0]));
            c[0]--;
            if (c[0] <= 0) it.remove();
        }
        return snap;
    }

    private double tigerMult(Player p, Map<String, Integer> snap) {
        Integer n = snap.get("tiger_strike");
        SkillDef def = skills.get("tiger_strike");
        if (n == null || def == null) return 1.0;
        int lv = level(p, data(p), def);
        if (lv <= 0) return 1.0;
        return 1.0 + val(p, def, "dmg-pct", lv, 0.0) * n / 100.0;
    }

    private void chainBolts(Player p, LivingEntity start, double dmg, int bounces) {
        Set<UUID> done = new HashSet<>();
        LivingEntity cur = start;
        Location from = aimPoint(start).toLocation(start.getWorld());
        for (int i = 0; i < bounces; i++) {
            LivingEntity next = null;
            double bd = Double.MAX_VALUE;
            for (LivingEntity o : around(cur.getLocation(), 6.0, p)) {
                if (o == start || done.contains(o.getUniqueId())) continue;
                double dd = o.getLocation().distanceSquared(cur.getLocation());
                if (dd < bd) {
                    bd = dd;
                    next = o;
                }
            }
            if (next == null) break;
            done.add(next.getUniqueId());
            Location to = aimPoint(next).toLocation(next.getWorld());
            sparkLine(from, to);
            elemHit(p, next, "lightning", dmg);
            from = to;
            cur = next;
        }
    }

    private void dropMeteor(Player p, Location c, double dmg, double radius, double zdmg, double zsec) {
        final World w = c.getWorld();
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                n++;
                double left = Math.max(0.0, 1.0 - n / 10.0);
                Location m = c.clone().add(left * 6.0, left * 16.0, left * 3.0);
                w.spawnParticle(Particle.FLAME, m, 10, 0.3, 0.3, 0.3, 0.03);
                if (n >= 10) {
                    cancel();
                    for (LivingEntity o : around(c, radius, p)) elemHit(p, o, "fire", dmg);
                    w.spawnParticle(Particle.EXPLOSION, c.clone().add(0, 0.5, 0), 3, radius * 0.3, 0.3, radius * 0.3, 0.0);
                    w.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 0.9f, 0.8f);
                    fireZone(p, c, radius * 0.9, zsec, zdmg);
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    /** 충전 효과 (원소 피해/폭발/훔침 등). snap = 소모 직전 충전 단계. */
    private void applyChargeEffects(Player p, LivingEntity t, Map<String, Integer> snap, double dealt) {
        PData d = data(p);
        for (Map.Entry<String, Integer> en : snap.entrySet()) {
            SkillDef def = skills.get(en.getKey());
            if (def == null) continue;
            int lv = level(p, d, def);
            if (lv <= 0) continue;
            int n = Math.min(3, en.getValue());
            Location tl = t.getLocation();
            World w = t.getWorld();
            switch (en.getKey()) {
                case "cobra_strike" -> {
                    healAlly(p, dealt * val(p, def, "leech-life-pct", lv, 0.0) * n / 100.0);
                    StatSystem ss = plugin.statSystem();
                    double max = ss.maxMana(ss.collect(p));
                    ss.setMana(p, Math.min(max, ss.getMana(p) + dealt * val(p, def, "leech-mana-pct", lv, 0.0) * n / 100.0));
                    w.spawnParticle(Particle.HAPPY_VILLAGER, p.getLocation().add(0, 1.2, 0), 4, 0.3, 0.4, 0.3, 0.0);
                }
                case "fists_of_fire" -> {
                    double e = val(p, def, "elem-damage", lv, 0.0);
                    elemHit(p, t, "fire", e);
                    w.spawnParticle(Particle.FLAME, tl.clone().add(0, 1.0, 0), 10, 0.3, 0.4, 0.3, 0.03);
                    if (n >= 2) {
                        for (LivingEntity o : around(tl, val(p, def, "explosion-radius", lv, 2.5), p)) if (o != t) elemHit(p, o, "fire", e * 0.6);
                        w.spawnParticle(Particle.EXPLOSION, tl.clone().add(0, 0.8, 0), 1);
                    }
                    if (n >= 3) fireZone(p, tl, 2.0, 3.0, val(p, def, "zone-damage", lv, 0.0));
                }
                case "claws_of_thunder" -> {
                    double e = val(p, def, "elem-damage", lv, 0.0);
                    elemHit(p, t, "lightning", e);
                    w.spawnParticle(Particle.ELECTRIC_SPARK, tl.clone().add(0, 1.0, 0), 12, 0.3, 0.4, 0.3, 0.05);
                    if (n >= 2) for (LivingEntity o : around(tl, val(p, def, "nova-radius", lv, 4.0), p)) if (o != t) elemHit(p, o, "lightning", e * 0.6);
                    if (n >= 3) chainBolts(p, t, e * 0.8, 3);
                }
                case "blades_of_ice" -> {
                    double e = val(p, def, "elem-damage", lv, 0.0);
                    elemHit(p, t, "cold", e);
                    w.spawnParticle(Particle.SNOWFLAKE, tl.clone().add(0, 1.0, 0), 12, 0.3, 0.4, 0.3, 0.03);
                    if (n >= 2) for (LivingEntity o : around(tl, val(p, def, "explosion-radius", lv, 2.5), p)) if (o != t) elemHit(p, o, "cold", e * 0.6);
                    if (n >= 3) freezeMob(t, val(p, def, "freeze-seconds", lv, 1.5));
                }
                case "phoenix_strike" -> {
                    if (n == 1) {
                        dropMeteor(p, tl.clone(), val(p, def, "meteor-damage", lv, 30.0), val(p, def, "meteor-radius", lv, 3.5),
                                val(p, def, "zone-damage", lv, 5.0), val(p, def, "zone-seconds", lv, 4.0));
                    } else if (n == 2) {
                        double cd = val(p, def, "chain-damage", lv, 20.0);
                        elemHit(p, t, "lightning", cd);
                        chainBolts(p, t, cd, Math.max(1, (int) val(p, def, "chain-bounces", lv, 4.0)));
                    } else {
                        final double idmg = val(p, def, "ice-damage", lv, 12.0);
                        Location from = aimPoint(t).toLocation(w);
                        for (int i = 0; i < 8; i++) {
                            double a = Math.PI * 2 * i / 8.0;
                            missileScale = 1.0; // 얼음 보주급으로 크게
                            flyMissile(p, from.clone(), new Vector(Math.cos(a), 0.0, Math.sin(a)), 1.0, 12.0, false, false, null, Particle.SNOWFLAKE, null,
                                    le -> {
                                        elemHit(p, le, "cold", idmg);
                                        freezeMob(le, 2.0);
                                    });
                        }
                    }
                }
                default -> { }
            }
        }
    }

    /** 필살기 한 번 타격: 충전을 한 단계 소모하며 호랑이 일격 배수와 충전 효과를 붙인다. */
    private void chargedHit(Player p, LivingEntity t, double base) {
        Map<String, Integer> snap = takeCharges(p);
        double before = t.getHealth();
        hit(p, t, base * tigerMult(p, snap));
        if (!snap.isEmpty()) applyChargeEffects(p, t, snap, Math.max(0.0, before - t.getHealth()));
    }

    /** 충전 상태로 일반 공격을 하면 충전이 소모되며 효과가 붙는다. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChargeRelease(EntityDamageByEntityEvent e) {
        if (casting || pure || spellFlag || charges.isEmpty()) return;
        if (!(e.getDamager() instanceof Player a)) return;
        if (!(e.getEntity() instanceof LivingEntity t) || t instanceof Player || isSummonEntity(t)) return;
        Map<String, Integer> snap = takeCharges(a);
        if (snap.isEmpty()) return;
        e.setDamage(e.getDamage() * tigerMult(a, snap));
        final double dealt = e.getFinalDamage();
        Bukkit.getScheduler().runTask(plugin, () -> applyChargeEffects(a, t, snap, dealt));
    }

    private boolean doMCharge(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        boolean needClaw = s.sec.getBoolean("requires-claw", false);
        if (needClaw && !isClaw(p.getInventory().getItemInMainHand())) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": 손톱(괭이)을 들어야 합니다.");
            return false;
        }
        LivingEntity t = forced != null ? forced : findTarget(p, val(p, s, "range", lv, 4.5));
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + "대상이 없습니다.");
            return false;
        }
        hit(p, t, skillDamage(p, s, lv));
        boolean dual = needClaw && isClaw(p.getInventory().getItemInMainHand()) && isClaw(p.getInventory().getItemInOffHand());
        addCharge(p, s, dual ? 2 : 1); // 양손 손톱이면 2회 충전
        t.getWorld().spawnParticle(Particle.SWEEP_ATTACK, t.getLocation().add(0, 1, 0), 1);
        t.getWorld().playSound(t.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.1f);
        return true;
    }

    private void knockFrom(Player p, LivingEntity t, double power) {
        if (isBossLike(t)) return;
        Vector away = t.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
        if (away.lengthSquared() < 0.01) away = p.getEyeLocation().getDirection().setY(0);
        t.setVelocity(away.normalize().multiply(power).setY(0.35));
    }

    private boolean doKick(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final LivingEntity t = forced != null ? forced : findTarget(p, val(p, s, "range", lv, 4.5));
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + "대상이 없습니다.");
            return false;
        }
        final int kicks = Math.max(1, (int) val(p, s, "kicks", lv, 1.0));
        final double base = skillDamage(p, s, lv);
        final double expPct = val(p, s, "explosion-pct", lv, 0.0);
        final double expR = val(p, s, "explosion-radius", lv, 4.0);
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (!p.isOnline() || !t.isValid() || t.isDead()) {
                    cancel();
                    return;
                }
                n++;
                chargedHit(p, t, base);
                t.getWorld().spawnParticle(Particle.CRIT, t.getLocation().add(0, 1.0, 0), 8, 0.3, 0.4, 0.3, 0.1);
                t.getWorld().playSound(t.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 0.9f, 1.0f);
                if (n >= kicks) {
                    cancel();
                    knockFrom(p, t, expPct > 0 ? 1.6 : 1.2);
                    if (expPct > 0) {
                        double ed = base * kicks * expPct / 100.0;
                        for (LivingEntity o : around(t.getLocation(), expR, p)) elemHit(p, o, "fire", ed);
                        t.getWorld().spawnParticle(Particle.EXPLOSION, t.getLocation().add(0, 0.8, 0), 2, expR * 0.3, 0.3, expR * 0.3, 0.0);
                        t.getWorld().spawnParticle(Particle.FLAME, t.getLocation().add(0, 0.8, 0), 30, expR * 0.3, 0.4, expR * 0.3, 0.05);
                        t.getWorld().playSound(t.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.2f);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 3L);
        return true;
    }

    private boolean doDualStrike(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        if (!isClaw(p.getInventory().getItemInMainHand()) || !isClaw(p.getInventory().getItemInOffHand())) {
            if (!quiet) msg(p, ChatColor.RED + s.name + ": 양손에 손톱(괭이)을 들어야 합니다.");
            return false;
        }
        final LivingEntity t = forced != null ? forced : findTarget(p, val(p, s, "range", lv, 4.5));
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + "대상이 없습니다.");
            return false;
        }
        final double base = skillDamage(p, s, lv);
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (!p.isOnline() || !t.isValid() || t.isDead()) {
                    cancel();
                    return;
                }
                chargedHit(p, t, base);
                t.getWorld().spawnParticle(Particle.SWEEP_ATTACK, t.getLocation().add(0, 1, 0), 1);
                t.getWorld().playSound(t.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.9f, 1.3f);
                if (++n >= 2) cancel();
            }
        }.runTaskTimer(plugin, 0L, 4L);
        return true;
    }

    private boolean doFlight(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final double range = val(p, s, "range", lv, 28.0);
        LivingEntity t = forced != null ? forced : findTarget(p, range);
        if (t == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 시야에 적이 있어야 합니다.");
            return false;
        }
        World w = p.getWorld();
        Vector back = t.getLocation().toVector().subtract(p.getEyeLocation().getDirection().setY(0).normalize().multiply(1.6));
        Location dest = safeSpot(w, back.getX(), t.getLocation().getY(), back.getZ());
        if (dest == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 이동할 안전한 곳이 없습니다.");
            return false;
        }
        Location from = p.getLocation();
        dest.setYaw(from.getYaw());
        dest.setPitch(from.getPitch());
        w.spawnParticle(Particle.END_ROD, from.clone().add(0, 1.0, 0), 15, 0.3, 0.6, 0.3, 0.05);
        p.teleport(dest);
        p.setFallDistance(0.0f);
        removeDecoyOf(p);
        w.spawnParticle(Particle.END_ROD, dest.clone().add(0, 1.0, 0), 15, 0.3, 0.6, 0.3, 0.05);
        w.playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 0.7f, 1.4f);
        chargedHit(p, t, skillDamage(p, s, lv));
        knockFrom(p, t, 1.0);
        t.getWorld().spawnParticle(Particle.CRIT, t.getLocation().add(0, 1.0, 0), 10, 0.3, 0.4, 0.3, 0.1);
        return true;
    }

    private void describeMartial(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        if (s.kind.equals("mcharge")) out.add(ChatColor.GRAY + "한 번 때리고 충전 +1 (양손 손톱이면 +2). 최대 3단계, 15초. 필살기나 일반 공격으로 때리면 한 단계씩 소모");
        if (c.getBoolean("requires-claw", false)) out.add(ChatColor.GRAY + "손톱(괭이)을 들어야 사용");
        if (c.contains("dmg-pct")) out.add(ChatColor.RED + "충전 단계마다 물리 피해 +" + fmt(val(p, s, "dmg-pct", lv, 0)) + "%");
        if (c.contains("leech-life-pct")) out.add(ChatColor.RED + "충전 단계마다 피해의 " + fmt(val(p, s, "leech-life-pct", lv, 0)) + "% 생명력, " + fmt(val(p, s, "leech-mana-pct", lv, 0)) + "% 마나 흡수");
        if (c.contains("kicks")) out.add(ChatColor.GRAY + "발차기 " + Math.max(1, (int) val(p, s, "kicks", lv, 1)) + "회, 마지막에 밀쳐냄");
        if (c.contains("explosion-pct") && s.kind.equals("kick")) out.add(ChatColor.GOLD + "발차기 피해의 " + fmt(val(p, s, "explosion-pct", lv, 0)) + "%만큼 화염 폭발");
        if (c.contains("meteor-damage")) out.add(ChatColor.GOLD + "1충전 운석 " + fmt(val(p, s, "meteor-damage", lv, 0)) + " / 2충전 연쇄 번개 " + fmt(val(p, s, "chain-damage", lv, 0)) + " / 3충전 얼음살 " + fmt(val(p, s, "ice-damage", lv, 0)));
        if (s.id.equals("fists_of_fire")) out.add(ChatColor.GRAY + "1충전 화염 피해, 2충전 화염 폭발, 3충전 폭발 자리에 불길");
        if (s.id.equals("claws_of_thunder")) out.add(ChatColor.GRAY + "1충전 번개 피해, 2충전 번개 파장, 3충전 튕기는 번개");
        if (s.id.equals("blades_of_ice")) out.add(ChatColor.GRAY + "1충전 냉기 피해, 2충전 냉기 폭발, 3충전 빙결");
    }


    // ===================================================================
    //  0.26.0: 드루이드 원소 (화염폭풍 / 타오르는 바위 / 극지 돌풍 / 균열 / 회오리 갑옷 / 돌개바람 / 화산 / 회오리바람 / 아마겟돈 / 허리케인)  [미검증]
    // ===================================================================

    private final Map<String, Long> cooldowns = new HashMap<>();
    private final Map<UUID, double[]> cycloneArmors = new HashMap<>(); // {남은 흡수량, 끝나는 시각}
    private final Map<UUID, BukkitTask> hurricanes = new HashMap<>();
    private final Map<UUID, BukkitTask> armageddons = new HashMap<>();

    private long cooldownLeft(Player p, SkillDef s) {
        if (!s.sec.contains("cooldown-seconds")) return 0L;
        Long u = cooldowns.get(p.getUniqueId() + ":" + s.id);
        return u == null ? 0L : Math.max(0L, u - System.currentTimeMillis());
    }

    private void startCooldown(Player p, SkillDef s) {
        if (!s.sec.contains("cooldown-seconds")) return;
        cooldowns.put(p.getUniqueId() + ":" + s.id,
                System.currentTimeMillis() + (long) (s.sec.getDouble("cooldown-seconds", 0.0) * 1000.0));
    }

    private void mixedHit(Player p, LivingEntity t, double fire, double phys) {
        if (fire > 0) elemHit(p, t, "fire", fire);
        if (phys > 0) pureHit(p, t, phys);
    }

    private Vector flatDir(Player p) {
        Vector d = p.getEyeLocation().getDirection().setY(0);
        if (d.lengthSquared() < 0.01) d = new Vector(1, 0, 0);
        return d.normalize();
    }

    // ---------------------------------------------------------------- 화염폭풍
    private boolean doFirestorm(Player p, SkillDef s, int lv) {
        final double range = val(p, s, "range", lv, 7.0);
        final double dmg = val(p, s, "fire-damage", lv, 10.0);
        final Vector base = flatDir(p);
        final Location start = p.getLocation().add(0, 0.4, 0);
        final World w = p.getWorld();
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            final Vector d = base.clone();
            if (k > 0) d.rotateAroundY((k == 1 ? 1 : -1) * (0.25 + random.nextDouble() * 0.35));
            final Location pos = start.clone();
            final Set<UUID> hit = new HashSet<>();
            final double[] trav = {0.0};
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!p.isOnline() || trav[0] >= range) {
                        cancel();
                        return;
                    }
                    if (kk > 0) d.rotateAroundY((random.nextDouble() - 0.5) * 0.4);
                    Location nx = pos.clone().add(d.clone().multiply(0.7));
                    if (!nx.getBlock().isPassable()) {
                        cancel();
                        return;
                    }
                    pos.setX(nx.getX());
                    pos.setZ(nx.getZ());
                    trav[0] += 0.7;
                    w.spawnParticle(Particle.FLAME, pos, 6, 0.3, 0.15, 0.3, 0.02);
                    w.spawnParticle(Particle.LAVA, pos, 1, 0.2, 0.1, 0.2, 0.0);
                    for (LivingEntity o : around(pos, 1.3, p)) if (hit.add(o.getUniqueId())) elemHit(p, o, "fire", dmg);
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }
        w.playSound(p.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1.0f, 0.8f);
        return true;
    }

    // ---------------------------------------------------------------- 타오르는 바위
    private boolean doMolten(Player p, SkillDef s, int lv, LivingEntity forced) {
        final double range = val(p, s, "range", lv, 14.0);
        final double fire = val(p, s, "fire-damage", lv, 20.0);
        final double phys = val(p, s, "phys-damage", lv, 15.0);
        final double knock = val(p, s, "knock", lv, 1.2);
        final double zdmg = val(p, s, "zone-damage", lv, 4.0);
        final double zsec = val(p, s, "zone-seconds", lv, 3.0);
        final Location eye = p.getEyeLocation();
        final Vector d = (forced != null ? aimPoint(forced).subtract(eye.toVector()) : eye.getDirection().clone()).setY(0);
        if (d.lengthSquared() < 0.01) d.setX(1);
        d.normalize();
        final Location pos = p.getLocation().add(0, 0.8, 0).add(d.clone().multiply(1.0));
        final World w = p.getWorld();
        final Map<UUID, Integer> last = new HashMap<>();
        final double[] trav = {0.0};
        final int[] n = {0};
        new BukkitRunnable() {
            @Override
            public void run() {
                n[0]++;
                boolean end = !p.isOnline() || trav[0] >= range;
                if (!end) {
                    Location nx = pos.clone().add(d.clone().multiply(0.5));
                    if (!nx.getBlock().isPassable()) end = true;
                    else {
                        pos.setX(nx.getX());
                        pos.setZ(nx.getZ());
                        trav[0] += 0.5;
                    }
                }
                w.spawnParticle(Particle.FLAME, pos, 8, 0.3, 0.3, 0.3, 0.03);
                dust(w, pos.getX(), pos.getY(), pos.getZ(), 0x8A2A0A, 3.0f);
                if (!end) {
                    for (LivingEntity o : around(pos, 1.5, p)) {
                        Integer lh = last.get(o.getUniqueId());
                        if (lh != null && n[0] - lh < 8) continue;
                        last.put(o.getUniqueId(), n[0]);
                        mixedHit(p, o, fire, phys);
                        knockFrom(p, o, knock);
                    }
                    return;
                }
                cancel();
                if (!p.isOnline()) return;
                for (LivingEntity o : around(pos, 2.5, p)) mixedHit(p, o, fire * 0.5, phys * 0.5);
                w.spawnParticle(Particle.EXPLOSION, pos, 2, 0.4, 0.3, 0.4, 0.0);
                w.spawnParticle(Particle.FLAME, pos, 30, 0.8, 0.4, 0.8, 0.05);
                w.playSound(pos, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.0f);
                fireZone(p, pos, 1.8, zsec, zdmg);
            }
        }.runTaskTimer(plugin, 0L, 1L);
        w.playSound(p.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.6f);
        return true;
    }

    // ---------------------------------------------------------------- 극지 돌풍 (냉기 지옥불)
    private boolean doArctic(Player p, SkillDef s, int lv) {
        final double secs = val(p, s, "blast-seconds", lv, 3.0);
        final double range = val(p, s, "range", lv, 6.0);
        final double dmg = val(p, s, "cold-damage", lv, 5.0);
        final double slow = val(p, s, "slow-seconds", lv, 1.0);
        final int ticks = Math.max(1, (int) (secs * 4.0));
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (n++ >= ticks || !p.isOnline() || p.isDead()) {
                    cancel();
                    return;
                }
                World w = p.getWorld();
                Location eye = p.getEyeLocation();
                Vector d = eye.getDirection().normalize();
                for (double k = 1.0; k <= range; k += 0.5) {
                    Location l = eye.clone().add(d.clone().multiply(k)).add(0, -0.3, 0);
                    w.spawnParticle(Particle.SNOWFLAKE, l, 2, 0.08 * k, 0.08 * k, 0.08 * k, 0.01);
                }
                for (LivingEntity t : around(p.getLocation(), range + 1.0, p)) {
                    Vector to = aimPoint(t).subtract(eye.toVector());
                    double dist = to.length();
                    if (dist > range + 0.5 || dist < 0.3) continue;
                    if (to.normalize().dot(d) < 0.9) continue;
                    elemHit(p, t, "cold", dmg);
                    slowFor(t, slow, 1);
                }
                if (n % 2 == 1) w.playSound(p.getLocation(), Sound.BLOCK_POWDER_SNOW_STEP, 1.0f, 0.8f);
            }
        }.runTaskTimer(plugin, 0L, 5L);
        return true;
    }

    // ---------------------------------------------------------------- 균열
    private boolean doFissure(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final Location c = groundTarget(p, val(p, s, "range", lv, 20.0), forced);
        if (c == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 땅을 바라보고 쓰세요.");
            return false;
        }
        final double radius = radius(p, s, lv, 4.6);
        final double dmg = val(p, s, "fire-damage", lv, 10.0);
        final int count = Math.max(1, (int) (val(p, s, "fissure-seconds", lv, 3.0) * 20.0 / 6.0));
        final World w = c.getWorld();
        startTrap(p, 0L, 6L, i -> {
            if (i >= count) return true;
            double a = random.nextDouble() * Math.PI * 2;
            double r = Math.sqrt(random.nextDouble()) * radius;
            Location at = c.clone().add(Math.cos(a) * r, 0.1, Math.sin(a) * r);
            for (int k = 0; k < 8; k++) {
                w.spawnParticle(Particle.FLAME, at.getX(), at.getY() + k * 0.3, at.getZ(), 2, 0.15, 0.05, 0.15, 0.02);
            }
            w.spawnParticle(Particle.LAVA, at, 3, 0.4, 0.1, 0.4, 0.0);
            if (i % 2 == 0) w.playSound(at, Sound.BLOCK_LAVA_POP, 0.8f, 0.8f);
            for (LivingEntity o : around(at, 1.5, p)) elemHit(p, o, "fire", dmg);
            return false;
        });
        return true;
    }

    // ---------------------------------------------------------------- 회오리 갑옷
    private boolean doCycloneArmor(Player p, SkillDef s, int lv) {
        double amt = val(p, s, "absorb", lv, 40.0);
        double secs = val(p, s, "armor-seconds", lv, 144.0);
        cycloneArmors.put(p.getUniqueId(), new double[]{amt, System.currentTimeMillis() + secs * 1000.0});
        p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1.0, 0), 25, 0.5, 0.7, 0.5, 0.05);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.6f);
        msg(p, ChatColor.AQUA + s.name + ": 화염/냉기/번개 피해 " + fmt(amt) + " 흡수");
        return true;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCycloneAbsorb(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player v)) return;
        double[] sh = cycloneArmors.get(v.getUniqueId());
        if (sh == null) return;
        if (sh[1] < System.currentTimeMillis()) {
            cycloneArmors.remove(v.getUniqueId());
            return;
        }
        DamageCause c = e.getCause();
        boolean elem = c == DamageCause.FIRE || c == DamageCause.FIRE_TICK || c == DamageCause.LAVA || c == DamageCause.HOT_FLOOR
                || c == DamageCause.LIGHTNING || c == DamageCause.FREEZE;
        if (!elem && e instanceof EntityDamageByEntityEvent be) {
            Entity dm = be.getDamager();
            elem = dm instanceof org.bukkit.entity.Fireball || dm instanceof org.bukkit.entity.LightningStrike
                    || dm instanceof org.bukkit.entity.Snowball;
        }
        if (!elem) return;
        double dmg = e.getDamage();
        if (dmg <= 0) return;
        double a = Math.min(sh[0], dmg);
        sh[0] -= a;
        e.setDamage(dmg - a);
        v.getWorld().spawnParticle(Particle.CLOUD, v.getLocation().add(0, 1.0, 0), 6, 0.4, 0.5, 0.4, 0.02);
        if (sh[0] <= 0.0001) {
            cycloneArmors.remove(v.getUniqueId());
            msg(v, ChatColor.GRAY + "회오리 갑옷이 흩어졌다.");
        }
    }

    // ---------------------------------------------------------------- 돌개바람
    private boolean doTwister(Player p, SkillDef s, int lv) {
        final double dmg = val(p, s, "phys-damage", lv, 12.0);
        final double stun = val(p, s, "stun-seconds", lv, 0.5);
        final double range = val(p, s, "range", lv, 12.0);
        final Set<UUID> once = new HashSet<>();
        final Location from = p.getLocation().add(0, 0.9, 0);
        final Vector base = flatDir(p);
        for (int k = -1; k <= 1; k++) {
            Vector d = base.clone().rotateAroundY(k * 0.22 + (random.nextDouble() - 0.5) * 0.12);
            flyMissile(p, from.clone(), d, 0.6, range, true, false, null, Particle.CLOUD, once, le -> {
                pureHit(p, le, dmg);
                stun(le, stun);
            });
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1.0f, 1.4f);
        return true;
    }

    // ---------------------------------------------------------------- 화산
    private boolean doVolcano(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final Location c = groundTarget(p, val(p, s, "range", lv, 20.0), forced);
        if (c == null) {
            if (!quiet) msg(p, ChatColor.GRAY + s.name + ": 땅을 바라보고 쓰세요.");
            return false;
        }
        final double radius = radius(p, s, lv, 3.2);
        final double fire = val(p, s, "fire-damage", lv, 12.0);
        final double phys = val(p, s, "phys-damage", lv, 8.0);
        final int count = Math.max(2, (int) (val(p, s, "volcano-seconds", lv, 6.0) * 4.0));
        final World w = c.getWorld();
        startTrap(p, 0L, 5L, i -> {
            if (i >= count) return true;
            for (int k = 0; k < 10; k++) {
                w.spawnParticle(Particle.LAVA, c.getX(), c.getY() + k * 0.3, c.getZ(), 1, 0.4, 0.1, 0.4, 0.0);
            }
            w.spawnParticle(Particle.FLAME, c.clone().add(0, 0.5, 0), 10, radius * 0.4, 0.4, radius * 0.4, 0.04);
            w.spawnParticle(Particle.LARGE_SMOKE, c.clone().add(0, 3.0, 0), 3, 0.5, 0.3, 0.5, 0.02);
            if (i % 2 == 0) {
                for (LivingEntity o : around(c, radius, p)) mixedHit(p, o, fire, phys);
                w.playSound(c, Sound.BLOCK_LAVA_EXTINGUISH, 0.8f, 0.6f);
            }
            // 불덩어리: 더 넓은 범위에 무작위
            double a = random.nextDouble() * Math.PI * 2;
            double r = Math.sqrt(random.nextDouble()) * radius * 2.4;
            Location at = c.clone().add(Math.cos(a) * r, 0.2, Math.sin(a) * r);
            w.spawnParticle(Particle.FLAME, at, 12, 0.3, 0.2, 0.3, 0.05);
            for (LivingEntity o : around(at, 1.3, p)) mixedHit(p, o, fire, phys);
            return false;
        });
        w.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.5f);
        return true;
    }

    // ---------------------------------------------------------------- 회오리바람 (토네이도)
    private boolean doTornado(Player p, SkillDef s, int lv) {
        final double dmg = val(p, s, "phys-damage", lv, 20.0);
        final int steps = Math.max(5, (int) (val(p, s, "tornado-seconds", lv, 5.0) * 10.0));
        final Vector d = flatDir(p);
        final Location pos = p.getLocation().add(d.clone().multiply(1.5));
        final World w = pos.getWorld();
        final Set<UUID> entered = new HashSet<>();
        startTrap(p, 0L, 2L, i -> {
            if (i >= steps) return true;
            d.rotateAroundY((random.nextDouble() - 0.5) * 0.5);
            Location nx = pos.clone().add(d.clone().multiply(0.45));
            if (!nx.getBlock().isPassable()) {
                if (nx.clone().add(0, 1, 0).getBlock().isPassable()) pos.add(0, 1, 0);
                else d.rotateAroundY(Math.PI * (0.5 + random.nextDouble()));
            } else {
                pos.setX(nx.getX());
                pos.setZ(nx.getZ());
                if (pos.clone().add(0, -1, 0).getBlock().isPassable() && pos.getY() > p.getLocation().getY() - 3) pos.add(0, -0.5, 0);
            }
            for (int k = 0; k < 8; k++) {
                double a = i * 0.9 + k * 0.8;
                double h = k * 0.35;
                double rr = 0.3 + h * 0.25;
                w.spawnParticle(Particle.CLOUD, pos.getX() + Math.cos(a) * rr, pos.getY() + h, pos.getZ() + Math.sin(a) * rr, 1, 0.0, 0.0, 0.0, 0.0);
            }
            for (LivingEntity o : around(pos, 1.8, p)) {
                if (entered.add(o.getUniqueId()) || i % 6 == 0) pureHit(p, o, dmg);
            }
            return false;
        });
        w.playSound(pos, Sound.ENTITY_PHANTOM_SWOOP, 1.0f, 0.6f);
        return true;
    }

    // ---------------------------------------------------------------- 아마겟돈
    private boolean doArmageddon(Player p, SkillDef s, int lv) {
        BukkitTask old = armageddons.remove(p.getUniqueId());
        if (old != null) old.cancel();
        final double secs = val(p, s, "armageddon-seconds", lv, 8.0);
        final double radius = radius(p, s, lv, 5.3);
        final double fire = val(p, s, "fire-damage", lv, 22.0);
        final double phys = val(p, s, "phys-damage", lv, 14.0);
        final double zdmg = val(p, s, "zone-damage", lv, 3.0);
        final int total = Math.max(2, (int) (secs * 4.0));
        final int[] n = {0};
        final BukkitTask[] ref = new BukkitTask[1];
        ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (n[0]++ >= total || !p.isOnline() || p.isDead()) {
                ref[0].cancel();
                armageddons.remove(p.getUniqueId());
                return;
            }
            final World w = p.getWorld();
            double a = random.nextDouble() * Math.PI * 2;
            double r = Math.sqrt(random.nextDouble()) * radius;
            final Location pt = p.getLocation().add(Math.cos(a) * r, 0.0, Math.sin(a) * r);
            for (int k = 0; k < 10; k++) {
                w.spawnParticle(Particle.FLAME, pt.getX() + k * 0.3, pt.getY() + 2 + k * 0.9, pt.getZ() + k * 0.15, 2, 0.1, 0.1, 0.1, 0.02);
            }
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline()) return;
                for (LivingEntity o : around(pt, 2.3, p)) mixedHit(p, o, fire, phys);
                w.spawnParticle(Particle.EXPLOSION, pt.clone().add(0, 0.4, 0), 1, 0.2, 0.2, 0.2, 0.0);
                w.spawnParticle(Particle.FLAME, pt.clone().add(0, 0.4, 0), 14, 0.6, 0.3, 0.6, 0.05);
                w.playSound(pt, Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 0.8f);
                if (zdmg > 0) fireZone(p, pt, 1.3, 1.5, zdmg);
            }, 8L);
        }, 0L, 5L);
        armageddons.put(p.getUniqueId(), ref[0]);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.5f);
        msg(p, ChatColor.GOLD + s.name + ": " + fmt(secs) + "초");
        return true;
    }

    // ---------------------------------------------------------------- 허리케인
    private boolean doHurricane(Player p, SkillDef s, int lv) {
        BukkitTask old = hurricanes.remove(p.getUniqueId());
        if (old != null) old.cancel();
        final double secs = val(p, s, "hurricane-seconds", lv, 10.0);
        final double radius = radius(p, s, lv, 5.0);
        final double dmg = val(p, s, "cold-damage", lv, 12.0);
        final double slow = val(p, s, "slow-seconds", lv, 1.5);
        final long end = System.currentTimeMillis() + (long) (secs * 1000.0);
        final int[] n = {0};
        final BukkitTask[] ref = new BukkitTask[1];
        ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || p.isDead() || System.currentTimeMillis() > end) {
                ref[0].cancel();
                hurricanes.remove(p.getUniqueId());
                return;
            }
            final World w = p.getWorld();
            Location c = p.getLocation();
            for (int k = 0; k < 12; k++) {
                double a = n[0] * 0.6 + k * 0.52;
                double h = (k % 6) * 0.5;
                double rr = radius * (0.55 + 0.45 * (k % 6) / 5.0);
                w.spawnParticle(Particle.SNOWFLAKE, c.getX() + Math.cos(a) * rr, c.getY() + h, c.getZ() + Math.sin(a) * rr, 1, 0.0, 0.0, 0.0, 0.0);
                if (k % 3 == 0) w.spawnParticle(Particle.CLOUD, c.getX() + Math.cos(a) * rr, c.getY() + h, c.getZ() + Math.sin(a) * rr, 1, 0.0, 0.0, 0.0, 0.0);
            }
            if (n[0] % 4 == 0) {
                for (LivingEntity o : around(c, radius, p)) {
                    elemHit(p, o, "cold", dmg);
                    slowFor(o, slow, 1);
                }
                w.playSound(c, Sound.ENTITY_PHANTOM_FLAP, 0.6f, 0.5f);
            }
            n[0]++;
        }, 0L, 4L); // 0.2초마다 그리고 4번에 한 번(0.8초) 피해
        hurricanes.put(p.getUniqueId(), ref[0]);
        msg(p, ChatColor.AQUA + s.name + ": " + fmt(secs) + "초");
        return true;
    }

    private void describeDruid(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        if (c.contains("fire-damage")) out.add(ChatColor.GOLD + "화염 피해 " + fmt(val(p, s, "fire-damage", lv, 0)) + " (화염 저항 적용)");
        if (c.contains("phys-damage")) out.add(ChatColor.GRAY + "물리 피해 " + fmt(val(p, s, "phys-damage", lv, 0)));
        if (c.contains("cold-damage")) out.add(ChatColor.AQUA + "냉기 피해 " + fmt(val(p, s, "cold-damage", lv, 0)) + " (냉기 저항 적용)");
        if (c.contains("stun-seconds")) out.add(ChatColor.GRAY + "기절 " + fmt(val(p, s, "stun-seconds", lv, 0)) + "초");
        if (c.contains("knock")) out.add(ChatColor.GRAY + "밀쳐냄");
        if (c.contains("fissure-seconds")) out.add(ChatColor.GOLD + fmt(val(p, s, "fissure-seconds", lv, 0)) + "초 동안 무작위로 균열 (0.3초마다)");
        if (c.contains("volcano-seconds")) out.add(ChatColor.GOLD + "화산 " + fmt(val(p, s, "volcano-seconds", lv, 0)) + "초 (0.5초마다 피해 + 불덩어리)");
        if (c.contains("tornado-seconds")) out.add(ChatColor.GRAY + "회오리 " + fmt(val(p, s, "tornado-seconds", lv, 0)) + "초 (무작위로 움직임, 0.6초마다 피해)");
        if (c.contains("armageddon-seconds")) out.add(ChatColor.GOLD + fmt(val(p, s, "armageddon-seconds", lv, 0)) + "초 동안 주변에 운석 비 (반경 " + fmt(radius(p, s, lv, 5.3)) + "칸)");
        if (c.contains("hurricane-seconds")) out.add(ChatColor.AQUA + "허리케인 " + fmt(val(p, s, "hurricane-seconds", lv, 0)) + "초 (0.8초마다 냉기 피해 + 둔화, 따라다님)");
        if (c.contains("blast-seconds")) out.add(ChatColor.AQUA + fmt(val(p, s, "blast-seconds", lv, 0)) + "초 동안 냉기 줄기 (0.25초마다, 사거리 " + fmt(val(p, s, "range", lv, 0)) + "칸)");
        if (c.contains("absorb") && s.kind.equals("cyclone")) out.add(ChatColor.AQUA + "화염/냉기/번개 피해 " + fmt(val(p, s, "absorb", lv, 0)) + " 흡수 (지속 " + fmt(val(p, s, "armor-seconds", lv, 0)) + "초)");
        if (s.kind.equals("form")) out.add(ChatColor.GREEN + "변신 " + fmt(val(p, s, "duration", lv, 0)) + "초 (다시 쓰면 해제)");
        if (c.contains("requires-form")) out.add(ChatColor.YELLOW + (c.getString("requires-form").equals("bear") ? "곰인간" : c.getString("requires-form").equals("wolf") ? "늑대인간" : "늑대인간/곰인간") + " 상태에서만 사용");
        if (c.isConfigurationSection("stack-bonuses")) {
            StringBuilder sbb = new StringBuilder();
            for (String k : c.getConfigurationSection("stack-bonuses").getKeys(false)) {
                if (sbb.length() > 0) sbb.append(", ");
                sbb.append(k).append(" 최대 ").append(fmt(scaled(c.getConfigurationSection("stack-bonuses"), k, lv, 0)));
            }
            out.add(ChatColor.YELLOW + "적중마다 중첩(최대 " + (int) val(p, s, "stack-max", lv, 5) + "회, " + fmt(val(p, s, "stack-seconds", lv, 6)) + "초): " + sbb);
        }
        if (c.contains("poison-spread-radius")) out.add(ChatColor.GREEN + "주변 " + fmt(c.getDouble("poison-spread-radius")) + "칸 안의 적에게 독 전염");
        if (c.contains("cooldown-seconds")) out.add(ChatColor.RED + "재사용 대기 " + fmt(c.getDouble("cooldown-seconds", 0.0)) + "초 (시전 속도로 줄지 않음)");
    }


    // ===================================================================
    //  0.27.0: 드루이드 변신 (늑대인간 / 곰인간 / 근접 스킬 7개)  [미검증]
    //   변신은 버프(buffs)로 구현한다. 변신 중에는 form-ok / requires-form 이 있는 스킬만 쓸 수 있다.
    // ===================================================================

    private final Map<UUID, Map<String, Frenzy>> formStacks = new HashMap<>();

    /** 지금 변신 상태("wolf"/"bear")이면 그 이름, 아니면 null. */
    private String formOf(Player p) {
        Map<String, Buff> m = buffs.get(p.getUniqueId());
        if (m == null || m.isEmpty()) return null;
        long now = System.currentTimeMillis();
        for (Buff b : m.values()) {
            if (b.until < now) continue;
            SkillDef sd = skills.get(b.id);
            if (sd != null && !sd.sec.getString("form", "").isEmpty()) return sd.sec.getString("form", "");
        }
        return null;
    }

    private boolean doForm(Player p, SkillDef s, int lv) {
        Map<String, Buff> m = buffs.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
        Buff cur = m.get(s.id);
        if (cur != null && cur.until >= System.currentTimeMillis()) { // 다시 쓰면 변신이 풀린다
            m.remove(s.id);
            bonusCache.remove(p.getUniqueId());
            refreshAttributes(p);
            p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.05);
            msg(p, ChatColor.GRAY + s.name + " 해제");
            return true;
        }
        String ex = s.sec.getString("exclusive", "");
        if (!ex.isEmpty()) m.remove(ex);
        double dur = val(p, s, "duration", lv, 60.0);
        m.put(s.id, new Buff(s.id, lv, System.currentTimeMillis() + (long) (dur * 1000.0)));
        bonusCache.remove(p.getUniqueId());
        refreshAttributes(p);
        World w = p.getWorld();
        w.spawnParticle(Particle.POOF, p.getLocation().add(0, 1, 0), 40, 0.5, 0.8, 0.5, 0.08);
        w.playSound(p.getLocation(), s.sec.getString("form", "wolf").equals("bear") ? Sound.ENTITY_POLAR_BEAR_WARNING : Sound.ENTITY_WOLF_GROWL, 1.0f, 0.8f);
        msg(p, ChatColor.GREEN + s.name + ": " + fmt(dur) + "초");
        return true;
    }

    /** 충격파: 앞쪽 부채꼴 안의 적에게 물리 피해 + 기절. */
    private boolean doShockWave(Player p, SkillDef s, int lv) {
        final double range = val(p, s, "range", lv, 6.0);
        final double dmg = skillDamage(p, s, lv);
        final double stun = val(p, s, "stun-seconds", lv, 2.0);
        final Location eye = p.getEyeLocation();
        final Vector dir = flatDir(p);
        final World w = p.getWorld();
        for (double k = 1.0; k <= range; k += 0.8) {
            for (double a = -0.8; a <= 0.8; a += 0.4) {
                Vector v = dir.clone().rotateAroundY(a).multiply(k);
                w.spawnParticle(Particle.CLOUD, p.getLocation().add(v).add(0, 0.2, 0), 1, 0.05, 0.05, 0.05, 0.0);
            }
        }
        for (LivingEntity t : around(p.getLocation(), range + 1.0, p)) {
            Vector to = aimPoint(t).subtract(eye.toVector()).setY(0);
            if (to.lengthSquared() < 0.01 || to.normalize().dot(dir) < 0.5) continue;
            pureHit(p, t, dmg);
            stun(t, stun);
        }
        w.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 0.6f);
        return true;
    }


    // ===================================================================
    //  0.28.0: 드루이드 소환 (큰까마귀 / 늑대 / 회색곰 / 정령 / 덩굴)  [미검증]
    //   동물(영혼 늑대/광포한 늑대/회색곰)은 서로 함께 소환할 수 있고, 정령과 덩굴은 각각 한 종류만 유지된다.
    // ===================================================================

    private final Map<UUID, java.util.ArrayDeque<BukkitTask>> ravens = new HashMap<>();
    private final Map<UUID, BukkitTask> plants = new HashMap<>();

    private boolean doAnimal(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final UUID id = p.getUniqueId();
        List<Summon> same = new ArrayList<>();
        for (Summon x : ownedSummons(id, "animal")) if (s.id.equals(x.skillId)) same.add(x);
        final int max = Math.max(1, (int) val(p, s, "max-count", lv, 1.0));
        int replacing = Math.max(0, same.size() - max + 1);
        if (!summonRoomFor(p, replacing)) return false;
        while (same.size() >= max) removeSummon(same.remove(0), true);
        int pcap = Math.max(1, plugin.getConfig().getInt("summon.max-animals-per-player", 12));
        List<Summon> all = ownedSummons(id, "animal");
        while (all.size() >= pcap) removeSummon(all.remove(0), true);
        final Location at = summonSpot(p, val(p, s, "range", lv, 10.0), forced);
        final double oak = auraOptionValue(p, "oak_sage", "최대 생명력%");
        final double hp = val(p, s, "hp", lv, 30.0) * (1.0 + oak / 100.0);
        final double dmg = val(p, s, "damage", lv, 5.0);
        final String ent = s.sec.getString("summon-entity", "WOLF");
        LivingEntity z;
        if (ent.equals("POLAR_BEAR")) z = at.getWorld().spawn(at, org.bukkit.entity.PolarBear.class);
        else {
            org.bukkit.entity.Wolf w = at.getWorld().spawn(at, org.bukkit.entity.Wolf.class);
            w.setAngry(true);
            z = w;
        }
        if (z instanceof org.bukkit.entity.Ageable ag) ag.setAdult();
        setupSummon(z, ChatColor.translateAlternateColorCodes('&', s.sec.getString("summon-name", "&7소환수")), hp, dmg);
        if (z instanceof Mob mb) mb.setTarget(null);
        Summon sm = new Summon();
        sm.owner = id;
        sm.ent = z;
        sm.type = "animal";
        sm.skillId = s.id;
        sm.dmg = dmg;
        sm.resist = Math.min(85.0, 5.0 * lv); // 기술 레벨 1당 모든 저항 5%
        sm.slowPct = val(p, s, "slow-pct", lv, 0.0);
        sm.stunSec = val(p, s, "stun-seconds", lv, 0.0);
        sm.knock = val(p, s, "knock", lv, 0.0);
        sm.eats = s.sec.getBoolean("eats-corpses", false);
        sm.until = 0L;
        summons.put(z.getUniqueId(), sm);
        at.getWorld().spawnParticle(Particle.CLOUD, at.clone().add(0, 0.6, 0), 15, 0.3, 0.3, 0.3, 0.03);
        at.getWorld().playSound(at, ent.equals("POLAR_BEAR") ? Sound.ENTITY_POLAR_BEAR_WARNING : Sound.ENTITY_WOLF_HOWL, 0.7f, 1.0f);
        msg(p, ChatColor.GREEN + s.name + " (" + (same.size() + 1) + "/" + max + ")  생명력 " + fmt(hp) + ", 공격력 " + fmt(dmg) + ", 모든 저항 " + fmt(sm.resist) + "%");
        return true;
    }

    /** 광포한 늑대: 시체를 먹으면 20초 동안 피해 2배. */
    private void direTick(Summon sm, long now) {
        AttributeInstance ad = sm.ent.getAttribute(VersionCompat.ATTACK_DAMAGE);
        if (sm.buffUntil < now) {
            if (ad != null && ad.getBaseValue() != sm.dmg) ad.setBaseValue(sm.dmg);
            for (Corpse c : new ArrayList<>(corpses)) {
                if (c.world != sm.ent.getWorld() || c.until < now) continue;
                if (c.loc.distanceSquared(sm.ent.getLocation()) > 9.0) continue;
                corpses.remove(c);
                sm.buffUntil = now + 20000L;
                sm.ent.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, sm.ent.getLocation().add(0, 0.8, 0), 8, 0.3, 0.3, 0.3, 0.0);
                sm.ent.getWorld().playSound(sm.ent.getLocation(), Sound.ENTITY_WOLF_GROWL, 0.8f, 0.6f);
                break;
            }
        }
        if (sm.buffUntil >= now) {
            if (ad != null && ad.getBaseValue() < sm.dmg * 1.99) ad.setBaseValue(sm.dmg * 2.0);
            sm.ent.getWorld().spawnParticle(Particle.ANGRY_VILLAGER, sm.ent.getLocation().add(0, 1.0, 0), 1, 0.2, 0.2, 0.2, 0.0);
        }
    }

    private boolean doSpirit(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final UUID id = p.getUniqueId();
        List<Summon> old = ownedSummons(id, "spirit");
        if (!summonRoomFor(p, old.size())) return false;
        for (Summon o : old) removeSummon(o, true); // 정령은 동시에 한 종류만
        final Location at = summonSpot(p, val(p, s, "range", lv, 6.0), forced);
        org.bukkit.entity.ArmorStand as = at.getWorld().spawn(at, org.bukkit.entity.ArmorStand.class);
        as.setInvisible(true);
        as.setGravity(false);
        as.setInvulnerable(true);
        as.setMarker(true);
        as.setBasePlate(false);
        Material blk = Material.matchMaterial(s.sec.getString("spirit-block", "WHITE_WOOL"));
        if (as.getEquipment() != null) as.getEquipment().setHelmet(new ItemStack(blk == null ? Material.WHITE_WOOL : blk));
        setupSummon(as, ChatColor.translateAlternateColorCodes('&', s.sec.getString("summon-name", "&f정령")), 20.0, 0.0);
        Summon sm = new Summon();
        sm.owner = id;
        sm.ent = as;
        sm.type = "spirit";
        sm.skillId = s.id;
        sm.castLv = lv;
        sm.radius = radius(p, s, lv, 16.0);
        sm.rgb = s.sec.getInt("spirit-rgb", 0xFFFFFF);
        sm.until = 0L;
        summons.put(as.getUniqueId(), sm);
        at.getWorld().spawnParticle(Particle.END_ROD, at.clone().add(0, 1.0, 0), 25, 0.3, 0.6, 0.3, 0.04);
        at.getWorld().playSound(at, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 0.8f, 1.6f);
        msg(p, ChatColor.GREEN + s.name + ": 반경 " + fmt(sm.radius) + "칸 안의 아군에게 오라");
        return true;
    }

    private void spiritTick(Summon sm, Player o, long now) {
        SkillDef sd = skills.get(sm.skillId);
        if (sd == null) return;
        Location c = sm.ent.getLocation();
        World w = c.getWorld();
        List<Player> rec = new ArrayList<>();
        rec.add(o);
        for (Player q : w.getPlayers()) {
            if (q != o && !q.isDead() && q.getLocation().distanceSquared(c) <= sm.radius * sm.radius) rec.add(q);
        }
        for (Player r : rec) {
            if (r.getWorld() != w || (r == o && o.getLocation().distanceSquared(c) > sm.radius * sm.radius)) continue;
            Map<String, Buff> map = auraBuffs.computeIfAbsent(r.getUniqueId(), k -> new HashMap<>());
            Buff old = map.get(sm.skillId);
            if (old == null || old.until < now || old.level <= sm.castLv) map.put(sm.skillId, new Buff(sm.skillId, sm.castLv, now + 2500L));
            bonusCache.remove(r.getUniqueId());
        }
        for (int i = 0; i < 6; i++) {
            double a = summonTickCount * 0.5 + i * Math.PI / 3.0;
            dust(w, c.getX() + Math.cos(a) * 0.8, c.getY() + 0.5 + (i % 3) * 0.5, c.getZ() + Math.sin(a) * 0.8, sm.rgb, 1.3f);
        }
        if (summonTickCount % 4 == 0) {
            for (int i = 0; i < 16; i++) {
                double a = Math.PI * 2 * i / 16.0;
                dust(w, c.getX() + Math.cos(a) * sm.radius, c.getY() + 0.2, c.getZ() + Math.sin(a) * sm.radius, sm.rgb, 0.8f);
            }
        }
    }

    private boolean doRaven(Player p, SkillDef s, int lv) {
        final UUID id = p.getUniqueId();
        final java.util.ArrayDeque<BukkitTask> dq = ravens.computeIfAbsent(id, k -> new java.util.ArrayDeque<>());
        final int cap = Math.max(1, s.sec.getInt("max-ravens", 5));
        final int spawn = Math.max(1, Math.min(cap, (int) val(p, s, "count", lv, 1.0)));
        final double dmg = val(p, s, "phys-damage", lv, 8.0);
        final int attacks = Math.max(1, (int) val(p, s, "attacks", lv, 10.0));
        final long end = System.currentTimeMillis() + (long) (val(p, s, "raven-seconds", lv, 40.0) * 1000.0);
        for (int k = 0; k < spawn; k++) {
            while (dq.size() >= cap) {
                BukkitTask old = dq.pollFirst();
                if (old != null) old.cancel();
            }
            final double phase = random.nextDouble() * Math.PI * 2;
            final Location pos = p.getEyeLocation().add(Math.cos(phase) * 1.5, 0.8, Math.sin(phase) * 1.5);
            final int[] left = {attacks};
            final int[] cd = {0};
            final int[] n = {0};
            final BukkitTask[] ref = new BukkitTask[1];
            ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
                if (!p.isOnline() || p.isDead() || left[0] <= 0 || System.currentTimeMillis() > end || p.getWorld() != pos.getWorld()) {
                    ref[0].cancel();
                    dq.remove(ref[0]);
                    return;
                }
                n[0]++;
                if (cd[0] > 0) cd[0]--;
                LivingEntity tg = nearestTo(p.getLocation(), 16.0, p);
                Vector want;
                double speed;
                if (tg != null) {
                    want = aimPoint(tg);
                    speed = 0.9;
                } else {
                    double a = phase + n[0] * 0.15;
                    want = p.getEyeLocation().toVector().add(new Vector(Math.cos(a) * 1.6, 0.8 + Math.sin(n[0] * 0.3) * 0.3, Math.sin(a) * 1.6));
                    speed = 0.6;
                }
                Vector to = want.clone().subtract(pos.toVector());
                double len = to.length();
                if (len > 0.05) pos.add(to.normalize().multiply(Math.min(speed, len)));
                World w = pos.getWorld();
                dust(w, pos.getX(), pos.getY(), pos.getZ(), 0x181820, 1.5f);
                if (n[0] % 2 == 0) w.spawnParticle(Particle.CRIT, pos, 1, 0.15, 0.1, 0.15, 0.0);
                if (tg != null && len < 1.4 && cd[0] <= 0) {
                    cd[0] = 5;
                    left[0]--;
                    pureHit(p, tg, dmg);
                    tg.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, false, false));
                    w.playSound(pos, Sound.ENTITY_PARROT_FLY, 0.6f, 1.6f);
                }
            }, 0L, 2L);
            dq.addLast(ref[0]);
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PARROT_AMBIENT, 0.8f, 0.6f);
        msg(p, ChatColor.GREEN + s.name + ": " + spawn + "마리 (최대 " + cap + ")");
        return true;
    }

    private boolean doPlant(Player p, SkillDef s, int lv, LivingEntity forced, boolean quiet) {
        final UUID id = p.getUniqueId();
        BukkitTask old = plants.remove(id); // 덩굴은 한 종류만
        if (old != null) old.cancel();
        final String type = s.sec.getString("plant-type", "poison");
        final Location pos = summonSpot(p, val(p, s, "range", lv, 10.0), forced).clone();
        final long end = System.currentTimeMillis() + (long) (val(p, s, "plant-seconds", lv, 30.0) * 1000.0);
        final double dps = val(p, s, "poison-dps", lv, 8.0);
        final double radius = radius(p, s, lv, 2.0);
        final double pct = val(p, s, "restore-pct", lv, 5.0);
        final double eatR = val(p, s, "eat-radius", lv, 8.0);
        final int[] n = {0};
        final BukkitTask[] ref = new BukkitTask[1];
        ref[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || p.isDead() || System.currentTimeMillis() > end || p.getWorld() != pos.getWorld()) {
                ref[0].cancel();
                plants.remove(id);
                return;
            }
            n[0]++;
            World w = pos.getWorld();
            int rgb = type.equals("solar") ? 0xE0C020 : type.equals("carrion") ? 0x90B030 : 0x30A030;
            for (int k = 0; k < 4; k++) {
                dust(w, pos.getX() + (random.nextDouble() - 0.5) * 0.5, pos.getY() + k * 0.35, pos.getZ() + (random.nextDouble() - 0.5) * 0.5, rgb, 1.4f);
            }
            if (type.equals("poison")) {
                LivingEntity tg = nearestTo(pos, 14.0, p);
                if (tg != null) {
                    Vector to = tg.getLocation().toVector().subtract(pos.toVector()).setY(0);
                    if (to.lengthSquared() > 1.0) {
                        Location nx = pos.clone().add(to.normalize().multiply(0.35));
                        if (nx.getBlock().isPassable()) pos.setX(nx.getX());
                        if (nx.getBlock().isPassable()) pos.setZ(nx.getZ());
                    }
                }
                if (n[0] % 4 == 0) addCloud(p, pos, radius, 3.0, dps, "poison");
                return;
            }
            if (n[0] % 4 != 0) return;
            long now = System.currentTimeMillis();
            Corpse best = null;
            double bd = Double.MAX_VALUE;
            for (Corpse c : corpses) {
                if (c.world != w || c.until < now) continue;
                double d = c.loc.distanceSquared(pos);
                if (d <= eatR * eatR && d < bd) {
                    bd = d;
                    best = c;
                }
            }
            if (best == null) return;
            corpses.remove(best);
            w.spawnParticle(Particle.HAPPY_VILLAGER, best.loc.clone().add(0, 0.5, 0), 12, 0.3, 0.3, 0.3, 0.0);
            w.playSound(pos, Sound.ENTITY_GENERIC_EAT, 0.8f, 0.7f);
            if (type.equals("solar")) {
                StatSystem ss = plugin.statSystem();
                double max = ss.maxMana(ss.collect(p));
                double cur = ss.getMana(p);
                if (cur < 0) cur = max;
                ss.setMana(p, Math.min(max, cur + max * pct / 100.0));
            } else {
                AttributeInstance mh = p.getAttribute(VersionCompat.MAX_HEALTH);
                healAlly(p, (mh == null ? 20.0 : mh.getValue()) * pct / 100.0);
            }
        }, 0L, 5L);
        plants.put(id, ref[0]);
        p.getWorld().playSound(pos, Sound.BLOCK_GRASS_PLACE, 1.0f, 0.6f);
        msg(p, ChatColor.GREEN + s.name + ": " + fmt(val(p, s, "plant-seconds", lv, 30.0)) + "초");
        return true;
    }

    private void describeDruidSummon(List<String> out, Player p, SkillDef s, int lv) {
        ConfigurationSection c = s.sec;
        if (s.kind.equals("animal")) {
            out.add(ChatColor.GREEN + "최대 " + (int) Math.max(1, val(p, s, "max-count", lv, 1)) + "마리, 생명력 " + fmt(val(p, s, "hp", lv, 0)) + ", 공격력 " + fmt(val(p, s, "damage", lv, 0)));
            out.add(ChatColor.GRAY + "모든 저항 " + fmt(Math.min(85.0, 5.0 * lv)) + "% (동물끼리 함께 소환 가능)");
            if (c.contains("slow-pct")) out.add(ChatColor.AQUA + "맞은 적 둔화 (냉기)");
            if (c.contains("stun-seconds")) out.add(ChatColor.GRAY + "맞은 적 기절 " + fmt(val(p, s, "stun-seconds", lv, 0)) + "초 + 밀쳐냄");
            if (c.getBoolean("eats-corpses", false)) out.add(ChatColor.YELLOW + "시체를 먹으면 20초 동안 피해 2배");
        }
        if (s.kind.equals("raven")) out.add(ChatColor.GREEN + "한 번에 " + (int) val(p, s, "count", lv, 1) + "마리 (최대 " + c.getInt("max-ravens", 5) + "), 마리당 " + (int) val(p, s, "attacks", lv, 0) + "번 공격 후 사라짐, 물리 " + fmt(val(p, s, "phys-damage", lv, 0)) + " + 실명");
        if (s.kind.equals("spirit")) out.add(ChatColor.GREEN + "반경 " + fmt(radius(p, s, lv, 16)) + "칸 아군에게 오라 (정령은 한 종류만 유지)");
        if (s.kind.equals("plant")) {
            out.add(ChatColor.GREEN + "지속 " + fmt(val(p, s, "plant-seconds", lv, 0)) + "초 (덩굴은 한 종류만 유지)");
            String pt = c.getString("plant-type", "poison");
            if (pt.equals("poison")) out.add(ChatColor.GREEN + "적을 따라가며 독 장판 (초당 " + fmt(val(p, s, "poison-dps", lv, 0)) + ")");
            else out.add(ChatColor.GREEN + "시체를 먹으면 " + (pt.equals("solar") ? "최대 마나" : "최대 생명력") + "의 " + fmt(val(p, s, "restore-pct", lv, 0)) + "% 회복");
        }
    }

}
