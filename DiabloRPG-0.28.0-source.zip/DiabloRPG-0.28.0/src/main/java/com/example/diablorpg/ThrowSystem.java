package com.example.diablorpg;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * 0.14.0: 투척 무기  [미검증]
 *
 *  - 종류는 config throwing.types (투척 단검 / 투척 도끼 / 투창). 일반 RPG 장비처럼 노말/매직/레어 옵션이 붙는다.
 *  - 직접 던지는 입력은 없다. 투척 무기를 손(1번 칸)에 들고 "투척 스킬"(예: 이중 투척)을 쓰면 SkillSystem 이 던진다.
 *  - 수량: 던질 때마다 줄고, 0이 돼도 아이템은 사라지지 않는다 (0이면 못 던짐). 상점의 "투척 무기 수리"로 최대 수량까지 다시 채운다.
 *  - 기본 피해는 만들 때 min~max 에서 굴려 손에 든 공격력(ATTACK_DAMAGE)에 반영된다. 스킬 피해 = 공격력 x 스킬 %.
 */
final class ThrowSystem {

    private final DiabloRPG plugin;
    private final NamespacedKey typeKey;
    private final NamespacedKey qtyKey;
    private final NamespacedKey maxKey;
    private final NamespacedKey uidKey;
    private final NamespacedKey dmgKey;

    ThrowSystem(DiabloRPG plugin) {
        this.plugin = plugin;
        this.typeKey = new NamespacedKey(plugin, "throw_type");
        this.qtyKey = new NamespacedKey(plugin, "throw_qty");
        this.maxKey = new NamespacedKey(plugin, "throw_max");
        this.uidKey = new NamespacedKey(plugin, "throw_uid");
        this.dmgKey = new NamespacedKey(plugin, "throw_dmg");
    }

    // ===================================================================
    //  종류 / 판별
    // ===================================================================

    Set<String> typeIds() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("throwing.types");
        return s == null ? Set.of() : s.getKeys(false);
    }

    boolean isTypeId(String id) {
        return typeIds().contains(id);
    }

    String typeOf(ItemStack it) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(typeKey, PersistentDataType.STRING);
    }

    boolean isThrowing(ItemStack it) {
        return typeOf(it) != null;
    }

    int quantity(ItemStack it) {
        if (!isThrowing(it)) return 0;
        Integer q = it.getItemMeta().getPersistentDataContainer().get(qtyKey, PersistentDataType.INTEGER);
        return q == null ? 0 : q;
    }

    int maxQuantity(ItemStack it) {
        if (!isThrowing(it)) return 0;
        Integer q = it.getItemMeta().getPersistentDataContainer().get(maxKey, PersistentDataType.INTEGER);
        return q == null ? 0 : q;
    }

    // ===================================================================
    //  아이템 만들기
    // ===================================================================

    /** 투척 무기 한 개를 만든다 (수량은 가득). rarity 는 normal/magic/rare. */
    ItemStack create(String type, String rarity) {
        ConfigurationSection t = plugin.getConfig().getConfigurationSection("throwing.types." + type);
        if (t == null) return null;
        Material mat = Material.matchMaterial(t.getString("material", "IRON_NUGGET"));
        if (mat == null || !mat.isItem()) mat = Material.IRON_NUGGET;
        ItemStack item = plugin.createItem(mat, rarity);
        if (item == null) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        int dmin = t.getInt("damage.min", 5);
        int dmax = Math.max(dmin, t.getInt("damage.max", dmin));
        int dmg = plugin.rollInt(dmin, dmax);
        int qty = Math.max(1, t.getInt("quantity", 40));

        String rarityName = plugin.getConfig().getString("rarities." + rarity + ".display", rarity);
        meta.setDisplayName(plugin.rarityColor(rarity) + rarityName + " " + t.getString("name", type));

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(typeKey, PersistentDataType.STRING, type);
        pdc.set(qtyKey, PersistentDataType.INTEGER, qty);
        pdc.set(maxKey, PersistentDataType.INTEGER, qty);
        pdc.set(uidKey, PersistentDataType.STRING, UUID.randomUUID().toString()); // 서로 합쳐지지 않게
        pdc.set(dmgKey, PersistentDataType.INTEGER, dmg);

        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        int at = Math.min(1, lore.size());
        lore.add(at, ChatColor.GRAY + "투척 무기 " + ChatColor.DARK_GRAY + "(스킬로 던진다)");
        lore.add(at + 1, qtyLine(qty, qty));
        lore.add(at + 2, ChatColor.GRAY + "기본 피해: " + ChatColor.WHITE + dmg);
        meta.setLore(lore);

        // 손에 들면 공격력/공격 속도에 반영된다 (스킬 피해 = 공격력 x 스킬 %)
        meta.addAttributeModifier(VersionCompat.ATTACK_DAMAGE, VersionCompat.modSlot(
                new NamespacedKey(plugin, "throw_damage"), dmg - 1.0,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        meta.addAttributeModifier(VersionCompat.ATTACK_SPEED, VersionCompat.modSlot(
                new NamespacedKey(plugin, "throw_speed"), t.getDouble("speed-modifier", -2.2),
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        item.setItemMeta(meta);
        return item;
    }

    /** 상점/참조용: "throw:종류" */
    ItemStack createFromRef(String ref) {
        if (!ref.startsWith("throw:")) return null;
        return create(ref.substring(6), "normal");
    }

    private String qtyLine(int q, int max) {
        ChatColor c = q <= 0 ? ChatColor.RED : ChatColor.WHITE;
        return ChatColor.GRAY + "수량: " + c + q + ChatColor.GRAY + " / " + max
                + (q <= 0 ? ChatColor.RED + "  (상점에서 수리)" : "");
    }

    // ===================================================================
    //  수량
    // ===================================================================

    /** 수량을 바꾸고(0~최대) 로어의 수량 줄을 갱신한다. item 을 직접 수정한다. */
    void setQuantity(ItemStack it, int q) {
        if (!isThrowing(it)) return;
        ItemMeta meta = it.getItemMeta();
        int max = maxQuantity(it);
        int nq = Math.max(0, Math.min(max, q));
        meta.getPersistentDataContainer().set(qtyKey, PersistentDataType.INTEGER, nq);
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        for (int i = 0; i < lore.size(); i++) {
            if (ChatColor.stripColor(lore.get(i)).startsWith("수량:")) {
                lore.set(i, qtyLine(nq, max));
                break;
            }
        }
        meta.setLore(lore);
        it.setItemMeta(meta);
    }

    /** 투척 무기의 기본 피해. (0.14.0 에서 만든 아이템은 PDC 가 없어서 공격력 속성 보정치에서 읽는다.) */
    double baseDamage(ItemStack it) {
        if (!isThrowing(it)) return 1.0;
        ItemMeta meta = it.getItemMeta();
        Integer d = meta.getPersistentDataContainer().get(dmgKey, PersistentDataType.INTEGER);
        if (d != null) return Math.max(1, d);
        java.util.Collection<AttributeModifier> mods = meta.getAttributeModifiers(VersionCompat.ATTACK_DAMAGE);
        if (mods != null) {
            for (AttributeModifier m : mods) {
                if ("throw_damage".equals(m.getKey().getKey())) return Math.max(1.0, m.getAmount() + 1.0);
            }
        }
        return 1.0;
    }

    /** 보조 손에 든 투척 무기의 수량을 n 줄인다. 모자라면 false. */
    boolean consumeOffHand(Player p, int n) {
        ItemStack off = p.getInventory().getItemInOffHand();
        if (!isThrowing(off)) return false;
        int q = quantity(off);
        if (q < n) return false;
        setQuantity(off, q - n);
        p.getInventory().setItemInOffHand(off);
        return true;
    }

    /** 손(주 손)에 든 투척 무기의 수량을 n 줄인다. 모자라면 false. */
    boolean consume(Player p, int n) {
        ItemStack held = p.getInventory().getItemInMainHand();
        if (!isThrowing(held)) return false;
        int q = quantity(held);
        if (q < n) return false;
        setQuantity(held, q - n);
        p.getInventory().setItemInMainHand(held);
        return true;
    }

    // ===================================================================
    //  수리 (상점)
    // ===================================================================

    private long unitPrice(String type) {
        return plugin.getConfig().getLong("throwing.types." + type + ".repair-per-unit", 2L);
    }

    private long repairCost(ItemStack it) {
        String type = typeOf(it);
        if (type == null) return 0L;
        int missing = maxQuantity(it) - quantity(it);
        return missing <= 0 ? 0L : missing * unitPrice(type);
    }

    /** 인벤토리(주 인벤토리 + 보조 손)에 있는 투척 무기 전부를 수리하는 데 드는 골드. */
    long repairCostAll(Player p) {
        long sum = 0L;
        PlayerInventory inv = p.getInventory();
        for (ItemStack it : inv.getStorageContents()) sum += repairCost(it);
        sum += repairCost(inv.getItemInOffHand());
        return sum;
    }

    /** 전부 최대 수량으로 채운다. 수리한 개수를 돌려준다. */
    int repairAll(Player p) {
        int n = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            if (isThrowing(it) && quantity(it) < maxQuantity(it)) {
                setQuantity(it, maxQuantity(it));
                inv.setItem(i, it);
                n++;
            }
        }
        ItemStack off = inv.getItemInOffHand();
        if (isThrowing(off) && quantity(off) < maxQuantity(off)) {
            setQuantity(off, maxQuantity(off));
            inv.setItemInOffHand(off);
            n++;
        }
        return n;
    }
}
