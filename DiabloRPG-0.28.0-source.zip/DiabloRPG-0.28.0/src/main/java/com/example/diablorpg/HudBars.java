package com.example.diablorpg;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;

/**
 * 체력/마나 이미지 바 (0.9.0). 리소스팩(DiabloRPG-HUD-ResourcePack)의 글꼴 diablorpg:hud 를 쓴다.  [미검증]
 *
 * 액션바는 화면 가운데 정렬이라, 전체 폭을 핫바 폭(182픽셀)에 맞춰 왼쪽에 체력, 오른쪽에 마나 바를 그린다.
 * 글꼴의 공백 글자(~: 음수, ~: 양수)로 픽셀 단위 이동을 한다.
 * 수치(폭 84, 글자 폭 5+1 간격)는 tools/make_hud_pack.py 와 같아야 한다.
 */
final class HudBars {

    private HudBars() {}

    static final String FONT = "diablorpg:hud";
    static final int STEPS = 42;
    static final int BAR_W = 84;
    static final int BAR_ADV = BAR_W + 1;     // 비트맵 글자의 이동 폭 = 그림 폭 + 1
    static final int HOTBAR_W = 182;
    static final int DIGIT_ADV = 6;           // 숫자 5픽셀 + 간격 1
    static final int MANA_X = HOTBAR_W - BAR_W; // 마나 바 시작 위치 (핫바 오른쪽 끝에 맞춤)

    /** px 만큼 이동 (음수면 뒤로). */
    private static void move(StringBuilder sb, int px) {
        if (px == 0) return;
        char base = px > 0 ? '' : '';
        int n = Math.abs(px);
        for (int i = 7; i >= 0; i--) {
            if ((n & (1 << i)) != 0) sb.append((char) (base + i));
        }
    }

    private static int step(double cur, double max) {
        if (max <= 0) return 0;
        double f = Math.max(0.0, Math.min(1.0, cur / max));
        int st = (int) Math.round(f * STEPS);
        if (cur > 0 && st == 0) st = 1;
        return st;
    }

    private static void bar(StringBuilder sb, char base, double cur, double max, String num, int slotX) {
        sb.append((char) (base + step(cur, max)));
        move(sb, -BAR_ADV);
        int textW = num.length() * DIGIT_ADV - 1;
        int pad = Math.max(0, (BAR_W - textW) / 2);
        move(sb, pad);
        sb.append(num);
        // 이 바가 끝난 뒤의 위치: 바 시작 + pad + 글자 폭
        // (호출한 쪽이 다음 위치까지의 간격을 계산할 수 있게 pad+글자 폭을 반환하는 대신 여기서 고정 규칙을 쓴다)
    }

    static BaseComponent[] build(double hp, double maxHp, double mana, double maxMana) {
        String hpNum = (int) Math.ceil(hp) + "/" + (int) Math.round(maxHp);
        String mpNum = (int) Math.floor(mana) + "/" + (int) Math.round(maxMana);

        StringBuilder sb = new StringBuilder();
        // 체력 바 (x = 0)
        bar(sb, '', hp, maxHp, hpNum, 0);
        int hpUsed = Math.max(0, (BAR_W - (hpNum.length() * DIGIT_ADV - 1)) / 2) + hpNum.length() * DIGIT_ADV;
        move(sb, MANA_X - hpUsed);
        // 마나 바 (x = MANA_X)
        bar(sb, '', mana, maxMana, mpNum, MANA_X);
        int mpUsed = Math.max(0, (BAR_W - (mpNum.length() * DIGIT_ADV - 1)) / 2) + mpNum.length() * DIGIT_ADV;
        move(sb, HOTBAR_W - (MANA_X + mpUsed)); // 전체 폭을 핫바 폭에 맞춘다 (가운데 정렬 기준)

        TextComponent t = new TextComponent(sb.toString());
        t.setFont(FONT);
        t.setColor(ChatColor.WHITE);
        return new BaseComponent[]{t};
    }
}
