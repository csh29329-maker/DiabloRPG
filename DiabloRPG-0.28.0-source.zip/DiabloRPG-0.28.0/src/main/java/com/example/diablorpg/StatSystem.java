package com.example.diablorpg;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLevelChangeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.List;
import java.util.Locale;

/**
 * 능력치(힘/민첩/활력/마력), 마나, 생명력 회복, 처치 시 회복 (0.6.1).
 *
 * 능력치는 장비 옵션으로만 올라간다 (레벨업으로 분배하는 시스템 없음). 합산 대상은
 * 방어구 4칸 + 보조 손 방패 + 주 손 무기(방어구/방패 제외) + 활성 세트 보너스.
 *
 *  - 힘:   근접 공격의 물리 피해 +N% (공격력 증가 %에 더해진다). 활/석궁에는 적용하지 않는다.
 *  - 민첩: 활/석궁 공격의 물리 피해 +N% 와 방어력 증가 +N%.
 *  - 활력: 최대 생명력 (플레이어 AttributeModifier, 0.5초마다 갱신).
 *  - 마력: 최대 마나.
 *  - 마나 증가 / 마나 회복 / 생명력 회복: 자원 및 초당 회복.
 *  - 적 처치 시 생명력 회복 / 적 처치 시 마나 회복: 적 처치 즉시 회복 (0.6.1).
 *
 * 모든 수치는 config.yml 의 stats / mana / life-regen / kill-recovery 섹션에서 조정한다.
 */
final class StatSystem implements Listener {

    /** 장비에서 합산한 능력치. */
    static final class Stats {
        double strength;
        double dexterity;
        double vitality;
        double energy;
        double manaFlat;     // 마나 증가 (최대 마나 고정 수치)
        double manaRegen;    // 마나 회복 (옵션 합, 초당)
        double lifeRegen;    // 생명력 회복 (옵션 합)
        double lifeOnKill;   // 적 처치 시 생명력 회복 (옵션 합, 0.6.1)
        double manaOnKill;   // 적 처치 시 마나 회복 (옵션 합, 0.6.1)
        double goldFindPct;  // 골드 획득량 % (옵션 합, 0.6.2)
        double magicFindPct; // 아이템 발견 확률 % (옵션 합, 0.6.2)
        double expGainPct;   // 경험치 획득 % (옵션 합, 0.6.3)
        double dodgePct;     // 회피 확률 % (옵션 합, 0.6.3)
        double lifeBase;     // 0.9.0: 직업/레벨 기준 최대 생명력 보정 (기본 체력 20에 더하는 값)
        double lifePerVit;   // 0.9.0: 활력 1당 생명력
        double manaBase;     // 0.9.0: 직업/레벨 기준 기본 마나
        double manaPerEnergy;// 0.9.0: 마력 1당 마나
    }

    private static final double TICK_SECONDS = 0.5; // tick() 주기 (10틱)

    private final DiabloRPG plugin;
    private final NamespacedKey manaKey;

    StatSystem(DiabloRPG plugin) {
        this.plugin = plugin;
        this.manaKey = new NamespacedKey(plugin, "mana_current");
    }

    void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 10L);
    }

    // ===================================================================
    //  합산
    // ===================================================================

    Stats collect(Player player) {
        Stats s = new Stats();
        initClassBase(player, s);
        PlayerInventory inv = player.getInventory();
        List<ItemStack> items = new ArrayList<>();
        for (ItemStack a : inv.getArmorContents()) items.add(a);
        ItemStack off = inv.getItemInOffHand();
        if (off != null && off.getType() == Material.SHIELD) items.add(off);
        ItemStack main = inv.getItemInMainHand();
        if (main != null && !isArmorOrShield(main.getType())) items.add(main);
        // 0.10.0: 장비창(장갑/목걸이/반지)
        if (plugin.equipSystem() != null) items.addAll(plugin.equipSystem().extraItems(player));

        for (ItemStack item : items) {
            if (item == null || item.getType().isAir() || !item.hasItemMeta()) continue;
            PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
            if (!pdc.has(plugin.rarityKey, PersistentDataType.STRING)) continue;
            add(s, pdc);
        }

        SetSystem.Bonus bonus = plugin.setSystem().bonusFor(player);
        if (bonus != null) add(s, bonus.pdc);
        // 0.7.0: 스킬(패시브/버프/오라)의 능력치 보너스
        PersistentDataContainer skillPdc = plugin.skillSystem() == null ? null : plugin.skillSystem().bonusPdc(player);
        if (skillPdc != null) add(s, skillPdc);
        // 0.8.0: 레벨업으로 분배한 능력치 포인트
        Alloc al = alloc(player);
        s.strength += al.str;
        s.dexterity += al.dex;
        s.vitality += al.vit;
        s.energy += al.ene;
        // 0.7.1: 전투 지시 - 최대 마나 %
        if (plugin.skillSystem() != null) {
            double pct = plugin.skillSystem().manaPct(player);
            if (pct != 0) {
                double base = s.manaBase + s.energy * s.manaPerEnergy + s.manaFlat;
                s.manaFlat += base * pct / 100.0;
            }
        }
        return s;
    }

    private void add(Stats s, PersistentDataContainer pdc) {
        s.strength += pdc.getOrDefault(plugin.strengthKey, PersistentDataType.DOUBLE, 0.0);
        s.dexterity += pdc.getOrDefault(plugin.dexterityKey, PersistentDataType.DOUBLE, 0.0);
        s.vitality += pdc.getOrDefault(plugin.vitalityKey, PersistentDataType.DOUBLE, 0.0);
        s.energy += pdc.getOrDefault(plugin.energyKey, PersistentDataType.DOUBLE, 0.0);
        s.manaFlat += pdc.getOrDefault(plugin.maxManaKey, PersistentDataType.DOUBLE, 0.0);
        s.manaRegen += pdc.getOrDefault(plugin.manaRegenKey, PersistentDataType.DOUBLE, 0.0);
        s.lifeRegen += pdc.getOrDefault(plugin.lifeRegenKey, PersistentDataType.DOUBLE, 0.0);
        s.lifeOnKill += pdc.getOrDefault(plugin.lifeOnKillKey, PersistentDataType.DOUBLE, 0.0);
        s.manaOnKill += pdc.getOrDefault(plugin.manaOnKillKey, PersistentDataType.DOUBLE, 0.0);
        s.goldFindPct += pdc.getOrDefault(plugin.goldFindKey, PersistentDataType.DOUBLE, 0.0);
        s.magicFindPct += pdc.getOrDefault(plugin.magicFindKey, PersistentDataType.DOUBLE, 0.0);
        s.expGainPct += pdc.getOrDefault(plugin.expGainKey, PersistentDataType.DOUBLE, 0.0);
        s.dodgePct += pdc.getOrDefault(plugin.dodgeChanceKey, PersistentDataType.DOUBLE, 0.0);
    }

    private boolean isArmorOrShield(Material m) {
        String n = m.name();
        return m == Material.SHIELD || m == Material.ELYTRA
                || n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE")
                || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS");
    }

    // ===================================================================
    //  능력치 -> 전투 수치 (config 로 조정)
    // ===================================================================

    /** 공격력 증가 %에 더할 값. 근접은 힘, 활/석궁은 민첩. */
    double attackPctBonus(Stats s, boolean ranged) {
        if (ranged) {
            return s.dexterity * plugin.getConfig().getDouble("stats.dexterity.ranged-phys-pct-per-point", 1.0);
        }
        return s.strength * plugin.getConfig().getDouble("stats.strength.melee-phys-pct-per-point", 1.0);
    }

    /** 방어력 증가 %에 더할 값 (민첩). */
    double defensePctBonus(Stats s) {
        return s.dexterity * plugin.getConfig().getDouble("stats.dexterity.defense-pct-per-point", 0.5);
    }

    double healthBonus(Stats s) {
        return s.lifeBase + s.vitality * s.lifePerVit;
    }

    double maxMana(Stats s) {
        return Math.max(0.0, s.manaBase + s.energy * s.manaPerEnergy + s.manaFlat);
    }

    /**
     * 0.9.0: 직업별 시작 체력/마나, 레벨당 증가, 활력/마력당 증가 (config class-stats.<직업 id>).
     *  체력 = 시작 체력 + (레벨-1) x 레벨당 + 활력 x 활력당   (마나도 같은 식)
     * 직업이 없거나 값이 없으면 예전 방식(기본 체력 20 + 활력 x stats.vitality, 기본 마나 mana.base + 마력 x ...)을 쓴다.
     * 레벨은 능력치 포인트와 같은 "최대 도달 레벨"이다.
     */
    private void initClassBase(Player player, Stats s) {
        s.lifeBase = 0.0;
        s.lifePerVit = plugin.getConfig().getDouble("stats.vitality.health-per-point", 2.0);
        s.manaBase = plugin.getConfig().getDouble("mana.base", 20.0);
        s.manaPerEnergy = plugin.getConfig().getDouble("stats.energy.mana-per-point", 2.0);
        if (plugin.skillSystem() == null) return;
        String cls = plugin.skillSystem().classOf(player);
        if (cls == null) return;
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("class-stats." + cls);
        if (c == null) return;
        int lv = Math.max(1, Math.min(alloc(player).maxLevel, levelCap()));
        double lifeScale = plugin.getConfig().getDouble("stats.class-life-scale", 1.0);
        double manaScale = plugin.getConfig().getDouble("stats.class-mana-scale", 1.0);
        double life = c.getDouble("start-life", 20.0) + c.getDouble("life-per-level", 0.0) * (lv - 1);
        s.lifeBase = life * lifeScale - 20.0;
        s.lifePerVit = c.getDouble("life-per-vitality", s.lifePerVit) * lifeScale;
        s.manaBase = (c.getDouble("start-mana", s.manaBase) + c.getDouble("mana-per-level", 0.0) * (lv - 1)) * manaScale;
        s.manaPerEnergy = c.getDouble("mana-per-energy", s.manaPerEnergy) * manaScale;
    }

    double manaRegenPerSec(Stats s) {
        return Math.max(0.0, plugin.getConfig().getDouble("mana.base-regen-per-sec", 0.5) + s.manaRegen);
    }

    double lifeRegenPerSec(Stats s) {
        return Math.max(0.0, s.lifeRegen * plugin.getConfig().getDouble("life-regen.per-point-per-sec", 0.2));
    }

    // ===================================================================
    //  마나 저장 (플레이어 PDC: 로그아웃/서버 재시작 후에도 유지)
    // ===================================================================

    double getMana(Player p) {
        Double v = p.getPersistentDataContainer().get(manaKey, PersistentDataType.DOUBLE);
        return v == null ? -1.0 : v; // -1 = 아직 초기화되지 않음 (최대치로 시작)
    }

    void setMana(Player p, double value) {
        p.getPersistentDataContainer().set(manaKey, PersistentDataType.DOUBLE, Math.max(0.0, value));
    }

    /** 0.6.4: 마나 흡수 등 즉시 마나 회복 (상한 maxMana, 실제 회복량 반환). */
    double addMana(Player p, double amount) {
        if (amount <= 0) return 0.0;
        Stats s = collect(p);
        double maxMana = maxMana(s);
        double cur = getMana(p);
        if (cur < 0) cur = maxMana;
        double next = Math.min(maxMana, cur + amount);
        double gained = Math.max(0.0, next - cur);
        setMana(p, next);
        AttributeInstance hpAttr = p.getAttribute(VersionCompat.MAX_HEALTH);
        double maxHp = hpAttr == null ? 20.0 : hpAttr.getValue();
        sendActionBar(p, p.getHealth(), maxHp, next, maxMana);
        return gained;
    }

    // ===================================================================
    //  적 처치 시 생명력/마나 회복 (0.6.1)
    // ===================================================================

    @EventHandler(ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity dead = event.getEntity();
        Player killer = dead.getKiller();
        if (killer == null || !killer.isOnline()) return;
        if (plugin.isDummy(dead)) return;

        Stats s = collect(killer);

        // 0.6.3: 경험치 획득 % (드롭 경험치가 있는 모든 엔티티에 적용 — Arclight 모드 몹 호환)
        int origExp = event.getDroppedExp();
        if (origExp > 0 && s.expGainPct > 0) {
            int nextExp = Math.max(origExp, (int) Math.round(origExp * (1.0 + s.expGainPct / 100.0)));
            event.setDroppedExp(nextExp);
            plugin.getLogger().info(String.format(Locale.ROOT,
                    "[경험치] %s <- %s | 기본 %d x (1 + %.0f%%) = %d",
                    killer.getName(), dead.getType().name(), origExp, s.expGainPct, nextExp));
        }

        if (killer.isDead()) return;
        if (plugin.getConfig().getBoolean("kill-recovery.hostile-only", true)
                && !(dead instanceof Enemy) && !(dead instanceof Player)) {
            return;
        }

        if (s.lifeOnKill <= 0 && s.manaOnKill <= 0) return;

        AttributeInstance hpAttr = killer.getAttribute(VersionCompat.MAX_HEALTH);
        double maxHp = hpAttr == null ? 20.0 : hpAttr.getValue();

        double lifeHealed = 0.0;
        if (s.lifeOnKill > 0 && !plugin.isHealBlocked(killer)) {
            double perPoint = plugin.getConfig().getDouble("kill-recovery.life-per-point", 1.0);
            double heal = Math.max(0.0, s.lifeOnKill * perPoint);
            if (heal > 0 && killer.getHealth() < maxHp) {
                double next = Math.min(maxHp, killer.getHealth() + heal);
                lifeHealed = next - killer.getHealth();
                killer.setHealth(next);
            }
        }

        double maxMana = maxMana(s);
        double mana = getMana(killer);
        if (mana < 0) mana = maxMana;

        double manaGained = 0.0;
        if (s.manaOnKill > 0) {
            double perPoint = plugin.getConfig().getDouble("kill-recovery.mana-per-point", 1.0);
            double gain = Math.max(0.0, s.manaOnKill * perPoint);
            if (gain > 0 && mana < maxMana) {
                double next = Math.min(maxMana, mana + gain);
                manaGained = next - mana;
                mana = next;
                setMana(killer, mana);
            }
        }

        if (lifeHealed > 0 || manaGained > 0) {
            sendActionBar(killer, killer.getHealth(), maxHp, mana, maxMana);
            plugin.getLogger().info(String.format(Locale.ROOT,
                    "[처치 회복] %s <- %s | 생명력 +%.1f (옵션 %.0f) | 마나 +%.1f (옵션 %.0f)",
                    killer.getName(), dead.getType().name(), lifeHealed, s.lifeOnKill, manaGained, s.manaOnKill));
        }
    }

    // ===================================================================
    //  0.5초마다: 활력 -> 최대 생명력, 마나/생명력 회복, 액션바
    // ===================================================================

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isDead()) continue;
            if (hungerLocked()) {
                int lock = Math.max(7, plugin.getConfig().getInt("hunger.level", 19));
                if (p.getFoodLevel() != lock) p.setFoodLevel(lock);
            }
            Stats s = collect(p);
            setModifier(p, VersionCompat.MAX_HEALTH, "stat_vitality_health", healthBonus(s),
                    AttributeModifier.Operation.ADD_NUMBER);

            // 0.6.4: 빙결 방지 착용 시 가루눈 빙결 누적 즉시 해제
            if (p.getFreezeTicks() > 0 && plugin.hasCannotFreeze(p)) {
                p.setFreezeTicks(0);
            }

            // 생명력 회복 (0.6.4: 회복 저지 / 상처 열기 상태면 차단)
            AttributeInstance hpAttr = p.getAttribute(VersionCompat.MAX_HEALTH);
            double maxHp = hpAttr == null ? 20.0 : hpAttr.getValue();
            double lifeRegen = lifeRegenPerSec(s);
            if (lifeRegen > 0 && p.getHealth() < maxHp && !plugin.isHealBlocked(p)) {
                p.setHealth(Math.min(maxHp, p.getHealth() + lifeRegen * TICK_SECONDS));
            }

            // 마나
            double maxMana = maxMana(s);
            double mana = getMana(p);
            if (mana < 0) mana = maxMana; // 처음에는 가득 찬 상태
            mana = Math.min(maxMana, mana + manaRegenPerSec(s) * TICK_SECONDS);
            setMana(p, mana);

            sendActionBar(p, p.getHealth(), maxHp, mana, maxMana);
        }
    }

    private final Map<UUID, Long> hudHold = new HashMap<>();

    /** 액션바 안내 메시지. 잠깐 동안(2.5초) 체력/마나 바 갱신을 멈춰서 글이 보이게 한다. */
    void notice(Player p, String text) {
        hudHold.put(p.getUniqueId(), System.currentTimeMillis() + 2500L);
        VersionCompat.actionBar(p, text);
    }

    private void sendActionBar(Player p, double hp, double maxHp, double mana, double maxMana) {
        if (!plugin.getConfig().getBoolean("mana.actionbar", true)) return;
        Long hold = hudHold.get(p.getUniqueId());
        if (hold != null) {
            if (hold > System.currentTimeMillis()) return;
            hudHold.remove(p.getUniqueId());
        }
        boolean textMode = alloc(p).hudText || "text".equalsIgnoreCase(plugin.getConfig().getString("hud.mode", "bars"));
        if (!textMode) {
            VersionCompat.actionBar(p, HudBars.build(hp, maxHp, mana, maxMana));
            return;
        }
        StringBuilder text = new StringBuilder();
        text.append(ChatColor.RED).append("생명력 ").append((int) Math.ceil(hp)).append("/").append((int) Math.round(maxHp))
            .append(ChatColor.GRAY).append("   ")
            .append(ChatColor.AQUA).append("마나 ").append((int) Math.floor(mana)).append("/").append((int) Math.round(maxMana));
        VersionCompat.actionBar(p, text.toString());
    }

    // ===================================================================
    //  허기 고정 (0.9.0): 음식 수치를 항상 hunger.level(19, 반 칸 닳은 상태)로 고정하고 자연회복을 막는다.
    //  (음식 수치 18 이상이면 마크가 자연회복을 하기 때문에, 그 회복 이벤트를 막는다. 생명력 회복은 우리 시스템만 쓴다.)
    // ===================================================================

    private boolean hungerLocked() {
        return plugin.getConfig().getBoolean("hunger.lock", true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFoodChange(FoodLevelChangeEvent e) {
        if (!hungerLocked() || !(e.getEntity() instanceof Player)) return;
        e.setFoodLevel(Math.max(7, plugin.getConfig().getInt("hunger.level", 19)));
    }

    @EventHandler(priority = org.bukkit.event.EventPriority.HIGH, ignoreCancelled = true)
    public void onNaturalRegen(EntityRegainHealthEvent e) {
        if (!hungerLocked() || !(e.getEntity() instanceof Player)) return;
        EntityRegainHealthEvent.RegainReason r = e.getRegainReason();
        if (r == EntityRegainHealthEvent.RegainReason.SATIATED || r == EntityRegainHealthEvent.RegainReason.REGEN) {
            e.setCancelled(true);
        }
    }

    private void setModifier(Player p, Attribute attribute, String keyName, double amount,
                             AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attribute);
        if (inst == null) return;
        NamespacedKey key = new NamespacedKey(plugin, keyName);
        AttributeModifier existing = null;
        for (AttributeModifier m : new ArrayList<>(inst.getModifiers())) {
            if (key.equals(m.getKey())) {
                existing = m;
                break;
            }
        }
        if (existing != null) {
            if (existing.getAmount() == amount && existing.getOperation() == op) return;
            inst.removeModifier(existing);
        }
        if (amount != 0.0) {
            inst.addModifier(VersionCompat.mod(key, amount, op));
        }
    }

    // ===================================================================
    //  레벨업 / 능력치 포인트 (0.8.0)  [미검증]
    //   - 캐릭터 레벨 = 마인크래프트 경험치 레벨. "지금까지 도달한 최대 레벨"을 기준으로 포인트를 준다
    //     (죽어서 레벨이 내려가도 이미 받은 포인트는 줄지 않는다).
    //   - 포인트 = (최대 도달 레벨 - 1) x points-per-level(5) + start-points + 관리자 지급
    //   - /rpgstat 창에서 힘/민첩/활력/마력에 투자한다. 효과는 기존 stats 설정 그대로.
    // ===================================================================

    static final class Alloc {
        int str;
        int dex;
        int vit;
        int ene;
        int bonus;
        int maxLevel = 1;
        boolean hudText; // 0.9.0: 글자 표시 모드 (리소스팩 없이 볼 때)
    }

    static final class StatHolder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final Map<UUID, Alloc> allocs = new HashMap<>();
    private NamespacedKey allocKey;

    private NamespacedKey allocKey() {
        if (allocKey == null) allocKey = new NamespacedKey(plugin, "stat_alloc");
        return allocKey;
    }

    Alloc alloc(Player p) {
        Alloc a = allocs.get(p.getUniqueId());
        if (a != null) return a;
        a = new Alloc();
        String raw = p.getPersistentDataContainer().get(allocKey(), PersistentDataType.STRING);
        if (raw != null) {
            for (String part : raw.split("\\|")) {
                int eq = part.indexOf('=');
                if (eq < 0) continue;
                try {
                    int v = Integer.parseInt(part.substring(eq + 1));
                    switch (part.substring(0, eq)) {
                        case "s" -> a.str = v;
                        case "d" -> a.dex = v;
                        case "v" -> a.vit = v;
                        case "e" -> a.ene = v;
                        case "b" -> a.bonus = v;
                        case "m" -> a.maxLevel = Math.max(1, v);
                        case "h" -> a.hudText = v != 0;
                        default -> { }
                    }
                } catch (NumberFormatException ignored) {
                    // 깨진 항목은 무시
                }
            }
        }
        allocs.put(p.getUniqueId(), a);
        return a;
    }

    private void saveAlloc(Player p) {
        Alloc a = allocs.get(p.getUniqueId());
        if (a == null) return;
        p.getPersistentDataContainer().set(allocKey(), PersistentDataType.STRING,
                "s=" + a.str + "|d=" + a.dex + "|v=" + a.vit + "|e=" + a.ene + "|b=" + a.bonus + "|m=" + a.maxLevel + "|h=" + (a.hudText ? 1 : 0));
    }

    private int levelCap() {
        return Math.max(1, plugin.getConfig().getInt("stats.level-cap", 99));
    }

    int statPointsTotal(Alloc a) {
        int per = plugin.getConfig().getInt("stats.points-per-level", 5);
        int start = plugin.getConfig().getInt("stats.start-points", 0);
        return start + per * Math.max(0, Math.min(a.maxLevel, levelCap()) - 1) + a.bonus;
    }

    int statPointsFree(Alloc a) {
        return statPointsTotal(a) - (a.str + a.dex + a.vit + a.ene);
    }

    /** 관리자 테스트용: 도달 레벨을 올린다 (포인트도 같이 늘어난다). */
    void adminSetMaxLevel(Player p, int level) {
        Alloc a = alloc(p);
        a.maxLevel = Math.max(a.maxLevel, level);
        saveAlloc(p);
    }

    @EventHandler
    public void onStatJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Alloc a = alloc(p);
        a.maxLevel = Math.max(a.maxLevel, Math.max(1, p.getLevel()));
        saveAlloc(p);
    }

    @EventHandler
    public void onStatQuit(PlayerQuitEvent e) {
        saveAlloc(e.getPlayer());
        allocs.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onLevelChange(PlayerLevelChangeEvent e) {
        Player p = e.getPlayer();
        Alloc a = alloc(p);
        int newLevel = e.getNewLevel();
        if (newLevel <= a.maxLevel) return;
        int cap = levelCap();
        int gained = Math.max(0, Math.min(newLevel, cap) - Math.min(a.maxLevel, cap));
        a.maxLevel = newLevel;
        saveAlloc(p);
        if (gained <= 0) return;
        int per = plugin.getConfig().getInt("stats.points-per-level", 5);
        if (plugin.getConfig().getBoolean("stats.level-up-message", true)) {
            p.sendMessage(ChatColor.GOLD + "★ 레벨 업! Lv " + newLevel + ChatColor.GRAY + "  능력치 포인트 +" + (gained * per)
                    + ", 스킬 포인트 +" + gained + ChatColor.YELLOW + "  (/rpgstat, /rpgskill)");
            notice(p, ChatColor.GOLD + "레벨 업! Lv " + newLevel + ChatColor.GRAY + "  능력치 포인트 " + statPointsFree(a));
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.2f);
        }
        if (plugin.getConfig().getBoolean("stats.level-up-full-restore", true)) {
            // 속성(최대 생명력)이 갱신될 시간을 한 틱 준 뒤 체력/마나를 가득 채운다.
            restoreFullLater(p);
        }
    }

    /** 생명력/마나를 가득 채운다 (최대치 속성이 갱신될 시간을 주려고 몇 틱 뒤에). */
    void restoreFullLater(Player p) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline() || p.isDead()) return;
            Stats st = collect(p);
            setModifier(p, VersionCompat.MAX_HEALTH, "stat_vitality_health", healthBonus(st),
                    AttributeModifier.Operation.ADD_NUMBER);
            AttributeInstance hp = p.getAttribute(VersionCompat.MAX_HEALTH);
            if (hp != null) p.setHealth(Math.min(hp.getValue(), Math.max(1.0, hp.getValue())));
            setMana(p, maxMana(st));
        }, 3L);
    }

    private ItemStack statIcon(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }

    void openGui(Player p) {
        StatHolder h = new StatHolder();
        h.inv = Bukkit.createInventory(h, 27, ChatColor.DARK_RED + "능력치");
        renderGui(p, h.inv);
        p.openInventory(h.inv);
    }

    private void renderGui(Player p, Inventory inv) {
        Alloc a = alloc(p);
        Stats eq = collect(p);
        int free = statPointsFree(a);
        int per = plugin.getConfig().getInt("stats.points-per-level", 5);
        inv.clear();

        List<String> info = new ArrayList<>();
        info.add(ChatColor.GRAY + "남은 포인트: " + ChatColor.GREEN + free + ChatColor.GRAY + " / 총 " + statPointsTotal(a));
        info.add(ChatColor.GRAY + "레벨 " + Math.max(1, p.getLevel()) + " (최대 도달 " + a.maxLevel + ")");
        info.add(ChatColor.GRAY + "레벨업마다 포인트 +" + per);
        info.add("");
        info.add(ChatColor.YELLOW + "좌클릭: +1   우클릭: +5");
        inv.setItem(4, statIcon(Material.NETHER_STAR, ChatColor.GOLD + "능력치 포인트", info));

        FileConfigurationShim cfg = new FileConfigurationShim(plugin);
        inv.setItem(10, statIcon(Material.IRON_SWORD, ChatColor.RED + "힘  " + ChatColor.WHITE + a.str,
                statLore(a.str, eq.strength, "근접 물리 피해 +" + cfg.fmt1(eq.strength * cfg.d("stats.strength.melee-phys-pct-per-point", 1.0)) + "%")));
        inv.setItem(12, statIcon(Material.BOW, ChatColor.GREEN + "민첩  " + ChatColor.WHITE + a.dex,
                statLore(a.dex, eq.dexterity, "활/석궁 물리 피해 +" + cfg.fmt1(eq.dexterity * cfg.d("stats.dexterity.ranged-phys-pct-per-point", 1.0))
                        + "%, 방어력 증가 +" + cfg.fmt1(defensePctBonus(eq)) + "%")));
        inv.setItem(14, statIcon(Material.GOLDEN_APPLE, ChatColor.LIGHT_PURPLE + "활력  " + ChatColor.WHITE + a.vit,
                statLore(a.vit, eq.vitality, "최대 생명력 +" + cfg.fmt1(eq.vitality * eq.lifePerVit))));
        inv.setItem(16, statIcon(Material.ENCHANTED_BOOK, ChatColor.AQUA + "마력  " + ChatColor.WHITE + a.ene,
                statLore(a.ene, eq.energy, "최대 마나 +" + cfg.fmt1(eq.energy * eq.manaPerEnergy))));

        List<String> rs = new ArrayList<>();
        rs.add(ChatColor.GRAY + "분배한 포인트를 모두 되돌립니다.");
        if (!plugin.getConfig().getBoolean("stats.allow-reset", true)) rs.add(ChatColor.RED + "초기화가 꺼져 있습니다. (관리자만)");
        inv.setItem(22, statIcon(Material.BARRIER, ChatColor.RED + "포인트 초기화", rs));
    }

    private List<String> statLore(int invested, double total, String effect) {
        List<String> l = new ArrayList<>();
        l.add(ChatColor.GRAY + "분배: " + ChatColor.WHITE + invested + ChatColor.GRAY + "   장비 포함 합계: " + ChatColor.WHITE + (int) Math.round(total));
        l.add(ChatColor.GRAY + "현재 효과: " + effect);
        l.add("");
        l.add(ChatColor.YELLOW + "좌클릭 +1 / 우클릭 +5");
        return l;
    }

    /** config 읽기 보조 (GUI 문구용). */
    private static final class FileConfigurationShim {
        private final DiabloRPG plugin;

        FileConfigurationShim(DiabloRPG plugin) {
            this.plugin = plugin;
        }

        double d(String path, double def) {
            return plugin.getConfig().getDouble(path, def);
        }

        String fmt1(double v) {
            return String.format(Locale.ROOT, "%.1f", v);
        }
    }

    private boolean invest(Player p, int which, int amount) {
        Alloc a = alloc(p);
        int free = statPointsFree(a);
        if (free <= 0) {
            notice(p, ChatColor.RED + "남은 포인트가 없습니다.");
            return false;
        }
        int n = Math.min(amount, free);
        switch (which) {
            case 0 -> a.str += n;
            case 1 -> a.dex += n;
            case 2 -> a.vit += n;
            default -> a.ene += n;
        }
        saveAlloc(p);
        return true;
    }

    @EventHandler
    public void onStatGuiClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof StatHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getInventory()) return;
        int slot = e.getSlot();
        ClickType ct = e.getClick();
        int amount = (ct == ClickType.RIGHT || ct == ClickType.SHIFT_RIGHT) ? 5
                : (ct == ClickType.LEFT || ct == ClickType.SHIFT_LEFT) ? 1 : 0;
        if (amount == 0) return;
        int which = switch (slot) {
            case 10 -> 0;
            case 12 -> 1;
            case 14 -> 2;
            case 16 -> 3;
            default -> -1;
        };
        if (which >= 0) {
            if (invest(p, which, amount)) renderGui(p, e.getInventory());
            return;
        }
        if (slot == 22) {
            if (!plugin.getConfig().getBoolean("stats.allow-reset", true) && !p.hasPermission("diablorpg.admin")) {
                notice(p, ChatColor.RED + "초기화가 허용되지 않습니다.");
                return;
            }
            Alloc a = alloc(p);
            a.str = 0;
            a.dex = 0;
            a.vit = 0;
            a.ene = 0;
            saveAlloc(p);
            renderGui(p, e.getInventory());
        }
    }

    @EventHandler
    public void onStatGuiDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof StatHolder) e.setCancelled(true);
    }

    private boolean handleStatSubcommand(Player p, String sub, String[] args) {
        Alloc a = alloc(p);
        switch (sub) {
            case "add" -> {
                if (args.length < 2) {
                    p.sendMessage(ChatColor.YELLOW + "사용법: /rpgstat add <str|dex|vit|ene> [개수]");
                    return true;
                }
                int which = switch (args[1].toLowerCase(Locale.ROOT)) {
                    case "str", "힘" -> 0;
                    case "dex", "민첩" -> 1;
                    case "vit", "활력" -> 2;
                    case "ene", "energy", "마력" -> 3;
                    default -> -1;
                };
                if (which < 0) {
                    p.sendMessage(ChatColor.RED + "str / dex / vit / ene 중 하나를 쓰세요.");
                    return true;
                }
                int n = 1;
                if (args.length >= 3) {
                    try {
                        n = Math.max(1, Integer.parseInt(args[2]));
                    } catch (NumberFormatException ex) {
                        p.sendMessage(ChatColor.RED + "개수는 숫자로 쓰세요.");
                        return true;
                    }
                }
                if (invest(p, which, n)) {
                    p.sendMessage(ChatColor.GREEN + "분배했습니다. 남은 포인트: " + statPointsFree(a));
                }
                return true;
            }
            case "hud" -> {
                a.hudText = !a.hudText;
                saveAlloc(p);
                p.sendMessage(ChatColor.YELLOW + "체력/마나 표시: " + (a.hudText ? "글자 모드" : "이미지 바 모드(리소스팩 필요)"));
                return true;
            }
            case "reset" -> {
                if (!plugin.getConfig().getBoolean("stats.allow-reset", true) && !p.hasPermission("diablorpg.admin")) {
                    p.sendMessage(ChatColor.RED + "초기화가 허용되지 않습니다.");
                    return true;
                }
                a.str = 0;
                a.dex = 0;
                a.vit = 0;
                a.ene = 0;
                saveAlloc(p);
                p.sendMessage(ChatColor.YELLOW + "능력치 포인트를 초기화했습니다. 남은 포인트: " + statPointsFree(a));
                return true;
            }
            case "give", "level" -> {
                if (!p.hasPermission("diablorpg.admin")) {
                    p.sendMessage(ChatColor.RED + "권한이 없습니다.");
                    return true;
                }
                if (args.length < 2) {
                    p.sendMessage(ChatColor.YELLOW + "사용법: /rpgstat " + sub + " <숫자>");
                    return true;
                }
                try {
                    int v = Integer.parseInt(args[1]);
                    if (sub.equals("give")) a.bonus += v;
                    else a.maxLevel = Math.max(a.maxLevel, v);
                } catch (NumberFormatException ex) {
                    p.sendMessage(ChatColor.RED + "숫자를 입력하세요.");
                    return true;
                }
                saveAlloc(p);
                p.sendMessage(ChatColor.YELLOW + "능력치 포인트: 남은 " + statPointsFree(a) + " / 총 " + statPointsTotal(a)
                        + ChatColor.GRAY + " (최대 도달 레벨 " + a.maxLevel + ", 관리자 지급 " + a.bonus + ")");
                return true;
            }
            default -> {
                p.sendMessage(ChatColor.YELLOW + "/rpgstat [info|add|reset|hud|give|level|setmana]");
                return true;
            }
        }
    }

    // ===================================================================
    //  /rpgstat            내 능력치와 파생 수치 확인
    //  /rpgstat setmana N  (관리자) 현재 마나를 N으로 설정 (회복 테스트용)
    // ===================================================================

    boolean handleCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(ChatColor.YELLOW + "플레이어만 사용할 수 있습니다.");
            return true;
        }
        if (args.length == 0) {
            openGui(p);
            return true;
        }
        String sub0 = args[0].toLowerCase(Locale.ROOT);
        if (!sub0.equals("info") && !sub0.equals("setmana")) {
            return handleStatSubcommand(p, sub0, args);
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("setmana")) {
            if (!sender.hasPermission("diablorpg.admin")) {
                sender.sendMessage(ChatColor.RED + "권한이 없습니다.");
                return true;
            }
            if (args.length != 2) {
                sender.sendMessage(ChatColor.YELLOW + "사용법: /rpgstat setmana <수치>");
                return true;
            }
            try {
                setMana(p, Double.parseDouble(args[1]));
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "숫자를 입력하세요.");
                return true;
            }
            sender.sendMessage(ChatColor.GREEN + "현재 마나를 " + args[1] + "(으)로 설정했습니다.");
            return true;
        }

        Stats s = collect(p);
        AttributeInstance hpAttr = p.getAttribute(VersionCompat.MAX_HEALTH);
        double mana = getMana(p);
        double maxMana = maxMana(s);
        if (mana < 0) mana = maxMana;

        p.sendMessage(ChatColor.GOLD + "=== 능력치 ===");
        p.sendMessage(String.format(Locale.ROOT, "%s힘 %.0f%s  (근접 물리 피해 +%.1f%%)",
                ChatColor.WHITE, s.strength, ChatColor.GRAY, attackPctBonus(s, false)));
        p.sendMessage(String.format(Locale.ROOT, "%s민첩 %.0f%s  (활/석궁 물리 피해 +%.1f%%, 방어력 증가 +%.1f%%)",
                ChatColor.WHITE, s.dexterity, ChatColor.GRAY, attackPctBonus(s, true), defensePctBonus(s)));
        p.sendMessage(String.format(Locale.ROOT, "%s활력 %.0f%s  (최대 생명력 +%.1f)",
                ChatColor.WHITE, s.vitality, ChatColor.GRAY, s.vitality * s.lifePerVit));
        p.sendMessage(String.format(Locale.ROOT, "%s마력 %.0f%s  (최대 마나 +%.1f)",
                ChatColor.WHITE, s.energy, ChatColor.GRAY,
                s.energy * s.manaPerEnergy));
        p.sendMessage(String.format(Locale.ROOT, "%s마나 %.1f / %.1f  (초당 회복 %.2f)",
                ChatColor.AQUA, mana, maxMana, manaRegenPerSec(s)));
        p.sendMessage(String.format(Locale.ROOT, "%s생명력 %.1f / %.1f  (옵션 회복 초당 %.2f)",
                ChatColor.RED, p.getHealth(), hpAttr == null ? 20.0 : hpAttr.getValue(), lifeRegenPerSec(s)));
        p.sendMessage(String.format(Locale.ROOT, "%s처치 시 회복%s  생명력 +%.0f / 마나 +%.0f",
                ChatColor.GREEN, ChatColor.GRAY, s.lifeOnKill, s.manaOnKill));
        p.sendMessage(String.format(Locale.ROOT, "%s골드 획득량 +%.0f%%%s  |  %s아이템 발견 확률 +%.0f%%",
                ChatColor.GOLD, s.goldFindPct, ChatColor.GRAY, ChatColor.YELLOW, s.magicFindPct));
        double dodgeCap = plugin.getConfig().getDouble("dodge.max", 75.0);
        double effectiveDodge = Math.max(0.0, Math.min(dodgeCap, s.dodgePct));
        String freezeState = plugin.hasCannotFreeze(p) ? ChatColor.AQUA + "빙결 방지: 활성" : ChatColor.GRAY + "빙결 방지: 없음";
        p.sendMessage(String.format(Locale.ROOT, "%s경험치 획득 +%.0f%%%s  |  %s회피 확률 %.0f%% (상한 %.0f%%)%s  |  %s",
                ChatColor.LIGHT_PURPLE, s.expGainPct, ChatColor.GRAY, ChatColor.WHITE, effectiveDodge, dodgeCap,
                ChatColor.GRAY, freezeState));
        return true;
    }
}
