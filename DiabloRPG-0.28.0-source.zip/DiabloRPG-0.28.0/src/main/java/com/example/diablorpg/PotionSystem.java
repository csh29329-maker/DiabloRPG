package com.example.diablorpg;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * 0.11.0: 물약  [미검증]
 *
 *  종류: healing(체력, 몇 초에 걸쳐 회복) / mana(마나, 몇 초에 걸쳐 회복) / rejuv(활력, 체력+마나 최대치의 %를 즉시 회복)
 *  등급: 1~4 (작은 / 보통 / 큰 / 최상급), 수치는 config potions 섹션.
 *  보관: 장비창(/rpgequip)의 물약 줄. 칸 수는 벨트(바지 칸)가 정한다 (벨트 없음 = equip.base-potion-slots).
 *  마시기: /rpgpotion <번호>, 장비창에서 물약 우클릭, 또는 손에 들고 우클릭(마시기 동작).
 *  벨트 물약을 마시면 인벤토리에 같은 물약이 있을 때 한 개가 그 칸으로 자동 보충된다 (potions.refill-from-inventory).
 *
 * 0.12.0: 자동 마시기  [미검증]
 *  체력/마나가 플레이어가 정한 % 밑으로 내려가면 벨트 물약을 알아서 마신다. 기준 %와 켜고 끄기는 장비창 버튼(좌클릭 +, 우클릭 -).
 *  평소: 부족한 양에 맞는 가장 작은 등급부터. 위험(체력 emergency-life-pct 밑): 활력 물약(없으면 가장 큰 체력 물약)부터.
 *  이미 회복 중이면(몇 초에 걸친 물약) 위험 수준이 아닌 한 또 마시지 않는다.
 */
final class PotionSystem implements Listener {

    static final String[] KINDS = {"healing", "mana", "rejuv"};
    private static final int STEP_TICKS = 5;

    private final DiabloRPG plugin;
    private final NamespacedKey kindKey;
    private final NamespacedKey tierKey;
    private final Random random = new Random();
    private final Map<UUID, Long> lastDrink = new HashMap<>();
    private final Map<UUID, Long> lastAuto = new HashMap<>();
    private final Map<UUID, Long> healUntil = new HashMap<>();
    private final Map<UUID, Long> manaUntil = new HashMap<>();
    private final NamespacedKey autoOnKey;
    private final NamespacedKey autoLifeKey;
    private final NamespacedKey autoManaKey;

    PotionSystem(DiabloRPG plugin) {
        this.plugin = plugin;
        this.kindKey = new NamespacedKey(plugin, "potion_kind");
        this.tierKey = new NamespacedKey(plugin, "potion_tier");
        this.autoOnKey = new NamespacedKey(plugin, "potion_auto_on");
        this.autoLifeKey = new NamespacedKey(plugin, "potion_auto_life");
        this.autoManaKey = new NamespacedKey(plugin, "potion_auto_mana");
    }

    void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) autoCheck(p);
        }, 20L, 5L);
    }

    // ===================================================================
    //  자동 마시기 설정 (플레이어별, PDC)
    // ===================================================================

    boolean autoMaster() {
        return plugin.getConfig().getBoolean("potions.auto.enabled", true);
    }

    boolean isAutoOn(Player p) {
        Byte v = p.getPersistentDataContainer().get(autoOnKey, PersistentDataType.BYTE);
        if (v == null) return plugin.getConfig().getBoolean("potions.auto.default-on", true);
        return v != 0;
    }

    void toggleAuto(Player p) {
        p.getPersistentDataContainer().set(autoOnKey, PersistentDataType.BYTE, (byte) (isAutoOn(p) ? 0 : 1));
    }

    int autoLifePct(Player p) {
        Integer v = p.getPersistentDataContainer().get(autoLifeKey, PersistentDataType.INTEGER);
        return v != null ? v : plugin.getConfig().getInt("potions.auto.default-life-pct", 40);
    }

    int autoManaPct(Player p) {
        Integer v = p.getPersistentDataContainer().get(autoManaKey, PersistentDataType.INTEGER);
        return v != null ? v : plugin.getConfig().getInt("potions.auto.default-mana-pct", 20);
    }

    int autoStep() {
        return Math.max(1, plugin.getConfig().getInt("potions.auto.step-pct", 5));
    }

    /** 기준 %를 한 칸(step) 올리거나(sign>0) 내린다. 범위 0~90. */
    void adjustAuto(Player p, boolean life, int sign) {
        int cur = life ? autoLifePct(p) : autoManaPct(p);
        int next = Math.max(0, Math.min(90, cur + sign * autoStep()));
        p.getPersistentDataContainer().set(life ? autoLifeKey : autoManaKey, PersistentDataType.INTEGER, next);
    }

    // ===================================================================
    //  아이템
    // ===================================================================

    static boolean isKind(String k) {
        for (String s : KINDS) if (s.equals(k)) return true;
        return false;
    }

    private String kindName(String kind) {
        return switch (kind) {
            case "healing" -> "체력 물약";
            case "mana" -> "마나 물약";
            default -> "활력 물약";
        };
    }

    private String tierName(int tier) {
        List<String> names = plugin.getConfig().getStringList("potions.tier-names");
        if (names.size() >= tier) return names.get(tier - 1);
        return switch (tier) {
            case 1 -> "작은";
            case 2 -> "보통";
            case 3 -> "큰";
            default -> "최상급";
        };
    }

    private ChatColor colorOf(String kind) {
        return switch (kind) {
            case "healing" -> ChatColor.RED;
            case "mana" -> ChatColor.BLUE;
            default -> ChatColor.LIGHT_PURPLE;
        };
    }

    private Color rgbOf(String kind) {
        return switch (kind) {
            case "healing" -> Color.fromRGB(200, 30, 40);
            case "mana" -> Color.fromRGB(40, 80, 220);
            default -> Color.fromRGB(170, 60, 200);
        };
    }

    int maxTier() { return 4; }

    /** 설정 배열에서 값 읽기 (등급 1~4). 없으면 fallback. */
    private double value(String path, int tier, double fallback) {
        List<Double> list = plugin.getConfig().getDoubleList(path);
        if (list.size() >= tier) return list.get(tier - 1);
        return fallback;
    }

    private String describe(String kind, int tier) {
        if (kind.equals("rejuv")) {
            return "체력/마나 " + fmt(value("potions.rejuv.percent", tier, 35)) + "% 즉시 회복";
        }
        String what = kind.equals("healing") ? "체력" : "마나";
        double amt = value("potions." + kind + ".amount", tier, 50);
        double sec = value("potions." + kind + ".seconds", tier, 4);
        return what + " " + fmt(amt) + " 회복 (" + fmt(sec) + "초에 걸쳐)";
    }

    private String fmt(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.ROOT, "%.1f", v);
    }

    ItemStack create(String kind, int tier, int amount) {
        if (!isKind(kind)) return null;
        tier = Math.max(1, Math.min(maxTier(), tier));
        Material mat = Material.matchMaterial(plugin.getConfig().getString("potions.material", "POTION"));
        if (mat == null || !mat.isItem()) mat = Material.POTION;
        ItemStack item = new ItemStack(mat, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setDisplayName(colorOf(kind) + tierName(tier) + " " + kindName(kind));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + describe(kind, tier));
        lore.add(ChatColor.DARK_GRAY + "/rpgequip 물약 칸에 넣고 /rpgpotion 번호 로 마신다");
        meta.setLore(lore);
        if (meta instanceof PotionMeta pm) pm.setColor(rgbOf(kind));
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(kindKey, PersistentDataType.STRING, kind);
        pdc.set(tierKey, PersistentDataType.INTEGER, tier);
        item.setItemMeta(meta);
        return item;
    }

    /** "potion:healing:2" 형식 (상점 목록용). */
    ItemStack createFromRef(String ref) {
        String[] p = ref.split(":");
        if (p.length < 3) return null;
        try {
            return create(p[1], Integer.parseInt(p[2]), 1);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    boolean isPotion(ItemStack it) {
        return kindOf(it) != null;
    }

    String kindOf(ItemStack it) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(kindKey, PersistentDataType.STRING);
    }

    int tierOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return 1;
        Integer t = it.getItemMeta().getPersistentDataContainer().get(tierKey, PersistentDataType.INTEGER);
        return t == null ? 1 : t;
    }

    private boolean sameKind(ItemStack a, ItemStack b) {
        String ka = kindOf(a);
        return ka != null && ka.equals(kindOf(b)) && tierOf(a) == tierOf(b);
    }

    // ===================================================================
    //  드롭
    // ===================================================================

    /** 몬스터 처치 시 물약 한 개를 굴려서 돌려준다 (드롭 확률은 호출하는 쪽에서 판정). */
    ItemStack rollDrop(boolean boss) {
        double wh = plugin.getConfig().getDouble("potions.drop-kind-weights.healing", 45.0);
        double wm = plugin.getConfig().getDouble("potions.drop-kind-weights.mana", 35.0);
        double wr = plugin.getConfig().getDouble("potions.drop-kind-weights.rejuv", 8.0);
        double r = random.nextDouble() * (wh + wm + wr);
        String kind = r < wh ? "healing" : (r < wh + wm ? "mana" : "rejuv");

        List<Integer> w = plugin.getConfig().getIntegerList(boss ? "potions.drop-tier-weights.boss" : "potions.drop-tier-weights.mob");
        if (w.size() < 4) w = boss ? List.of(0, 30, 50, 20) : List.of(60, 28, 10, 2);
        int total = 0;
        for (int x : w) total += Math.max(0, x);
        int tier = 1;
        if (total > 0) {
            int roll = random.nextInt(total);
            int acc = 0;
            for (int i = 0; i < 4; i++) {
                acc += Math.max(0, w.get(i));
                if (roll < acc) {
                    tier = i + 1;
                    break;
                }
            }
        }
        return create(kind, tier, 1);
    }

    // ===================================================================
    //  마시기
    // ===================================================================

    /** 벨트 물약 칸 n(1부터)의 물약을 마신다. 마셨으면 true. */
    boolean drinkFromSlot(Player p, int n) {
        EquipSystem eq = plugin.equipSystem();
        int cap = eq.potionCapacity(p);
        if (n < 1 || n > cap) {
            p.sendMessage(ChatColor.RED + "물약 칸은 1~" + cap + "번까지 있습니다. (벨트를 끼면 칸이 늘어납니다)");
            return false;
        }
        ItemStack it = eq.getPotion(p, n);
        if (it == null) {
            p.sendMessage(ChatColor.GRAY + "물약 칸 " + n + "번이 비어 있습니다.");
            return false;
        }
        if (!applyPotion(p, it)) return false;

        // 소비 + 인벤토리에서 같은 물약 자동 보충
        ItemStack refill = null;
        if (plugin.getConfig().getBoolean("potions.refill-from-inventory", true)) {
            refill = takeSimilarFromInventory(p, it);
        }
        eq.setPotion(p, n, refill);
        return true;
    }

    // ===================================================================
    //  자동 마시기 판정
    // ===================================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamaged(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        // 피해가 반영된 다음 틱에 체력을 보고 판단한다.
        Bukkit.getScheduler().runTask(plugin, () -> autoCheck(p));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        lastDrink.remove(id);
        lastAuto.remove(id);
        healUntil.remove(id);
        manaUntil.remove(id);
    }

    private void autoCheck(Player p) {
        if (!autoMaster() || !p.isOnline() || p.isDead() || !isAutoOn(p)) return;
        long now = System.currentTimeMillis();
        Long la = lastAuto.get(p.getUniqueId());
        long cd = plugin.getConfig().getLong("potions.auto.cooldown-ms", 1500L);
        if (la != null && now - la < cd) return;

        EquipSystem eq = plugin.equipSystem();
        int cap = eq.potionCapacity(p);
        if (cap <= 0) return;

        AttributeInstance hpAttr = p.getAttribute(VersionCompat.MAX_HEALTH);
        double maxHp = hpAttr == null ? 20.0 : hpAttr.getValue();
        double hp = p.getHealth();
        double hpPct = maxHp <= 0 ? 100.0 : hp / maxHp * 100.0;

        // ----- 체력 -----
        int lifeT = autoLifePct(p);
        if (lifeT > 0 && hpPct < lifeT && !plugin.isHealBlocked(p)) {
            int emergencyPct = plugin.getConfig().getInt("potions.auto.emergency-life-pct", 15);
            boolean emergency = hpPct < emergencyPct;
            long until = healUntil.getOrDefault(p.getUniqueId(), 0L);
            if (until <= now || emergency) {
                int slot = pickSlot(p, cap, true, maxHp - hp, emergency);
                if (slot > 0 && drinkFromSlot(p, slot)) {
                    lastAuto.put(p.getUniqueId(), now);
                    return;
                }
            }
        }

        // ----- 마나 -----
        int manaT = autoManaPct(p);
        if (manaT > 0) {
            StatSystem ss = plugin.statSystem();
            double maxMana = ss.maxMana(ss.collect(p));
            double mana = ss.getMana(p);
            if (mana < 0) mana = maxMana;
            double manaPct = maxMana <= 0 ? 100.0 : mana / maxMana * 100.0;
            if (maxMana > 0 && manaPct < manaT) {
                long until = manaUntil.getOrDefault(p.getUniqueId(), 0L);
                if (until <= now) {
                    int slot = pickSlot(p, cap, false, maxMana - mana, false);
                    if (slot > 0 && drinkFromSlot(p, slot)) {
                        lastAuto.put(p.getUniqueId(), now);
                    }
                }
            }
        }
    }

    /**
     * 벨트에서 마실 칸 번호(1부터)를 고른다. 없으면 -1.
     *  life=true: 체력 / false: 마나. missing = 부족한 양.
     *  평소: 부족한 양의 60% 이상 채워 주는 가장 작은 등급, 없으면 가장 큰 등급. 해당 종류가 없으면 활력 물약(가장 작은 것).
     *  emergency: 활력 물약(가장 큰 것), 없으면 가장 큰 체력 물약.
     */
    private int pickSlot(Player p, int cap, boolean life, double missing, boolean emergency) {
        EquipSystem eq = plugin.equipSystem();
        String main = life ? "healing" : "mana";
        int bestMainSlot = -1, bestMainTier = -1;       // 가장 큰 등급
        int fitSlot = -1, fitTier = 99;                 // 부족분을 채우는 가장 작은 등급
        int rejLow = -1, rejLowTier = 99;
        int rejHigh = -1, rejHighTier = -1;
        for (int n = 1; n <= cap; n++) {
            ItemStack it = eq.getPotion(p, n);
            String kind = kindOf(it);
            if (kind == null) continue;
            int tier = tierOf(it);
            if (kind.equals(main)) {
                if (tier > bestMainTier) {
                    bestMainTier = tier;
                    bestMainSlot = n;
                }
                double amount = value("potions." + main + ".amount", tier, 50);
                if (amount >= missing * 0.6 && tier < fitTier) {
                    fitTier = tier;
                    fitSlot = n;
                }
            } else if (kind.equals("rejuv")) {
                if (tier < rejLowTier) {
                    rejLowTier = tier;
                    rejLow = n;
                }
                if (tier > rejHighTier) {
                    rejHighTier = tier;
                    rejHigh = n;
                }
            }
        }
        if (emergency) {
            if (rejHigh > 0) return rejHigh;
            return bestMainSlot;
        }
        if (fitSlot > 0) return fitSlot;
        if (bestMainSlot > 0) return bestMainSlot;
        return rejLow;
    }

    private ItemStack takeSimilarFromInventory(Player p, ItemStack like) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack c = contents[i];
            if (c == null || !sameKind(c, like)) continue;
            ItemStack one = c.clone();
            one.setAmount(1);
            if (c.getAmount() > 1) {
                c.setAmount(c.getAmount() - 1);
                inv.setItem(i, c);
            } else {
                inv.setItem(i, null);
            }
            return one;
        }
        return null;
    }

    /** 효과를 적용한다. 쿨다운/가득 참 등으로 못 마시면 false (아이템은 소비되지 않는다). */
    private boolean applyPotion(Player p, ItemStack it) {
        String kind = kindOf(it);
        if (kind == null) return false;
        int tier = tierOf(it);

        long now = System.currentTimeMillis();
        long cd = plugin.getConfig().getLong("potions.cooldown-ms", 400L);
        Long last = lastDrink.get(p.getUniqueId());
        if (last != null && now - last < cd) return false;

        AttributeInstance hpAttr = p.getAttribute(VersionCompat.MAX_HEALTH);
        double maxHp = hpAttr == null ? 20.0 : hpAttr.getValue();
        StatSystem ss = plugin.statSystem();
        double maxMana = ss.maxMana(ss.collect(p));
        double curMana = ss.getMana(p);
        if (curMana < 0) curMana = maxMana;
        boolean hpFull = p.getHealth() >= maxHp - 0.01;
        boolean manaFull = curMana >= maxMana - 0.01;

        if (kind.equals("healing") && hpFull) {
            p.sendMessage(ChatColor.GRAY + "체력이 이미 가득합니다.");
            return false;
        }
        if (kind.equals("mana") && manaFull) {
            p.sendMessage(ChatColor.GRAY + "마나가 이미 가득합니다.");
            return false;
        }
        if (kind.equals("rejuv") && hpFull && manaFull) {
            p.sendMessage(ChatColor.GRAY + "체력과 마나가 이미 가득합니다.");
            return false;
        }
        lastDrink.put(p.getUniqueId(), now);

        switch (kind) {
            case "healing" -> startOverTime(p, true, value("potions.healing.amount", tier, 45),
                    value("potions.healing.seconds", tier, 4));
            case "mana" -> startOverTime(p, false, value("potions.mana.amount", tier, 40),
                    value("potions.mana.seconds", tier, 4));
            default -> {
                double pct = value("potions.rejuv.percent", tier, 35) / 100.0;
                if (!plugin.isHealBlocked(p)) {
                    p.setHealth(Math.min(maxHp, p.getHealth() + maxHp * pct));
                }
                ss.addMana(p, maxMana * pct);
            }
        }
        p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.8f, 1.0f);
        return true;
    }

    private void startOverTime(Player p, boolean life, double amount, double seconds) {
        int steps = Math.max(1, (int) Math.round(seconds * 20.0 / STEP_TICKS));
        (life ? healUntil : manaUntil).put(p.getUniqueId(), System.currentTimeMillis() + (long) (seconds * 1000.0));
        double each = amount / steps;
        final BukkitTask[] holder = new BukkitTask[1];
        final int[] done = {0};
        holder[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || p.isDead()) {
                holder[0].cancel();
                return;
            }
            if (life) {
                if (!plugin.isHealBlocked(p)) {
                    AttributeInstance a = p.getAttribute(VersionCompat.MAX_HEALTH);
                    double max = a == null ? 20.0 : a.getValue();
                    p.setHealth(Math.min(max, p.getHealth() + each));
                }
            } else {
                plugin.statSystem().addMana(p, each);
            }
            if (++done[0] >= steps) holder[0].cancel();
        }, 0L, STEP_TICKS);
    }

    /** 손에 든 물약을 마시려 할 때 (우클릭 마시기 동작): 바닐라 마시기를 막고 우리 효과로 대신한다. */
    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        ItemStack item = e.getItem();
        if (!isPotion(item)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        PlayerInventory inv = p.getInventory();
        ItemStack main = inv.getItemInMainHand();
        boolean fromMain = isPotion(main) && sameKind(main, item);
        ItemStack held = fromMain ? main : inv.getItemInOffHand();
        if (!isPotion(held)) return;
        if (!applyPotion(p, held)) return;
        if (held.getAmount() > 1) {
            held.setAmount(held.getAmount() - 1);
        } else if (fromMain) {
            inv.setItemInMainHand(null);
        } else {
            inv.setItemInOffHand(null);
        }
    }

    // ===================================================================
    //  명령어: /rpgpotion <번호> | give <플레이어> <종류> <등급> [개수] | (인자 없음) 목록
    // ===================================================================

    boolean handleCommand(CommandSender sender, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("diablorpg.admin")) {
                sender.sendMessage(ChatColor.RED + "권한이 없습니다.");
                return true;
            }
            if (args.length < 4) {
                sender.sendMessage(ChatColor.YELLOW + "사용법: /rpgpotion give <플레이어> <healing|mana|rejuv> <1~4> [개수]");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "플레이어를 찾을 수 없습니다.");
                return true;
            }
            String kind = args[2].toLowerCase(Locale.ROOT);
            if (!isKind(kind)) {
                sender.sendMessage(ChatColor.RED + "종류: healing(체력), mana(마나), rejuv(활력)");
                return true;
            }
            int tier;
            int amount = 1;
            try {
                tier = Integer.parseInt(args[3]);
                if (args.length >= 5) amount = Math.max(1, Math.min(64, Integer.parseInt(args[4])));
            } catch (NumberFormatException ex) {
                sender.sendMessage(ChatColor.RED + "등급과 개수는 숫자로 입력하세요.");
                return true;
            }
            ItemStack it = create(kind, tier, amount);
            target.getInventory().addItem(it).values().forEach(left ->
                    target.getWorld().dropItemNaturally(target.getLocation(), left));
            sender.sendMessage(ChatColor.GREEN + target.getName() + "에게 " + it.getItemMeta().getDisplayName()
                    + ChatColor.GREEN + " x" + amount + " 지급");
            return true;
        }

        if (!(sender instanceof Player p)) {
            sender.sendMessage("플레이어만 쓸 수 있습니다.");
            return true;
        }
        if (args.length == 0) {
            EquipSystem eq = plugin.equipSystem();
            int cap = eq.potionCapacity(p);
            p.sendMessage(ChatColor.GOLD + "[물약 칸] " + cap + "칸  (마시기: /rpgpotion 번호)");
            for (int n = 1; n <= cap; n++) {
                ItemStack it = eq.getPotion(p, n);
                String name = it == null ? ChatColor.DARK_GRAY + "(비어 있음)" : it.getItemMeta().getDisplayName();
                p.sendMessage(ChatColor.GRAY + " " + n + ". " + name);
            }
            return true;
        }
        int n;
        try {
            n = Integer.parseInt(args[0]);
        } catch (NumberFormatException ex) {
            p.sendMessage(ChatColor.YELLOW + "사용법: /rpgpotion <번호> 또는 /rpgpotion (목록)");
            return true;
        }
        drinkFromSlot(p, n);
        return true;
    }
}
