package com.example.diablorpg;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.lang.reflect.Method;

/**
 * 마인크래프트 버전마다 이름이 바뀌는 API 상수를 한 곳에 모은다.
 *
 * 1.21.1 API: Attribute.GENERIC_MAX_HEALTH 처럼 GENERIC_ 접두어가 붙어 있다.
 * 1.21.3 이상 API: 접두어가 빠져 Attribute.MAX_HEALTH 가 된다.
 * 대상 버전을 바꿀 때는 이 파일의 다섯 줄만 고치면 된다.
 */
final class VersionCompat {

    private VersionCompat() {}

    static final Attribute MAX_HEALTH = Attribute.GENERIC_MAX_HEALTH;
    static final Attribute ATTACK_SPEED = Attribute.GENERIC_ATTACK_SPEED;
    static final Attribute MOVEMENT_SPEED = Attribute.GENERIC_MOVEMENT_SPEED;
    static final Attribute ATTACK_DAMAGE = Attribute.GENERIC_ATTACK_DAMAGE;
    static final Attribute ARMOR = Attribute.GENERIC_ARMOR;
    static final Attribute KNOCKBACK_RESISTANCE = Attribute.GENERIC_KNOCKBACK_RESISTANCE;

    /**
     * 속성 보정치 생성. Spigot API 1.21.1 에는 (키, 값, 연산) 3개짜리 생성자가 없어서
     * 슬롯 그룹(ANY)을 붙인 4개짜리를 쓴다. (Paper 의 3개짜리와 같은 동작)
     */
    static AttributeModifier mod(NamespacedKey key, double amount, AttributeModifier.Operation op) {
        return new AttributeModifier(key, amount, op, EquipmentSlotGroup.ANY);
    }

    /** 장비 칸(주 손 등)에서만 켜지는 속성 보정치. (투척 무기의 공격력/공격 속도) */
    static AttributeModifier modSlot(NamespacedKey key, double amount, AttributeModifier.Operation op,
                                     EquipmentSlotGroup group) {
        return new AttributeModifier(key, amount, op, group);
    }

    // ------------------------------------------------------------------
    //  Paper 전용 API 대체 (0.7.6: Arclight 등 Spigot 기반 서버에서도 돌아가게)
    // ------------------------------------------------------------------

    /** 액션바 표시. Paper/Adventure 없이 Spigot(Bungee chat) API 로 보낸다. 색 코드는 § 형식. */
    static void actionBar(Player p, String legacyText) {
        p.spigot().sendMessage(net.md_5.bungee.api.ChatMessageType.ACTION_BAR,
                net.md_5.bungee.api.chat.TextComponent.fromLegacyText(legacyText));
    }

    /** 액션바에 컴포넌트(글꼴 이미지 등)를 그대로 보낸다. */
    static void actionBar(Player p, net.md_5.bungee.api.chat.BaseComponent... components) {
        p.spigot().sendMessage(net.md_5.bungee.api.ChatMessageType.ACTION_BAR, components);
    }

    private static Method pathfinderGetter;
    private static Method pathfinderMoveTo;
    private static boolean pathfinderChecked;

    /**
     * 몹을 목표 지점으로 걷게 한다.
     * Paper 의 Mob#getPathfinder() 가 있으면 그것을(리플렉션), 없으면(Spigot/Arclight) 속도 벡터로 밀어 이동시킨다.
     */
    static void moveMob(Mob m, Location target, double speed) {
        if (!pathfinderChecked) {
            pathfinderChecked = true;
            try {
                pathfinderGetter = Mob.class.getMethod("getPathfinder");
                pathfinderMoveTo = pathfinderGetter.getReturnType().getMethod("moveTo", Location.class, double.class);
            } catch (Throwable ignored) {
                pathfinderGetter = null;
                pathfinderMoveTo = null;
            }
        }
        if (pathfinderGetter != null && pathfinderMoveTo != null) {
            try {
                Object pf = pathfinderGetter.invoke(m);
                pathfinderMoveTo.invoke(pf, target, speed);
                return;
            } catch (Throwable ignored) {
                pathfinderGetter = null; // 이후부터는 대체 방식 사용
            }
        }
        Vector dir = target.toVector().subtract(m.getLocation().toVector());
        dir.setY(0);
        if (dir.lengthSquared() < 0.0001) return;
        dir.normalize().multiply(0.32 * Math.max(0.5, speed));
        dir.setY(m.isOnGround() ? 0.18 : m.getVelocity().getY());
        m.setVelocity(dir);
    }
}
