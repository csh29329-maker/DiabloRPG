package com.example.diablorpg;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * 0.10.0: 장비칸 확장  [미검증]  (0.11.0: 장비창에 벨트 물약 줄 추가)
 *
 *  - 벨트  = 마인크래프트 "바지" 칸. 그 칸에 낀 RPG 아이템은 벨트로 취급한다 (따로 처리할 게 없다: 기존 방어구 4칸 합산에 이미 들어 있음).
 *  - 장갑 / 목걸이 / 반지 2칸 = 플러그인 장비창(/rpgequip). 여기 넣은 아이템의 옵션이 능력치에 합산된다.
 *  - 무기 프리셋 = 장비창의 "무기 2 / 보조 2" 칸. /rpgswap 또는 장비창 버튼으로 손에 든 무기와 맞바꾼다.
 *  - 장비창 내용은 플레이어 PDC(문자열)에 저장되어 서버를 껐다 켜도 남는다. 메모리에 캐시해 두고 읽는다.
 *
 * 장비창 칸 번호 (27칸):  10 장갑 / 11 목걸이 / 12 반지1 / 13 반지2 / 15 무기2 / 16 보조2 / 22 무기 교체 버튼
 * 나머지는 회색 유리판(클릭 불가).
 */
final class EquipSystem implements Listener {

    static final String[] TYPES = {"glove", "amulet", "ring", "belt"};

    // 캐시 배열 인덱스
    private static final int IDX_GLOVE = 0;
    private static final int IDX_AMULET = 1;
    private static final int IDX_RING1 = 2;
    private static final int IDX_RING2 = 3;
    private static final int IDX_MAIN2 = 4;
    private static final int IDX_OFF2 = 5;
    private static final int POTION_BASE = 6;          // 0.11.0: 인덱스 6~21 = 벨트 물약 칸 (최대 16)
    private static final int MAX_POTION = 16;
    private static final int COUNT = POTION_BASE + MAX_POTION;

    // 창 칸 번호 <-> 인덱스. 장비 6칸 + 물약 16칸(윗줄 27~34, 아랫줄 36~43)
    private static final int[] WINDOW_SLOTS = buildSlots();
    private static final int SWAP_BUTTON = 22;
    private static final int INFO_SLOT = 35;
    private static final int HOTKEY_SLOT = 23;          // 0.13.0: 숫자키 스킬 단축키 켜기/끄기 버튼
    private static final int AUTO_LIFE_SLOT = 24;      // 0.12.0: 자동 마시기 버튼
    private static final int AUTO_MANA_SLOT = 25;
    private static final int AUTO_TOGGLE_SLOT = 26;
    private static final int WINDOW_SIZE = 45;

    private static int[] buildSlots() {
        int[] a = new int[COUNT];
        int[] eq = {10, 11, 12, 13, 15, 16};
        System.arraycopy(eq, 0, a, 0, eq.length);
        for (int k = 0; k < MAX_POTION; k++) a[POTION_BASE + k] = k < 8 ? 27 + k : 36 + (k - 8);
        return a;
    }

    private final DiabloRPG plugin;
    private final NamespacedKey typeKey;
    private final NamespacedKey potionSlotsKey;
    private final NamespacedKey dataKey;
    private final NamespacedKey placeholderKey;

    private final Map<UUID, ItemStack[]> cache = new HashMap<>();

    EquipSystem(DiabloRPG plugin) {
        this.plugin = plugin;
        this.typeKey = new NamespacedKey(plugin, "equip_type");
        this.potionSlotsKey = new NamespacedKey(plugin, "potion_slots");
        this.dataKey = new NamespacedKey(plugin, "equip_data");
        this.placeholderKey = new NamespacedKey(plugin, "equip_placeholder");
    }

    void start() {
        // 장비창 아이템의 최대 생명력 / 공속 / 이속 옵션은 바닐라 장비 칸이 아니라서 우리가 직접 적용한다.
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) applyAttributes(p);
        }, 20L, 10L);
    }

    NamespacedKey potionSlotsKey() { return potionSlotsKey; }

    // ===================================================================
    //  아이템 만들기
    // ===================================================================

    static boolean isExtraType(String type) {
        for (String t : TYPES) if (t.equals(type)) return true;
        return false;
    }

    static String label(String type) {
        return switch (type) {
            case "glove" -> "장갑";
            case "amulet" -> "목걸이";
            case "ring" -> "반지";
            case "belt" -> "벨트";
            default -> type;
        };
    }

    private Material defaultMaterial(String type) {
        String def = switch (type) {
            case "glove" -> "LEATHER";
            case "amulet" -> "HEART_OF_THE_SEA";
            case "ring" -> "GOLD_NUGGET";
            default -> "LEATHER_LEGGINGS";
        };
        String name = plugin.getConfig().getString("equip.items." + type, def);
        Material m = Material.matchMaterial(name);
        if (m == null || !m.isItem()) m = Material.matchMaterial(def);
        return m;
    }

    /**
     * 장갑/목걸이/반지/벨트 아이템 생성. 옵션은 기존 createItem 과 같은 방식으로 굴린다.
     * material 이 null 이면 config(equip.items.<종류>)의 기본 재료를 쓴다. 벨트는 바지 종류 재료여야 한다.
     */
    ItemStack create(String type, String rarity, Material material) {
        if (!isExtraType(type)) return null;
        // 디아2처럼 반지/목걸이는 노말이 없고 매직부터 시작한다 (config equip.no-normal).
        if ("normal".equals(rarity) && noNormal(type)) rarity = "magic";
        Material base = material != null ? material : defaultMaterial(type);
        if (type.equals("belt") && !base.name().endsWith("_LEGGINGS")) {
            base = Material.LEATHER_LEGGINGS;
        }
        ItemStack item = plugin.createItem(base, rarity);
        if (item == null) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        String rarityName = plugin.getConfig().getString("rarities." + rarity + ".display", rarity);
        meta.setDisplayName(plugin.rarityColor(rarity) + rarityName + " " + label(type));
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(typeKey, PersistentDataType.STRING, type);

        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        if (type.equals("belt")) {
            int slots = beltPotionSlots(base);
            pdc.set(potionSlotsKey, PersistentDataType.INTEGER, slots);
            lore.add(1, ChatColor.GRAY + "착용 칸: 바지 칸 (벨트)");
            lore.add(2, ChatColor.GRAY + "물약 칸: " + slots + "칸 " + ChatColor.DARK_GRAY + "(/rpgpotion 번호)");
        } else {
            // 장비창에서만 적용되므로, 손에 들거나 바닐라 칸에 끼어도 속성이 켜지지 않게 속성 보정치를 지운다.
            meta.setAttributeModifiers(null);
            lore.add(1, ChatColor.GRAY + "착용 칸: " + label(type) + " (/rpgequip 장비창)");
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    /** 노말 등급이 없는 종류인지 (기본: 반지, 목걸이). */
    boolean noNormal(String type) {
        List<String> list = plugin.getConfig().isList("equip.no-normal")
                ? plugin.getConfig().getStringList("equip.no-normal")
                : List.of("ring", "amulet");
        return list.contains(type);
    }

    private int beltPotionSlots(Material base) {
        int def = plugin.getConfig().getInt("equip.belt-potion-slots.default", 8);
        return plugin.getConfig().getInt("equip.belt-potion-slots." + base.name(), def);
    }

    /** 이 아이템이 해당 종류(glove/amulet/ring/belt)로 지정된 RPG 장비인지. */
    boolean isType(ItemStack item, String type) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        String t = item.getItemMeta().getPersistentDataContainer().get(typeKey, PersistentDataType.STRING);
        return type.equals(t);
    }

    /** 착용 중인 벨트(바지 칸)의 물약 칸 수. 벨트가 없으면 기본값(2단계에서 사용). */
    int potionSlotsOf(Player p) {
        int base = plugin.getConfig().getInt("equip.base-potion-slots", 4);
        ItemStack legs = p.getInventory().getLeggings();
        if (legs == null || legs.getType().isAir() || !legs.hasItemMeta()) return base;
        Integer n = legs.getItemMeta().getPersistentDataContainer().get(potionSlotsKey, PersistentDataType.INTEGER);
        return n == null ? base : Math.max(base, n);
    }

    // ===================================================================
    //  저장 / 불러오기
    // ===================================================================

    private ItemStack[] items(Player p) {
        ItemStack[] arr = cache.get(p.getUniqueId());
        if (arr != null) return arr;
        arr = load(p);
        cache.put(p.getUniqueId(), arr);
        return arr;
    }

    private ItemStack[] load(Player p) {
        ItemStack[] arr = new ItemStack[COUNT];
        String raw = p.getPersistentDataContainer().get(dataKey, PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) return arr;
        try {
            YamlConfiguration y = new YamlConfiguration();
            y.loadFromString(raw);
            for (int i = 0; i < COUNT; i++) {
                ItemStack it = y.getItemStack("i" + i);
                arr[i] = (it == null || it.getType().isAir()) ? null : it;
            }
        } catch (Exception ex) {
            plugin.getLogger().warning("장비창 데이터를 읽지 못했습니다 (" + p.getName() + "): " + ex.getMessage());
        }
        return arr;
    }

    private void save(Player p) {
        ItemStack[] arr = items(p);
        YamlConfiguration y = new YamlConfiguration();
        for (int i = 0; i < COUNT; i++) {
            if (arr[i] != null && !arr[i].getType().isAir()) y.set("i" + i, arr[i]);
        }
        p.getPersistentDataContainer().set(dataKey, PersistentDataType.STRING, y.saveToString());
    }

    // ===================================================================
    //  다른 시스템에서 쓰는 조회
    // ===================================================================

    /** 장비창의 장갑/목걸이/반지 아이템 (옵션 합산용). 종류가 맞지 않는 아이템은 무시한다. */
    List<ItemStack> extraItems(Player p) {
        List<ItemStack> out = new ArrayList<>(4);
        ItemStack[] a = items(p);
        if (isType(a[IDX_GLOVE], "glove")) out.add(a[IDX_GLOVE]);
        if (isType(a[IDX_AMULET], "amulet")) out.add(a[IDX_AMULET]);
        if (isType(a[IDX_RING1], "ring")) out.add(a[IDX_RING1]);
        if (isType(a[IDX_RING2], "ring")) out.add(a[IDX_RING2]);
        return out;
    }

    // ===================================================================
    //  장비창 속성(최대 생명력/공속/이속) 적용
    // ===================================================================

    void applyAttributes(Player p) {
        double hp = 0, atk = 0, mv = 0;
        for (ItemStack it : extraItems(p)) {
            PersistentDataContainer pdc = it.getItemMeta().getPersistentDataContainer();
            hp += pdc.getOrDefault(new NamespacedKey(plugin, "max_health_flat"), PersistentDataType.DOUBLE, 0.0);
            atk += pdc.getOrDefault(new NamespacedKey(plugin, "attack_speed_pct"), PersistentDataType.DOUBLE, 0.0);
            mv += pdc.getOrDefault(new NamespacedKey(plugin, "move_speed_pct"), PersistentDataType.DOUBLE, 0.0);
        }
        setModifier(p, VersionCompat.MAX_HEALTH, "equip_maxhealth", hp, AttributeModifier.Operation.ADD_NUMBER);
        setModifier(p, VersionCompat.ATTACK_SPEED, "equip_atkspeed", 4.0 * atk / 100.0, AttributeModifier.Operation.ADD_NUMBER);
        setModifier(p, VersionCompat.MOVEMENT_SPEED, "equip_movespeed", mv / 100.0, AttributeModifier.Operation.MULTIPLY_SCALAR_1);
    }

    private void setModifier(Player p, Attribute attribute, String keyName, double amount,
                             AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attribute);
        if (inst == null) return;
        NamespacedKey key = new NamespacedKey(plugin, keyName);
        AttributeModifier existing = null;
        for (AttributeModifier m : new ArrayList<>(inst.getModifiers())) {
            if (key.equals(m.getKey())) {
                existing = m;
                break;
            }
        }
        if (existing != null) {
            if (existing.getAmount() == amount && existing.getOperation() == op) return;
            inst.removeModifier(existing);
        }
        if (amount != 0.0) inst.addModifier(VersionCompat.mod(key, amount, op));
    }

    // ===================================================================
    //  장비창
    // ===================================================================

    static final class EquipHolder implements InventoryHolder {
        Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private ItemStack icon(Material mat, String name, String... lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        if (lore.length > 0) {
            List<String> l = new ArrayList<>();
            for (String s : lore) l.add(s);
            meta.setLore(l);
        }
        meta.getPersistentDataContainer().set(placeholderKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    private boolean isPlaceholder(ItemStack it) {
        return it != null && !it.getType().isAir() && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(placeholderKey, PersistentDataType.BYTE);
    }

    private ItemStack placeholderFor(int idx) {
        if (idx >= POTION_BASE) {
            return icon(Material.GLASS_BOTTLE, ChatColor.GRAY + "물약 칸 " + (idx - POTION_BASE + 1));
        }
        return switch (idx) {
            case IDX_GLOVE -> icon(Material.LIGHT_GRAY_STAINED_GLASS_PANE, ChatColor.GRAY + "장갑 칸");
            case IDX_AMULET -> icon(Material.LIGHT_GRAY_STAINED_GLASS_PANE, ChatColor.GRAY + "목걸이 칸");
            case IDX_RING1 -> icon(Material.LIGHT_GRAY_STAINED_GLASS_PANE, ChatColor.GRAY + "반지 칸 1");
            case IDX_RING2 -> icon(Material.LIGHT_GRAY_STAINED_GLASS_PANE, ChatColor.GRAY + "반지 칸 2");
            case IDX_MAIN2 -> icon(Material.LIGHT_BLUE_STAINED_GLASS_PANE, ChatColor.AQUA + "무기 2 (오른손)");
            default -> icon(Material.LIGHT_BLUE_STAINED_GLASS_PANE, ChatColor.AQUA + "보조 2 (왼손/방패)");
        };
    }

    void open(Player p) {
        EquipHolder holder = new EquipHolder();
        Inventory inv = Bukkit.createInventory(holder, WINDOW_SIZE, ChatColor.DARK_GRAY + "장비창");
        holder.inventory = inv;
        ItemStack filler = icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < WINDOW_SIZE; i++) inv.setItem(i, filler);
        for (int i = 0; i < COUNT; i++) {
            inv.setItem(WINDOW_SLOTS[i], slotIcon(p, i));
        }
        refreshAuto(p, inv);
        refreshHotkey(p, inv);
        inv.setItem(INFO_SLOT, icon(Material.BOOK, ChatColor.YELLOW + "물약 칸 " + potionCapacity(p) + "칸",
                ChatColor.GRAY + "벨트를 끼면 칸이 늘어납니다",
                ChatColor.GRAY + "물약 우클릭 = 마시기",
                ChatColor.DARK_GRAY + "명령어: /rpgpotion 번호"));
        inv.setItem(SWAP_BUTTON, icon(Material.COMPASS, ChatColor.YELLOW + "무기 교체",
                ChatColor.GRAY + "손에 든 무기 <-> 무기 2 / 보조 2",
                ChatColor.DARK_GRAY + "명령어: /rpgswap"));
        p.openInventory(inv);
    }

    /** 숫자키 스킬 단축키 스위치 그림. */
    private void refreshHotkey(Player p, Inventory inv) {
        SkillSystem sk = plugin.skillSystem();
        if (sk == null || !sk.hasClass(p)) {
            inv.setItem(HOTKEY_SLOT, icon(Material.BARRIER, ChatColor.GRAY + "숫자키 스킬 단축키",
                    ChatColor.GRAY + "직업을 고르면 쓸 수 있습니다 (/rpgskill)"));
            return;
        }
        boolean on = sk.hotkeysOn(p);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "켜짐: 무기를 1번 칸에 든 채 숫자키로 스킬을 고릅니다");
        if (sk.cycleMode()) {
            lore.add(ChatColor.GRAY + "  숫자키 3~8 = 등록한 스킬 선택 (웅크리면 왼쪽 스킬)");
            lore.add(ChatColor.GRAY + "  마우스 휠 / 숫자키 2, 9 = 스킬 넘기기");
        } else {
            lore.add(ChatColor.GRAY + "  숫자키 2~9 = 등록한 스킬 선택 (웅크리면 왼쪽 스킬)");
        }
        lore.add(ChatColor.GRAY + "꺼짐: 숫자키/휠이 평소처럼 핫바 아이템을 바꿉니다");
        lore.add(ChatColor.DARK_GRAY + "등록: /rpgskill 창에서 스킬 위에 마우스를 올리고 숫자키");
        lore.add(ChatColor.YELLOW + "클릭하면 " + (on ? "끕니다" : "켭니다"));
        inv.setItem(HOTKEY_SLOT, icon(on ? Material.LIME_DYE : Material.GRAY_DYE,
                ChatColor.YELLOW + "숫자키 스킬 단축키: " + (on ? ChatColor.GREEN + "켜짐" : ChatColor.RED + "꺼짐"),
                lore.toArray(new String[0])));
    }

    /** 자동 마시기 버튼 3개(체력 기준 %, 마나 기준 %, 켜기/끄기)의 그림을 갱신한다. */
    private void refreshAuto(Player p, Inventory inv) {
        PotionSystem ps = plugin.potionSystem();
        boolean master = ps.autoMaster();
        boolean on = ps.isAutoOn(p);
        int step = ps.autoStep();
        int life = ps.autoLifePct(p);
        int mana = ps.autoManaPct(p);
        String lifeTxt = life <= 0 ? ChatColor.GRAY + "사용 안 함" : ChatColor.WHITE + "" + life + "%";
        String manaTxt = mana <= 0 ? ChatColor.GRAY + "사용 안 함" : ChatColor.WHITE + "" + mana + "%";
        inv.setItem(AUTO_LIFE_SLOT, icon(Material.RED_DYE, ChatColor.RED + "자동 체력 물약: " + lifeTxt,
                ChatColor.GRAY + "체력이 이 % 밑으로 내려가면",
                ChatColor.GRAY + "벨트의 체력 물약을 자동으로 마십니다",
                ChatColor.YELLOW + "좌클릭 +" + step + "%  /  우클릭 -" + step + "%",
                ChatColor.DARK_GRAY + "0% = 사용 안 함"));
        inv.setItem(AUTO_MANA_SLOT, icon(Material.LAPIS_LAZULI, ChatColor.BLUE + "자동 마나 물약: " + manaTxt,
                ChatColor.GRAY + "마나가 이 % 밑으로 내려가면",
                ChatColor.GRAY + "벨트의 마나 물약을 자동으로 마십니다",
                ChatColor.YELLOW + "좌클릭 +" + step + "%  /  우클릭 -" + step + "%",
                ChatColor.DARK_GRAY + "0% = 사용 안 함"));
        if (!master) {
            inv.setItem(AUTO_TOGGLE_SLOT, icon(Material.BARRIER, ChatColor.RED + "자동 마시기: 서버에서 꺼져 있음"));
        } else if (on) {
            inv.setItem(AUTO_TOGGLE_SLOT, icon(Material.LIME_DYE, ChatColor.GREEN + "자동 마시기: 켜짐",
                    ChatColor.GRAY + "클릭하면 끕니다"));
        } else {
            inv.setItem(AUTO_TOGGLE_SLOT, icon(Material.GRAY_DYE, ChatColor.GRAY + "자동 마시기: 꺼짐",
                    ChatColor.GRAY + "클릭하면 켭니다"));
        }
    }

    private ItemStack slotIcon(Player p, int i) {
        if (isLocked(p, i)) {
            return icon(Material.BLACK_STAINED_GLASS_PANE, ChatColor.DARK_GRAY + "잠김 (더 큰 벨트가 필요)");
        }
        ItemStack[] a = items(p);
        return a[i] != null ? a[i].clone() : placeholderFor(i);
    }

    private boolean isLocked(Player p, int idx) {
        return idx >= POTION_BASE && (idx - POTION_BASE) >= potionCapacity(p);
    }

    // ----- 물약 칸 API (PotionSystem 이 사용) -----

    /** 지금 쓸 수 있는 물약 칸 수 (벨트에 따라 4~16). */
    int potionCapacity(Player p) {
        return Math.max(0, Math.min(MAX_POTION, potionSlotsOf(p)));
    }

    /** n번(1부터) 물약 칸의 아이템. 비었거나 잠긴 칸이면 null. */
    ItemStack getPotion(Player p, int n) {
        if (n < 1 || n > potionCapacity(p)) return null;
        ItemStack it = items(p)[POTION_BASE + n - 1];
        return it == null ? null : it.clone();
    }

    /** n번 물약 칸을 바꾼다 (null = 비움). 저장하고, 장비창이 열려 있으면 그림도 갱신. */
    void setPotion(Player p, int n, ItemStack item) {
        if (n < 1 || n > potionCapacity(p)) return;
        items(p)[POTION_BASE + n - 1] = (item == null || item.getType().isAir()) ? null : item;
        save(p);
        Inventory top = p.getOpenInventory().getTopInventory();
        if (top.getHolder() instanceof EquipHolder) {
            top.setItem(WINDOW_SLOTS[POTION_BASE + n - 1], slotIcon(p, POTION_BASE + n - 1));
        }
    }

    private int indexOfWindowSlot(int rawSlot) {
        for (int i = 0; i < COUNT; i++) if (WINDOW_SLOTS[i] == rawSlot) return i;
        return -1;
    }

    /** 이 아이템을 그 칸에 넣어도 되는지. */
    private boolean accepts(int idx, ItemStack it) {
        if (it == null || it.getType().isAir()) return false;
        if (idx >= POTION_BASE) return plugin.potionSystem() != null && plugin.potionSystem().isPotion(it);
        return switch (idx) {
            case IDX_GLOVE -> isType(it, "glove");
            case IDX_AMULET -> isType(it, "amulet");
            case IDX_RING1, IDX_RING2 -> isType(it, "ring");
            default -> !isPlaceholder(it) && !isType(it, "glove") && !isType(it, "amulet")
                    && !isType(it, "ring") && !plugin.potionSystem().isPotion(it); // 무기 2 / 보조 2 : 장신구/물약은 안 됨
        };
    }

    private String wantText(int idx) {
        return switch (idx) {
            case IDX_GLOVE -> "장갑";
            case IDX_AMULET -> "목걸이";
            case IDX_RING1, IDX_RING2 -> "반지";
            default -> idx >= POTION_BASE ? "물약" : "무기/방패";
        };
    }

    /** 장비창 안 한 칸을 바꾼 뒤 저장/속성 갱신/그림 갱신. */
    private void commit(Player p, Inventory inv, int idx, ItemStack newItem) {
        ItemStack[] a = items(p);
        a[idx] = (newItem == null || newItem.getType().isAir()) ? null : newItem;
        inv.setItem(WINDOW_SLOTS[idx], a[idx] != null ? a[idx].clone() : placeholderFor(idx));
        save(p);
        applyAttributes(p);
    }

    private void give(Player p, ItemStack it) {
        if (it == null || it.getType().isAir()) return;
        p.getInventory().addItem(it).values().forEach(left ->
                p.getWorld().dropItemNaturally(p.getLocation(), left));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof EquipHolder)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return; // 창 밖 클릭(아이템 버리기 등)은 기본 동작

        ClickType click = e.getClick();

        // ----- 아래쪽(내 인벤토리) 클릭 -----
        if (clicked != top) {
            if (click == ClickType.DOUBLE_CLICK) {
                e.setCancelled(true);
                return;
            }
            if (e.isShiftClick()) {
                // 내 인벤토리 -> 장비창으로 보내기
                e.setCancelled(true);
                ItemStack it = e.getCurrentItem();
                if (it == null || it.getType().isAir()) return;
                ItemStack[] a = items(p);
                for (int idx = 0; idx < COUNT; idx++) {
                    if (a[idx] == null && !isLocked(p, idx) && accepts(idx, it)) {
                        ItemStack one = it.clone();
                        one.setAmount(1);
                        if (it.getAmount() > 1) {
                            it.setAmount(it.getAmount() - 1);
                            e.setCurrentItem(it);
                        } else {
                            e.setCurrentItem(null);
                        }
                        commit(p, top, idx, one);
                        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_GENERIC, 0.8f, 1.0f);
                        return;
                    }
                }
                return;
            }
            return; // 그 밖에는 인벤토리 안 정리라서 기본 동작
        }

        // ----- 위쪽(장비창) 클릭: 전부 직접 처리 -----
        e.setCancelled(true);
        int raw = e.getRawSlot();

        if (raw == SWAP_BUTTON) {
            swapPreset(p);
            return;
        }
        if (raw == HOTKEY_SLOT) {
            SkillSystem sk = plugin.skillSystem();
            if (sk != null && sk.hasClass(p)) sk.toggleHotkeys(p);
            refreshHotkey(p, top);
            return;
        }
        if (raw == AUTO_LIFE_SLOT || raw == AUTO_MANA_SLOT) {
            boolean lifeBtn = raw == AUTO_LIFE_SLOT;
            int sign = (click == ClickType.RIGHT || click == ClickType.SHIFT_RIGHT) ? -1 : 1;
            plugin.potionSystem().adjustAuto(p, lifeBtn, sign);
            refreshAuto(p, top);
            return;
        }
        if (raw == AUTO_TOGGLE_SLOT) {
            plugin.potionSystem().toggleAuto(p);
            refreshAuto(p, top);
            return;
        }
        int idx = indexOfWindowSlot(raw);
        if (idx < 0) return;

        if (isLocked(p, idx)) {
            p.sendMessage(ChatColor.GRAY + "이 물약 칸은 더 큰 벨트를 끼면 열립니다.");
            return;
        }
        ItemStack[] a = items(p);
        ItemStack current = a[idx];
        ItemStack cursor = p.getItemOnCursor();
        boolean cursorEmpty = cursor == null || cursor.getType().isAir();

        // 물약 칸 우클릭 = 마시기
        if (idx >= POTION_BASE && cursorEmpty && current != null && click == ClickType.RIGHT) {
            plugin.potionSystem().drinkFromSlot(p, idx - POTION_BASE + 1);
            return;
        }

        // Shift 클릭: 꺼내서 인벤토리로
        if (e.isShiftClick()) {
            if (current != null) {
                commit(p, top, idx, null);
                give(p, current);
            }
            return;
        }

        // 숫자키: 핫바 칸과 맞바꾸기
        if (click == ClickType.NUMBER_KEY) {
            PlayerInventory pinv = p.getInventory();
            int hb = e.getHotbarButton();
            if (hb < 0 || hb > 8) return;
            ItemStack h = pinv.getItem(hb);
            boolean hEmpty = h == null || h.getType().isAir();
            if (hEmpty) {
                if (current != null) {
                    commit(p, top, idx, null);
                    pinv.setItem(hb, current);
                }
            } else if (accepts(idx, h)) {
                ItemStack one = h.clone();
                one.setAmount(1);
                if (h.getAmount() > 1) {
                    h.setAmount(h.getAmount() - 1);
                    pinv.setItem(hb, h);
                    commit(p, top, idx, one);
                    give(p, current);
                } else {
                    commit(p, top, idx, one);
                    pinv.setItem(hb, current);
                }
            } else {
                p.sendMessage(ChatColor.RED + "이 칸에는 " + wantText(idx) + "만 넣을 수 있습니다.");
            }
            return;
        }

        // 일반 클릭
        if (cursorEmpty) {
            if (current != null) {
                commit(p, top, idx, null);
                p.setItemOnCursor(current);
            }
            return;
        }
        if (!accepts(idx, cursor)) {
            p.sendMessage(ChatColor.RED + "이 칸에는 " + wantText(idx) + "만 넣을 수 있습니다.");
            return;
        }
        ItemStack one = cursor.clone();
        one.setAmount(1);
        if (cursor.getAmount() > 1) {
            // 한 개만 넣고 나머지는 커서에 남긴다. 원래 있던 아이템은 인벤토리로.
            ItemStack rest = cursor.clone();
            rest.setAmount(cursor.getAmount() - 1);
            p.setItemOnCursor(rest);
            commit(p, top, idx, one);
            give(p, current);
        } else {
            commit(p, top, idx, one);
            p.setItemOnCursor(current); // 맞바꾸기 (current 가 null 이면 커서 비움)
        }
        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_GENERIC, 0.8f, 1.0f);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof EquipHolder)) return;
        for (int raw : e.getRawSlots()) {
            if (raw < top.getSize()) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof EquipHolder)) return;
        if (e.getPlayer() instanceof Player p) {
            save(p);
            applyAttributes(p);
        }
    }

    // ===================================================================
    //  무기 프리셋
    // ===================================================================

    /** 손에 든 무기(오른손/왼손)와 장비창의 무기 2 / 보조 2 를 맞바꾼다. */
    void swapPreset(Player p) {
        ItemStack[] a = items(p);
        PlayerInventory inv = p.getInventory();
        ItemStack main = inv.getItemInMainHand();
        ItemStack off = inv.getItemInOffHand();
        ItemStack m2 = a[IDX_MAIN2];
        ItemStack o2 = a[IDX_OFF2];
        if (m2 == null && o2 == null && isAir(main) && isAir(off)) {
            p.sendMessage(ChatColor.GRAY + "교체할 무기가 없습니다. /rpgequip 의 무기 2 / 보조 2 칸에 무기를 넣으세요.");
            return;
        }
        inv.setItemInMainHand(m2);
        inv.setItemInOffHand(o2);
        a[IDX_MAIN2] = isAir(main) ? null : main.clone();
        a[IDX_OFF2] = isAir(off) ? null : off.clone();
        save(p);
        applyAttributes(p);
        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_IRON, 0.8f, 1.2f);
        if (p.getOpenInventory().getTopInventory().getHolder() instanceof EquipHolder) {
            Inventory top = p.getOpenInventory().getTopInventory();
            top.setItem(WINDOW_SLOTS[IDX_MAIN2], a[IDX_MAIN2] != null ? a[IDX_MAIN2].clone() : placeholderFor(IDX_MAIN2));
            top.setItem(WINDOW_SLOTS[IDX_OFF2], a[IDX_OFF2] != null ? a[IDX_OFF2].clone() : placeholderFor(IDX_OFF2));
        }
        plugin.statSystem().notice(p, ChatColor.AQUA + "무기 교체");
    }

    private boolean isAir(ItemStack it) {
        return it == null || it.getType().isAir();
    }

    // ===================================================================
    //  접속 / 사망 / 손 바꾸기 키
    // ===================================================================

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        cache.put(p.getUniqueId(), load(p));
        applyAttributes(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (cache.containsKey(p.getUniqueId())) save(p);
        cache.remove(p.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!plugin.getConfig().getBoolean("equip.drop-on-death", false)) return;
        if (e.getKeepInventory()) return;
        Player p = e.getEntity();
        ItemStack[] a = items(p);
        for (int i = 0; i < COUNT; i++) {
            if (a[i] != null) {
                e.getDrops().add(a[i]);
                a[i] = null;
            }
        }
        save(p);
    }

    /** config equip.swap-key: true 이면 손 바꾸기 키(기본 F)가 무기 프리셋 교체가 된다. */
    @EventHandler
    public void onSwapKey(PlayerSwapHandItemsEvent e) {
        if (!plugin.getConfig().getBoolean("equip.swap-key", false)) return;
        e.setCancelled(true);
        swapPreset(e.getPlayer());
    }

    // ===================================================================
    //  명령어
    // ===================================================================

    boolean handleEquipCommand(CommandSender sender) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("플레이어만 쓸 수 있습니다.");
            return true;
        }
        open(p);
        return true;
    }

    boolean handleSwapCommand(CommandSender sender) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("플레이어만 쓸 수 있습니다.");
            return true;
        }
        swapPreset(p);
        return true;
    }

    /** /rpgitem give ... <glove|amulet|ring|belt> 에서 쓰는 이름 해석. 아니면 null. */
    static String parseType(String arg) {
        String a = arg.toLowerCase(Locale.ROOT);
        return isExtraType(a) ? a : null;
    }
}
