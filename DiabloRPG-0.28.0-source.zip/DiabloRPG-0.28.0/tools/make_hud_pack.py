"""DiabloRPG HUD 리소스팩 생성기 (체력/마나 이미지 바 + 하트/허기/갑옷 바 숨김).

사용법:  python make_hud_pack.py <출력 폴더> [BAR_ASCENT]
  BAR_ASCENT  바를 아래로 얼마나 내릴지(기본 -13). 더 작게(-16 등) 쓰면 바가 더 아래로, 크게(-8 등) 쓰면 위로 올라간다.
  화면 크기(GUI 배율)에 따라 위치가 어긋나면 이 값을 바꿔서 다시 만들면 된다.
바 이미지(도안)는 이 파일 안에서 그리는 임시 도안이다. 나중에 직접 그린 이미지로 바꾸려면
  assets/diablorpg/textures/font/bar_hp.png (84 x 387, 9픽셀 칸 43개, 위에서부터 0칸~42칸 채움),
  bar_mp.png (같은 규격), digits.png (55 x 7, 5픽셀 칸 11개: 0123456789/) 를 같은 규격으로 교체한다.
"""
import json
import os
import sys
import zipfile

from PIL import Image

out_dir = sys.argv[1]
BAR_ASCENT = int(sys.argv[2]) if len(sys.argv) > 2 else -13
DIGIT_ASCENT = BAR_ASCENT - 1
STEPS = 42            # 0..42 = 43칸
BAR_W, BAR_H = 84, 9
INNER_W = BAR_W - 2

# ---------------- 바 이미지 ----------------
def bar_atlas(bg, top, bottom, border):
    img = Image.new("RGBA", (BAR_W, BAR_H * (STEPS + 1)), (0, 0, 0, 0))
    px = img.load()
    for step in range(STEPS + 1):
        oy = step * BAR_H
        fill = round(step / STEPS * INNER_W)
        for y in range(BAR_H):
            for x in range(BAR_W):
                if y in (0, BAR_H - 1) or x in (0, BAR_W - 1):
                    px[x, oy + y] = border + (255,)
                else:
                    if x - 1 < fill:
                        t = (y - 1) / (BAR_H - 3)
                        c = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
                        px[x, oy + y] = c + (255,)
                    else:
                        px[x, oy + y] = bg + (255,)
    return img

hp_img = bar_atlas((70, 12, 12), (240, 70, 70), (150, 20, 20), (20, 4, 4))
mp_img = bar_atlas((10, 20, 70), (90, 140, 250), (30, 60, 170), (4, 6, 20))

# ---------------- 숫자 (5x7) ----------------
GLYPHS = {
    "0": ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
    "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
    "2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
    "3": ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
    "4": ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
    "5": ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
    "6": ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
    "7": ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
    "8": ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
    "9": ["01110", "10001", "10001", "01111", "00001", "00010", "01100"],
    "/": ["00001", "00010", "00010", "00100", "01000", "01000", "10000"],
}
ORDER = "0123456789/"
digits = Image.new("RGBA", (5 * len(ORDER), 7), (0, 0, 0, 0))
dp = digits.load()
for i, ch in enumerate(ORDER):
    rows = GLYPHS[ch]
    for y in range(7):
        for x in range(5):
            if rows[y][x] == "1":
                dp[i * 5 + x, y] = (255, 255, 255, 255)
    # 모든 글자의 폭이 정확히 5가 되도록, 오른쪽 끝 열이 비면 눈에 안 보이는 픽셀(투명도 1)을 하나 둔다.
    if all(rows[y][4] == "0" for y in range(7)):
        dp[i * 5 + 4, 6] = (255, 255, 255, 1)

# ---------------- 폰트 정의 ----------------
space_adv = {}
for i in range(8):
    space_adv[chr(0xE100 + i)] = -(1 << i)
    space_adv[chr(0xE110 + i)] = (1 << i)
hp_chars = [chr(0xE200 + i) for i in range(STEPS + 1)]
mp_chars = [chr(0xE300 + i) for i in range(STEPS + 1)]
font = {"providers": [
    {"type": "space", "advances": space_adv},
    {"type": "bitmap", "file": "diablorpg:font/bar_hp.png", "ascent": BAR_ASCENT, "height": BAR_H, "chars": hp_chars},
    {"type": "bitmap", "file": "diablorpg:font/bar_mp.png", "ascent": BAR_ASCENT, "height": BAR_H, "chars": mp_chars},
    {"type": "bitmap", "file": "diablorpg:font/digits.png", "ascent": DIGIT_ASCENT, "height": 7, "chars": [ORDER]},
]}

# ---------------- 숨길 기본 HUD 스프라이트 (투명 9x9) ----------------
HIDE = []
for kind in ["", "poisoned_", "withered_", "frozen_", "absorbing_"]:
    for hard in ["", "hardcore_"]:
        for part in ["full", "half"]:
            for blink in ["", "_blinking"]:
                HIDE.append("hud/heart/%s%s%s%s" % (kind, hard, part, blink))
for hard in ["", "_hardcore"]:
    for blink in ["", "_blinking"]:
        HIDE.append("hud/heart/container%s%s" % (hard, blink))
for n in ["food_empty", "food_empty_hunger", "food_full", "food_full_hunger", "food_half", "food_half_hunger",
          "armor_empty", "armor_full", "armor_half"]:
    HIDE.append("hud/" + n)

def png_bytes(img):
    import io
    b = io.BytesIO()
    img.save(b, "PNG")
    return b.getvalue()

transparent = png_bytes(Image.new("RGBA", (9, 9), (0, 0, 0, 0)))

README = """[DiabloRPG HUD 리소스팩]
 - 하트 / 허기 / 갑옷 바를 숨기고, 핫바 위에 체력(빨강, 왼쪽)/마나(파랑, 오른쪽) 바와 숫자를 그린다.
 - 마크: 설정 -> 리소스 팩 에서 켠다. (룬 팩/소리 팩과 같이 켜도 된다.)
 - 서버 plugins/DiabloRPG/config.yml 의 hud.mode 가 bars 여야 바가 나온다. (text 면 글자로만 표시)
 - 바 위치가 어긋나면 tools/make_hud_pack.py 의 BAR_ASCENT 값을 바꿔서 팩을 다시 만든다.
   (화면 크기=GUI 배율에 따라 달라질 수 있다.)
 - 리소스팩을 안 켠 플레이어는 /rpgstat hud 로 글자 표시로 바꿀 수 있다.
"""

os.makedirs(out_dir, exist_ok=True)
zpath = os.path.join(out_dir, "DiabloRPG-HUD-ResourcePack.zip")
with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("pack.mcmeta", json.dumps({"pack": {"pack_format": 34, "description": "DiabloRPG HUD"}}, ensure_ascii=False, indent=2))
    z.writestr("assets/diablorpg/font/hud.json", json.dumps(font, indent=1))
    z.writestr("assets/diablorpg/textures/font/bar_hp.png", png_bytes(hp_img))
    z.writestr("assets/diablorpg/textures/font/bar_mp.png", png_bytes(mp_img))
    z.writestr("assets/diablorpg/textures/font/digits.png", png_bytes(digits))
    for name in HIDE:
        z.writestr("assets/minecraft/textures/gui/sprites/%s.png" % name, transparent)
    z.writestr("README.txt", README)
print("wrote", zpath, "hidden sprites:", len(HIDE), "ascent:", BAR_ASCENT)
